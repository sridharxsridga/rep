# -*- coding: utf-8 -*-
"""
Created on Fri Oct 20 15:28:13 2017

@author: Colm Coughlan. Data Science and Solutions. 40631
"""

import logging
import socket
from logging.handlers import TimedRotatingFileHandler


class CustomLogger(logging.Logger):
        
    def _set_extra_vars(self, appname):
        
        host = socket.gethostname()
        if 'rhhdpalp' in host:
            node_type = 'ALPHA'
        elif 'rhhdpomt' in host:
            node_type = 'OMEGA'
        elif 'rhdtmomg' in host:
            node_type = 'DEV'
        else:
            node_type = 'UNKNOWN'
            
        self.extra_args = {'appName': appname, 'host':host,'nodeType':node_type}

    def _log(self, level, msg, args, exc_info=None, extra=None):
        super(CustomLogger, self)._log(level, msg, args, exc_info, extra = self.extra_args)
        
        
def getLogger(appname = 'Unknown', loggername='dsspylogger', log_file = None):
    logger = logging.getLogger(loggername)

    logger._set_extra_vars(appname)
    logger.setLevel(logging.INFO) # do not log at debug level! info leaks from pyjks library.... (could turn this off too)
    if log_file is None:
        handler = logging.StreamHandler(None)
    else:
        logger.handlers = []
        handler = TimedRotatingFileHandler(log_file,when="d",interval=1,backupCount=180) # daily rotations, keep last year
    handler.setFormatter(logging.Formatter('{"startTime":"%(asctime)s", "hostName":"%(host)s", "nodeType":"%(nodeType)s", "level":"%(levelname)s", "timestamp":"%(asctime)s", "from":"%(module)s", "class":"%(funcName)s", "line":"%(lineno)d", "content":"%(message)s" }', datefmt='%Y-%m-%d %H:%M:%S'))
    logger.addHandler(handler)
    
    return logger
    
logging.setLoggerClass(CustomLogger)