# -*- coding: utf-8 -*-
"""
Created on Fri May 26 10:22:22 2017

@author: Colm Coughlan. Data Science and Solutions. 40631
"""

from setuptools import setup

extras = {
   'full_install': ['paramiko', 'pyOpenSSL']
}


setup(name='dsspy',
      version='0.6',
      description='The Data Science and Solutions python library',
      url='giturl',
      author='Data Science and Solutions, AIB',
      author_email='datascience@aib.ie',
      packages=['dsspy'],
      install_requires=[
          'pandas','requests','pyodbc'
      ],
      zip_safe=False)