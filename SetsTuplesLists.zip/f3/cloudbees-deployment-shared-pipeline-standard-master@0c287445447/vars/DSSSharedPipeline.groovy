//This method is called by configuring giturl and branch. For eg. giturl is https://gitstash.aib.pri/scm/hea/deployment-cloudbees-scripts.git and branch as master.

def call() {
	//Selecting cloudbees instances of maven and openjdk of specific versions
    pipeline {
        agent { label 'maven-3.3.9-openjdk-1.8.0_121' }
        options {
            timestamps()
            buildDiscarder(logRotator(
                artifactDaysToKeepStr: '',
                artifactNumToKeepStr: '',
				//No. of days to keep the previous build logs
                daysToKeepStr: '180',
				//Number of previous build to keep
                numToKeepStr: '10')
            )
        }
        
		//Configuring the parameters from Cloudbees UI
        parameters {           	
            choice( \
                name: 'Environment',
                choices: 'pre-prod\nprod',
                description: 'Environment where the job has to be deployed'
            )
            choice( \
                name: 'User',
                choices: 'test_data_batch\ndata_batch',
                description: 'User for deploying the job\n Note: data_batch + prod environment needs approval from product owners'
            )
			
			string(name: 'Job_GitURL', defaultValue: '', description: 'Git url for the repository that has the BRD. eg:https://gitstash.aib.pri/scm/hddp/call-data-agent-desktop-voice-id.git')
			
			string(name: 'Job_Pull_Branch', defaultValue: 'master', description: 'Git branch of the repository that has the BRD. eg:master, pre-prod, dev')
			
			string(name: 'Job_Push_Branch', defaultValue: 'master', description: 'Git branch name for updating the file created during the deployment. e.g. master,pre-prod,dev')
					
            string(name: 'Job_Push_Message', defaultValue: 'DSS-', description: 'Jira story link for this deployment. e.g. DSS-10 Deployment in pre-prod')	
			
			string(name: 'Table_Stem_Regex', defaultValue: 'HR*', description: 'This field is used for creating the tables for each acquisations based on the type of acquisation. e.g. CALL*,HR*')
			
			choice( \
                name: 'Configuration_file',
                choices: 'default\ndefault_with_stg\nvm\nproduction',
                description: 'The configuration file containing the deployment steps'
            )
			
            choice( \
                name: 'Solr_Source_Column',
                choices: 'Source Field\nTarget Field\nSource Field Short Description',
                description: 'Column in BRD specifying the Source columns'
            )
				
        }

		//Configuring Credentials and Deployment pipeline into Environment
        environment {
            CREDENTIALS_ID = 'Data_builduser'
            GIT_CREDENTIALS = credentials("${env.CREDENTIALS_ID}")
            CONTROL_REPO = 'https://gitstash.aib.pri/scm/hea/deployment-pipeline.git'
        }

		//Prompting for Cloudbees credentials
        stages {
            stage('Parameters') {
                steps{
                    script {
                        jenkins_creds = input message: "Please input jenkins server access credentials",
                            parameters: [
                                string(name: 'user', defaultValue: '', description: ''),
                                password(name: 'password', defaultValue: '', description: '')
                            ]
                    }
                }
            }

			//Fetching the Deployment pipeline repo, properties_repo and job_repo
            stage('Git fetch') {
                steps {
                    // Determine Git repository to checkout
                    script {
                      	properties_repo = 'https://gitstash.aib.pri/scm/hea/deployment-properties.git'
                        props_file = params.Env + "-" + params.User
                    }
                    checkout_scm(params.Job_Pull_Branch, 'project', params.Job_GitURL)
                    checkout_scm('master', 'control', env.CONTROL_REPO)
                    checkout_scm('master', 'properties', properties_repo)

                }
            }

			//Adding Cloudbees username and Cloudbees pipeline name to environment and Executing the deployment pipeline
            stage('Run pipeline') {
                steps {
                  wrap([$class: 'BuildUser'])
					{
    					sh 'echo "${BUILD_USER}"'
                        script {
                            jenkins_username = BUILD_USER
                            jenkins_pipename ="${env.JOB_NAME}"		
                            echo "jenkins_pipename : $jenkins_pipename" 
                        } 
					}
                    run_pipeline(jenkins_creds)
                }
            }
        }
    }
}

//Function to pull git repo of particular branch into targetDir
def checkout_scm(branch, targetDir, repoUrl) {
    checkout changelog: false, scm: [
        $class: 'GitSCM',
        branches: [[name: branch]],
        doGenerateSubmoduleConfigurations: false,
        extensions: [[
            $class: 'LocalBranch', localBranch: branch],
            [$class: 'RelativeTargetDirectory',
            relativeTargetDir: targetDir
        ]],
        submoduleCfg: [],
        userRemoteConfigs: [[
            credentialsId: env.CREDENTIALS_ID,
            url: repoUrl
        ]]
    ]
}

//Fetching job properties from UI and setting into Environment. Executing the main function of deployment-pipeline with arguments read from Properties file.
def run_pipeline(Map jenkins_creds) {
    target = params.Job_GitURL.replaceFirst(/.*\/(.*)\.git/, '$1') //TODO: Sanity check here
	withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId: 'Data_builduser',
            usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']]) {  
        withEnv([
            "jenkins_username=${jenkins_username}",
            "jenkins_build_user=${jenkins_creds.user}",
			
            "jenkins_build_user_password=${jenkins_creds.password}",
			
            "target=${target}",
            "table_stem=${params.Table_Stem_Regex}",
            "solr_source_field=\"${params.Solr_Source_Column}\"",
            "git_msg=${params.Job_Push_Message}",
			"config_file=${params.Configuration_file}",
			"push_branch=${params.Job_Push_Branch}"
            ]) {
          	props = readProperties file: 'properties/properties/'+params.Environment+"-"+params.User+".properties"
            sh """
			export jenkins_build_user=${env.jenkins_build_user}
			#export jenkins_build_user_password=${env.jenkins_build_user_password}  
			export jenkins_username=${jenkins_username}
			export jenkins_pipename=${jenkins_pipename}
			export GIT_USERNAME=\$GIT_CREDENTIALS_USR
			export GIT_PASSWORD=\$GIT_CREDENTIALS_PSW
			python control/DEPLOY/pipeline.py ${props.env_type} ${props.env_vars}
			"""
    	}
    }
}

