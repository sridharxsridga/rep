sync module
===========

.. automodule:: sync
    :members:
    :undoc-members:
    :show-inheritance:
