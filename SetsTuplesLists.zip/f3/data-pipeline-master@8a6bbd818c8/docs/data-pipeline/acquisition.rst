acquisition module
==================

.. automodule:: acquisition
    :members:
    :undoc-members:
    :show-inheritance:
