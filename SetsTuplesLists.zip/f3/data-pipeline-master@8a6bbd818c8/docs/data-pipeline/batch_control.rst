batch_control module
====================

.. automodule:: batch_control
    :members:
    :undoc-members:
    :show-inheritance:
