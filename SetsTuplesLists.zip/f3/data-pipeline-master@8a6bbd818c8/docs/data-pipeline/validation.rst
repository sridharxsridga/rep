validation module
=================

.. automodule:: validation
    :members:
    :undoc-members:
    :show-inheritance:
