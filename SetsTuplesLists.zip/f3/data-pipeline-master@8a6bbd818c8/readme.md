# Data Pipeline
This is the data pipeline which runs jobs on Hadoop
It allows you to run the spark ETL app, validate files, run sqoop or sql etc., all while logging to an appropriate area and configured by the entry in the Solr metadata core

Sample use:

~~~~
python3 data_pipeline.py validate,etl "http://rhhdpalp8.mid.aib.pri:8983/solr/Production-Job-Configuration/select?q=id%3ACALL_LCM*&rows=145&wt=json&indent=true" $1 "http://rhhdpalp8.mid.aib.pri:8983/solr/Production-Job-Configuration/select?q=id%3ACALL_LCM*&rows=145&wt=json&indent=true" "http://rhhdpalp8.mid.aib.pri:8983/solr/BatchLogs_Prod/select?q=*" HDCWD00P.HADOOP_ETL_BATCH_LOGS_D2 SCHEDULER_RUN_CONTROL_DATE --jar_path=/opt/scripts/DataInnovation/ProductionScripts/data-acquisition/JAR --log4j_path=/opt/scripts/DataInnovation/ProductionScripts/data-acquisition/logs.properties --jceks=jcekspath --debug
~~~~
## Dependencies
dsspy