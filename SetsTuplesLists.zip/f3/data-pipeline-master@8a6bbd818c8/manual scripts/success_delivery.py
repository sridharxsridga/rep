"""
Utility to reset folder at original status
@Author Alessandro Marrella
"""

import os
import argparse

parser = argparse.ArgumentParser(description='Move files back from archive, clear db, remove filtered')
parser.add_argument('prefix', type=str, help='Prefix of the directory')

args = parser.parse_args()

dirs = [dir for dir in os.listdir(".") if os.path.isdir(dir) and args.prefix in dir]

print(dirs)
with open("make_dirs.sh","w") as f:
    for d in dirs:
        f.write("mkdir /bigpfs/data/"+d+"/ADJUSTMENT/ARCHIVE/SUCCESS_DELIVERY/\n")
        f.write("mkdir /bigpfs/data/"+d+"/DAILY/ARCHIVE/SUCCESS_DELIVERY/\n")
        f.write("mkdir /bigpfs/data/"+d+"/HOURLY/ARCHIVE/SUCCESS_DELIVERY/\n")
        f.write("mkdir /bigpfs/data/"+d+"/INTRADAY/ARCHIVE/SUCCESS_DELIVERY/\n")
        f.write("mkdir /bigpfs/data/"+d+"/MONTHLY/ARCHIVE/SUCCESS_DELIVERY/\n")
        f.write("mkdir /bigpfs/data/"+d+"/QUARTERLY/ARCHIVE/SUCCESS_DELIVERY/\n")
        f.write("mkdir /bigpfs/data/"+d+"/WEEKLY/ARCHIVE/SUCCESS_DELIVERY/\n")
        f.write("mkdir /bigpfs/data/"+d+"/YEARLY/ARCHIVE/SUCCESS_DELIVERY/\n")

