# -*- coding: utf-8 -*-
"""
Created on Tue Sep 12 14:56:54 2017

@author: Colm Coughlan. Data Science and Solutions. 40631
"""

import os
from dsspy import connections as dsc

def sync(conf_json):
    '''
    Synchronize Hive and BigSQL metadata so that BigSQL will actually notice new/deleted files
    
    :param str conf_json: Solr conf json, contains the jobs metadata information
    :return int: 0
    '''
    
    schema_table = (conf_json['LOADER_METADATA']['TARGET_TABLE']).split('.')
    
    schema = dsc.sql_parse_paramaterisation_not_an_option('\''+schema_table[0]+'\'')
    table = dsc.sql_parse_paramaterisation_not_an_option('\''+schema_table[1]+'\'')
    
    sync = []
    sync.append('''echo "CALL SYSHADOOP.HCAT_CACHE_SYNC('''+schema+''','''+table+''');" | jsqsh -vexit_on=true''')
    sync.append('''echo "CALL SYSHADOOP.HCAT_SYNC_OBJECTS('''+schema+''','''+table+''');" | jsqsh -vexit_on=true''')
    
    for s in sync:
        rt = 0
        rt = os.system(s)
        if rt !=0:
            raise(Exception('Error attempting to sync BigSQL.'))
            
    return 0