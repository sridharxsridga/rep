# -*- coding: utf-8 -*-
"""
Created on Thu Oct 19 17:05:53 2017

@author: Colm Coughlan. Data Science and Solutions. 40631
"""

from dsspy import connections as dsc
from datetime import datetime
from datetime import timedelta
from dsspy import logging as dsl

date_format = '%Y-%m-%d'

def get_run_control_date(args):
    '''
    Get the current run control date from the specified run control date core
    
    :param namespace args: Arguments from argparse
    :return tuple: run_control_date (datetime), run_control_date (string), prev_run_control_date (datetime), prev_run_control_date_str (string)
    '''
    
    try:
        log_file = args.log_file
    except AttributeError as e:
        log_file = None
    
    logger = dsl.getLogger(appname = 'get_run_control_date', log_file = log_file)
    
    
    if args.run_control_date is None:
        solr_url = args.solr_run_control_url.split('select')[0]+'select?q=APPLICATION_NAME:"' + args.appname + '"&wt=json&rows=1'
        contents = dsc.query_solr(solr_url, jceks = args.jceks)
        run_control_date_str = contents['response']['docs'][0]['RUN_CONTROL_DATE']
        logger.info('Run control date recieved from solr: '+run_control_date_str)
    else:
        run_control_date_str = args.run_control_date
        logger.info('Run control date specified manually:'+run_control_date_str)

    if args.prev_run_control_date is None:
        solr_url = args.solr_run_control_url.split('select')[0]+'select?q=APPLICATION_NAME:"' + args.appname + '"&wt=json&rows=1'
        contents = dsc.query_solr(solr_url, jceks = args.jceks)
        prev_run_control_date_str = contents['response']['docs'][0]['PREV_RUN_CONTROL_DATE']
        logger.info('Previous Run control date recieved from solr: '+prev_run_control_date_str)
    else:
        prev_run_control_date_str = args.prev_run_control_date
        logger.info('Previous Run control date specified manually:'+prev_run_control_date_str)

                
    run_control_date = datetime.strptime(run_control_date_str, date_format)
    prev_run_control_date = datetime.strptime(prev_run_control_date_str, date_format)
    
    return run_control_date, run_control_date_str, prev_run_control_date, prev_run_control_date_str

def set_run_control_date(args):
    '''
    Set the current run control date in the specified run control date core. If a new run control date has been manually specified
    it will be used, otherwise the run control date is determined from a combination of the increment type and the extra increment day variables.
    The old RCD is saved in the previous date field.
    
    :param namespace args: Arguments from argparse
    :return int: 0
    '''
    
    logger = dsl.getLogger(appname = 'get_run_control_date', log_file = args.log_file)
    
    # get the old run control date from solr
    solr_url = args.solr_run_control_url.split('select')[0]+'select?q=APPLICATION_NAME:"' + args.appname + '"&wt=json&rows=1'
    contents = dsc.query_solr(solr_url, jceks = args.jceks)
    
    # attempt to assign the job details from SOLR to old_solr_dict
    try:
        old_solr_dict = contents['response']['docs'][0]
        logger.info('Getting job details for ' + args.appname)
    
    # if no job details are found old_solr_dict returns a index out of bounds error
    # return sensible comment as a result and raise an index error
    except Exception as e:

        logger.error('No details received for application: ' + args.appname + ' ensure both the application name and the SOLR url are valid. Solr url: ' + solr_url)
        raise IndexError('No details received for application: ' + args.appname + ' ensure both the application name and the SOLR url are valid. Solr url: ' + solr_url)

    # set the increment and extra increment day so that if the try catch fails to assign either of them they will still be empty strings
    increment = ''
    extra_inc_day = ''

    # find the new run control date.
    # if not specified the run control date will be determined using a combination of the type increment and the extra increment day.
    if args.run_control_date is None:

        # convert the run control date string to a datetime object
        run_control_datetime = datetime.strptime(old_solr_dict['RUN_CONTROL_DATE'], date_format)

        # this try catch is to pass if the job does not contain details of the increment type or extra increment day
        try:
            increment = old_solr_dict['TYPE_INCRMT']
            extra_inc_day = old_solr_dict['EXTRA_INC_DAY']
        except Exception as e:
            pass
        
        # check what type of increment is specified -- will be one of [CURRENT, DAILY, WEEKLY, MONTHLY, '6', '5', '']
        if increment == 'CURRENT':
            # if current is specified the run control date should be updated to the current date
            new_date = datetime.utcnow()
        elif increment == 'DAILY':
            # if daily is specified the run control date should be updated to the next day
            new_date = datetime.strptime(old_solr_dict['RUN_CONTROL_DATE'], date_format) + timedelta(days = 1)
        elif increment == 'WEEKLY':
            # if weekly is specified the run control date should be updated to the next week i.e. same day but a week later
            new_date = datetime.strptime(old_solr_dict['RUN_CONTROL_DATE'], date_format) + timedelta(days = 7)
        elif increment == 'MONTHLY':
            # if monthly is specified the run control date should be updated to the next month on the same day i.e. e.g. '2018-01-24' to '2018-02-24'
            current_date_year = old_solr_dict['RUN_CONTROL_DATE'][0:4]
            current_date_month = old_solr_dict['RUN_CONTROL_DATE'][5:7]
            # if the month is december we need to increment the year and reset the month to january
            if current_date_month == '12':
                new_month = '1'
                current_date_year = str(int(current_date_year) + 1)
            # otherwise just increment the month value
            else:
                new_month = str(int(current_date_month) + 1)                
            new_date = datetime(year=int(current_date_year), month=int(new_month), day=int(old_solr_dict['RUN_CONTROL_DATE'][8:10]))
        elif increment == '6':
            # if 6 is specified it means the job runs 6 days in the week and so there will be a day on which the run control date needs to incremented by 2
            day_of_week = run_control_datetime.strftime('%a') # get the day of the week in the format Mon, Tue, Wed, Thu, Fri, Sat, Sun
            # check if the extra increment day has been specified - if not raise an error as this is required
            if extra_inc_day != '':
                # lowercase the day of week and extra increment day in case it is not written to solr in the right case
                if day_of_week.lower() == extra_inc_day.lower():
                    # increase the run_control_date by 2 days
                    new_date = datetime.strptime(old_solr_dict['RUN_CONTROL_DATE'], date_format) + timedelta(days = 2)
                else:
                    # increase the run_control_date by the usual 1 day
                    new_date = datetime.strptime(old_solr_dict['RUN_CONTROL_DATE'], date_format) + timedelta(days = 1)
            # raise the error
            else:
                error = 'The application: '+args.appname+' has a specified increment type of 6 day however it does not specify the day on which to double the run_control_date. This requires a SOLR update.'
                raise Exception(error)
        elif increment == '5':
            # if 5 is specified it means the job runs 5 days in the week and so there will be a day on which the run control date needs to incremented by 3
            day_of_week = run_control_datetime.strftime('%a') # get the day of the week in the format Mon, Tue, Wed, Thu, Fri, Sat, Sun
            # check if the extra increment day has been specified - if not raise an error as this is required
            if extra_inc_day != '':
                # lowercase the day of week and extra increment day in case it is not written to solr in the right case
                if day_of_week.lower() == extra_inc_day.lower():
                    # increase the run_control_date by 3 days
                    new_date = datetime.strptime(old_solr_dict['RUN_CONTROL_DATE'], date_format) + timedelta(days = 3)
                else:
                    # increase the run_control_date by the usual 1 day
                    new_date = datetime.strptime(old_solr_dict['RUN_CONTROL_DATE'], date_format) + timedelta(days = 1)
            # raise the error
            else:
                error = 'The application: '+args.appname+' has a specified increment type of 5 day however it does not specify the day on which to triple the run_control_date. This requires a SOLR update.'
                raise Exception(error)
         # if none of the above are specified then we throw an error        
        else:
            logger.error('Invalid increment: '+increment+' or extra_inc_day: '+extra_inc_day+' mentioned for application: '+args.appname )
            raise IndexError('Invalid increment: '+increment+' or extra_inc_day: '+extra_inc_day +' mentioned for application: '+args.appname)
    # if the run control date is specified in the args then we update to that date
    else:
        # this try catch is to pass if the job does not contain details of the increment type or extra increment day
        try:
            increment = old_solr_dict['TYPE_INCRMT']
            extra_inc_day = old_solr_dict['EXTRA_INC_DAY']
        except Exception as e:
            pass

        new_date = datetime.strptime(args.run_control_date, date_format) # not strictly necessary, but make sure string is in the right format
        
    # get strings for the new run control date and today's date
    new_date_str = new_date.strftime(date_format)
    load_date_str = datetime.utcnow().strftime(date_format)
    # update the SQL table
    sql_cmd = 'UPDATE '+args.run_control_table+' SET RUN_CONTROL_DATE=\''+new_date_str+'\', PREV_RUN_CONTROL_DATE = \''+old_solr_dict['RUN_CONTROL_DATE']+'\' WHERE APPLICATION_NAME = \''+args.appname+'\';'
    logger.info(sql_cmd)
    conn_str = args.db2_conn_str
    dsc.run_sql(sql_cmd, '', 'bigsql.user', 'bigsql.password', conn_str = conn_str, keystore = args.jceks, getdata = False)

    # update Solr, roll back if there is an error
    try:
        outdict = {'APPLICATION_NAME':args.appname, 'RUN_CONTROL_DATE':new_date_str, 'PREV_RUN_CONTROL_DATE': old_solr_dict['RUN_CONTROL_DATE'],
                   'TYPE_INCRMT': increment, 'EXTRA_INC_DAY': extra_inc_day, 'LOAD_DATE': load_date_str, 'SOURCE_INST':old_solr_dict['SOURCE_INST'],
                   'SOURCE_SYS': old_solr_dict['SOURCE_SYS']}
        logger.info('Updating solr core at '+solr_url)
        dsc.write_to_solr(solr_url, outdict, jceks = args.jceks)
        
    except Exception as e:
        
        logger.error('Error trying to update run control date in solr, rolling back sql version')
        sql_cmd = 'UPDATE '+args.run_control_table+' SET RUN_CONTROL_DATE=\''+old_solr_dict['RUN_CONTROL_DATE']+'\', PREV_RUN_CONTROL_DATE = \''+old_solr_dict['PREV_RUN_CONTROL_DATE']+'\' WHERE APPLICATION_NAME = \''+args.appname+'\';'
        dsc.run_sql(sql_cmd, '', 'bigsql.user', 'bigsql.password', conn_str = conn_str, keystore = args.jceks, getdata = False)
        raise
        
    return 0