from dsspy import connections as dsc
from dsspy import utilities as dsu
from dsspy import logging as dsl
from data_pipeline_lib.utils import get_count, get_export_sqoop_metadata, get_ordered_columns
from datetime import datetime
import argparse
import getpass
import os
import warnings
try:
    import jks
except:
    warnings.warn('No JKS module found. JKS functionality unavailable', ImportWarning)
    have_jks = False
else:
    have_jks = True

def hive_staging_insert(conf_json, previous_rcd, current_rcd,job_id, args):
    '''
    Inserts the latest records from the raw zone production table (parquet) to a hive staging table (textfile) in order to Sqoop to Teradata.
    Truncates table at the start. Validates that the counts are the same in the raw zone and staging table at the end. 
    
    :param str conf_json: Solr conf json, contains the jobs metadata information
    :param str previous_rcd: The previous run control date
    :param str current_rcd: The current run control date
    :param str job_id: Solr id for the job
    :param str args: The arguments passed down from data_pipeline.py
    :return 0 if insert successful. 1 if insert failed. 
    '''
    keystore = args.jceks
    jobname = args.job_name

    logger = dsl.getLogger(appname = args.job_name, log_file = args.log_file)

    #gathering the metadata from the solr json. Including gettin an ordered list of columns to define the hive select portion of the insert statement.
    metadata = get_export_sqoop_metadata(conf_json, args)[job_id]
    columns = get_ordered_columns(conf_json, args)

    #truncate table. This job shouldn't kick off unless the complete job signal has been given from downstream. Therefore should be ok to truncate at the start.
    truncate_stmt = '''
hive -e "TRUNCATE TABLE '''+metadata['hive_staging_schema']+'''.'''+metadata['hive_staging_table']+''';"'''

    hive_hostname = metadata['hostname']
    #syncing between hive and bigsql
    repair_stmt = 'MSCK REPAIR TABLE ' + metadata['hive_staging_schema'] + "." + metadata['hive_staging_table'] + ";"

    
    dsc.run_sql(repair_stmt, hive_hostname, 'bigsql.user', 'bigsql.password', keystore = args.jceks) 

    rt = os.system(truncate_stmt) # truncate the hive table
    if rt !=0:
        raise(Exception('Hive staging truncate error: '+jobname))
        result = rt

    #wrapping run control dates with '' so they come out with the format '2017-09-20' to make defining the hive stmts easier
    previous_rcd_str = "'"+previous_rcd+"'" 
    current_rcd_str = "'"+current_rcd+"'"

    #defining table definition from ordered columns for select from prod table
    table_def = ""
    for col in columns:
        table_def += col +",\n"
    table_def = table_def[:-2]+"\n".strip()
    
    hive_rz_stmt = "SELECT COUNT(*) FROM " + metadata['hive_rz_schema'] + "." + metadata['hive_rz_table'] + " WHERE PERIOD_DTE >= "+previous_rcd_str+" AND PERIOD_DTE < "+current_rcd_str+";"
    hive_stg_stmt = "SELECT COUNT(*) FROM " + metadata['hive_staging_schema'] + "." + metadata['hive_staging_table'] + ";"

    hive_insert_stmt = '''
hive -e "INSERT INTO '''+metadata['hive_staging_schema']+'''.'''+metadata['hive_staging_table'] +''' SELECT \n'''+table_def+'''\nFROM '''+metadata['hive_rz_schema']+'''.'''+metadata['hive_rz_table']+''' WHERE PERIOD_DTE >= '''+previous_rcd_str+''' AND PERIOD_DTE < '''+current_rcd_str+''';"'''

    '''
    Following is a workaround for Agent Desktop Services. 1 raw zone table needs to go to 3 staging tables, split by division. 
    SRCE_INST = 1 for ROI, SRCE_INST = 2, for FT, SRCE_INST = 3, for GB
    If srce_inst is specified in call to data_pipeline in TWS job then an addition clause will be added to the sql statements.
    srce_inst ONLY needs to be specified for the Agent Desktop Services jobs. 
    '''
    if args.srce_inst is not None:
        hive_rz_stmt = hive_rz_stmt[0:-1] + ' AND SRCE_INST = ' + args.srce_inst + ';'
        hive_insert_stmt = hive_insert_stmt[0:-2] + ' AND SRCE_INST = ' +args.srce_inst +';"'

    logger.info("Hive raw zone statement " + hive_rz_stmt)
    logger.info("Hive staging statement " + hive_stg_stmt)

    #counting records in hive raw zone table
    hive_rz_count = get_count(hive_rz_stmt,hive_hostname,'bigsql.user', 'bigsql.password', keystore = args.jceks)

    #checking if the staging table is empty
    hive_stg_pre_count = get_count(hive_stg_stmt,hive_hostname, 'bigsql.user', 'bigsql.password', keystore = args.jceks)
    if hive_stg_pre_count != 0:
        raise(Exception('Hive staging insert error: '+jobname +'\nStaging table not empty'))
        result = 1

    rt = os.system(hive_insert_stmt) # run the hive job
    if rt !=0:
       raise(Exception('Hive staging insert error: '+jobname))
       result = rt
    dsc.run_sql(repair_stmt, hive_hostname, 'bigsql.user', 'bigsql.password', keystore = args.jceks) 
    hive_stg_count = get_count(hive_stg_stmt, hive_hostname, 'bigsql.user', 'bigsql.password', keystore = args.jceks)
    logger.info('Hive raw zone record count : ' + str(hive_rz_count))
    logger.info('Hive staging record count : ' + str(hive_stg_count))
    if hive_stg_count != hive_rz_count:
        raise(Exception('Hive insert validation error: ' + jobname + '\nRecord counts do not match'))
        result = 1
    elif hive_stg_count == 0:
        raise(Exception('Hive insert validation error: ' + jobname + '\nZero records transferred'))
        result = 1
    else:
        logger.info('Hive insert successful: '+jobname)
        result = rt
    return result
