# -*- coding: utf-8 -*-
"""
Created on Tue Sep 12 14:01:49 2017

@author: Colm Coughlan. Data Science and Solutions. 40631
"""

import os
from dsspy import utilities as dsu
import glob
from subprocess import Popen, PIPE
from data_pipeline_lib.utils import get_used_ports
from random import randint
from dsspy import logging as dsl
import time
from random import uniform


def acquire(conf_json, run_control_date, jobname, args):
    '''
    Find the JAR for the metadata driven acquisition app (version specific, if version is supplied) and call it
    
    :param str conf_json: Solr conf json, contains the jobs metadata information
    :param datetime run_control_date: Current run control date, as a python datetime object
    :param str jobname: Unique job name (full name with time etc.)
    :param namespace args: Arguments from argparse
    :return tuple: code, log. code = 0 for success
    '''
    
    logger = dsl.getLogger(appname = args.job_name, log_file = args.log_file)
    
    # wait a random amount of time so as not to overload spark
    
    time.sleep(uniform(0,1))
    
    # get the jceks location
        
    if args.jceks is not None:
        jceks = 'jceks://file'+args.jceks
    else:
        jceks = 'nojceks'
        
    if args.jar_path is not None and args.log4j_path is not None:
        jar_path = args.jar_path
        log4j_props = args.log4j_path
    else:
        raise Exception('Need to specify jar_path and log4j_path as argument in this mode.')

    # identify jar
    
    jar_version =  conf_json['FileEvalutor']['JAR_VERSION'] if 'JAR_VERSION' in conf_json['FileEvalutor'] else 'default'

    spark_path = os.path.join(jar_path, jar_version) # point to the directory
    spark_path = os.path.join(spark_path,'*.jar') # point to all jars in directory
    spark_jar = glob.glob(spark_path) if spark_path.split('/')[1] in ['bigpfs','opt','home'] else dsu.hdfs_op('ls', spark_path) # for hdfs stored jar
    if len(spark_jar) < 1:
        logger.warn('Warning: Failed to find jar of specified version '+jar_version+' at path '+spark_path)
        spark_path = os.path.join(jar_path, 'default')
        spark_path = os.path.join(spark_path,'*.jar')
        spark_jar = glob.glob(spark_path) if os.path.sep+'bigpfs'+os.path.sep in spark_path else dsu.hdfs_op('ls', spark_path)
        if len(spark_jar) == 1:
            spark_jar = spark_jar[0]
            logger.warn('Failing back to default JAR at '+spark_jar)
        else:
            logger.warn('Attempt to fall back to default JAR failed because multiple JARs were discovered at '+spark_path)
            raise(os.error)
    elif len(spark_jar) > 1:
        logger.error('Error: Found '+str(len(spark_jar))+' jars at '+spark_path+', expected exactly 1.')
        raise(os.error)
    else:
        spark_jar = spark_jar[0] # get the path to the jar
        logger.info('Using jar '+spark_jar)
        
    # get the run_control date in the correct format for the period date
    period_date_format = conf_json['LOADER_METADATA']['PARTITIONS']['period_dte']['format'] # use the output format
    if len(period_date_format) < 1:
        raise Exception('No period date format defined')
    py_period_date_format = period_date_format.replace('yyyy','%Y').replace('MM','%m').replace('dd','%d')
    run_control_date_str = run_control_date.strftime(py_period_date_format)  
        
    # find a good port
    
    used_ports, lowest_port, highest_port = get_used_ports()
    port = used_ports[0]
    while port in used_ports:
        port = randint(lowest_port, highest_port)
        
    # create solr url
    if '*' not in args.search_term:
        solr_url = args.solr_url.split('select')[0]+'select?q=id%3A"'+args.search_term+'"'
    else:
        solr_url = args.solr_url.split('select')[0]+'select?q=id%3A'+args.search_term
        
    # prepare logging file (currently assume POSIX-compliant)
    
    # dsu.hdfs_op() # use this if JAR is in HDFS
    
    log4j_props_final = '/tmp/' + jobname + '_logs.properties'
    logger.info('Creating temporary logs properties file at '+log4j_props_final)
    
    with open(log4j_props_final, 'w') as fout:
        with open(log4j_props) as fin:
            lines = fin.readlines()
            for line in lines:
                if 'log4j.appender.file.File=' in line :
                    fout.write('log4j.appender.file.File='+args.log_file+'\n')
                else:
                    fout.write(line)

    # run job
    cmd = 'spark-submit --name '+jobname+' --driver-java-options "-Dlog4j.configuration=file:'+log4j_props_final \
    + '" --conf spark.ui.port='+str(port)+' --master yarn-client --class ie.aib.data.acquisition.Run.SparkReaderApp ' \
    + spark_jar+' '+solr_url+' "'+jobname+'" '+run_control_date_str+' '+log4j_props_final+' '+jceks

    logger.info(cmd)
    proc = Popen(cmd.split(), stdout=PIPE, stderr=PIPE)
    comms = proc.communicate() # note this waits for completion
    log = cmd + '\n' + comms[0].decode('utf-8') + comms[1].decode('utf-8')
    if args.debug:
        logger.info(log)
    ret = proc.returncode
    
    try:
        os.remove(log4j_props_final)
        logger.info('Temporary logs properties file removed')
    except:
        logger.warn('Temporary logs properties file appeared to have already been cleaned')
        
    return ret, log