# -*- coding: utf-8 -*-
"""
Created on Mon Sep 11 14:35:44 2017

@author: Colm Coughlan. Data Science and Solutions. 40631
"""

import re
import os
from dsspy import utilities as dsu
from dsspy import connections as dsc
from data_pipeline_lib.batch_control import date_format
from dsspy import logging as dsl
from datetime import datetime, date, timedelta


def get_valid_files(in_dir, regex_str, target_date, file_date_format, file_date_offset, reject_dir, args):
    '''
    :Identify Valid Files:

    :Validation checks the following:
        - Files exist in directory
        - Files in the directory match the regex for the expected filename
        - A 'success' file exists for all valid files
        - The date in the filename matches the run control date minus the offset
    
    :Exceptions are raised for the following reasons:
        - If no files exist in the directory.
        - If no file in the directory matches the regex.
        - If any valid files do not have a respective 'success' file.
        - If no filename contains the appropriate date
    
    :param: *str* :in_dir: Directory with success file in it \n
    :param: *str* :regex_str: Regex for valid files (from metadata) \n
    :param: *datetime* :target_date: Run control date \n
    :param: *str* :file_date_format: File date format (regex, from metadata) \n
    :param: *str* :reject_dir: Directory for rejected files \n
    :param: *namespace* :args: Arguments from argparse \n

    :return: *list* :valid_files:
    '''

    logger = dsl.getLogger(appname = args.job_name, log_file = args.log_file) # initialise the logger

    in_files = dsu.hdfs_op('ls', in_dir) #  get all the files in the IN directory
    if len(in_files) == 0: # if no files exist
        raise Exception('No files found in '+in_dir) # raise an exception
    
    py_regex_str = regex_str.replace('\\.','.').replace('(?<','(?P<') # convert the regex to a form suitable for python
    py_regex_str = in_dir + py_regex_str if in_dir[-1] == '/' else in_dir + '/' + py_regex_str
    regex = re.compile(py_regex_str) # main file regex
    
    target_files = list(filter(regex.match, in_files)) # get only the files that match the regex
    other_files_in_dir = list(set(in_files).difference(set(target_files))) # any files that don't match the regex

    if len(target_files) == 0: # if no files match the regex
        raise Exception('No files matching '+regex_str+' detected in GPFS/HDFS directory '+in_dir)
    
    valid_files_im = [] # Creating intermediate list for valid files.

    py_file_date_format = file_date_format.replace('yyyy','%Y').replace('MM','%m').replace('dd','%d') # get the python equivalent of the file date format using a replace
    run_control_dte = target_date.date() # get the date from the target date which is formatted as datetime
    file_date = run_control_dte + timedelta(days=int(file_date_offset)) # get expected file date by going back the 'offset' number of days from the run_control_dte
    file_date_str = file_date.strftime(py_file_date_format) # convert the expected file date to a string for comparison

    for target in target_files: # loop through files in directory and match any files that contain a date that matches the expected file date
        if file_date_str in target: # if the date is found in the filename
                valid_files_im.append(target) # append the file to valid_files_im
                      
    if len(valid_files_im) == 0: # if there are no valid files
        logger.info('No valid files for run date '+str(run_control_dte)+' found in '+in_dir)
        raise Exception('No valid files for run date '+str(run_control_dte)+' found in '+in_dir)

    success_files = []

    for file in other_files_in_dir:
        # if the file is a SUCCESS file
        if os.path.basename(os.path.normpath(file))[0:7] == 'SUCCESS':
            # append it to an array
            success_files.append(file) # add all the success files to the success_file array
        else:
            # else log a warning that an unexpected file exists in the directory
            logger.warn('Unexpected file in: '+in_dir+'   filename: '+file)
    reject_files = []
    
    valid_files = [] # final list for valid files
    # if a corresponding success file do not exist for a valid file then that file should be rejected
    for valid_file in valid_files_im: # loop through the valid files
        if any (valid_file.split('/')[-1] in success_file for success_file in success_files): # if the valid file has equivalent success file continue 
            valid_files.append(valid_file) #append to valid_files
        else:
            reject_files.append(valid_file) # else add the file to the reject directory
    if len(reject_files) != 0: # if files have been rejected
        logger.info('The following files ' +str(reject_files)+ ' detected in ' +in_dir+ ' have no respective success files')
        logger.info('Moving the files to '+reject_dir)
        for reject in reject_files:
            dsu.hdfs_op('mv', reject, reject_dir)
        raise Exception('Failing due to rejected files.') # move rejected files to REJECT and throw an error

    return valid_files
    
def process_success_file(target_file, in_dir, success_archive_dir):
    '''
    Move success files to archive
    
    :param str target_file: Name of data file
    :param str in_dir: Directory with success file in it
    :param str success_archive_dir: Archive directory for success files

    :return int: 0
    '''
    
    success_file = 'SUCCESS_' + target_file.split(os.path.sep)[-1]
    success_file_fp = os.path.join(in_dir, success_file)
    success_file_dest = os.path.join(success_archive_dir, success_file)
    
    dsu.hdfs_op('mv', success_file_fp, success_file_dest)
        
    return 0
    

def validate(conf_json, run_control_date, args):
    '''
    Make sure that any files in the IN directory have the correct format. N.B. currently does not really validate! It just confirms the file exits.
    
    :param str conf_json: Solr conf json, contains the jobs metadata information
    :param datetime run_control_date: Current run control date, as a python datetime object
    :param namespace args: Arguments from argparse

    :return int: The number of valid files found
    '''
    
    in_dir = conf_json['FileEvalutor']['IN_FILE_LOCATION']
    out_dir = conf_json['FileEvalutor']['IN_PROGRESS_FILE_LOCATION']
    reject_dir = conf_json['FileEvalutor']['REJECT_FILE_LOCATION']
    extract_file_name = conf_json['FileEvalutor']['FILE_NAME_EXTRACT']
    
    archive_dir = conf_json['LOADER_METADATA']['ARCHIEVE_FILE_LOCATION']
    success_archive_dir = os.path.join(archive_dir, 'SUCCESS_DELIVERY')
    file_date_format = conf_json['LOADER_METADATA']['FILE_DATE_FORMAT']
    file_date_offset = conf_json['LOADER_METADATA']['FILE_DATE_OFFSET']
    
    
        
    valid_files = get_valid_files(in_dir, extract_file_name, run_control_date, file_date_format, file_date_offset, reject_dir, args)
    
    if len(valid_files) == 0:
        raise(Exception('Validation: No valid files detected.'))
    
    for target in valid_files:
        process_success_file(target, in_dir, success_archive_dir)
        dsu.hdfs_op('mv', target, out_dir)
    
    return len(valid_files)

def post_validate(conf_json, run_control_date, keystore, args):
    '''
    Validates that the records written in the latest job is within 2 standard deviations of the mean of previous record counts written on that day of the week.
    Approximate normal distribution then 95% of the data values are within 2 standard deviations. 
    Meaning if the record counts are 2 standard deviations from the mean there is only a 5 % chance this is a normal load. 
    If the record counts are 3 standard deviaitons from the mean there is only a 0.3 % chance this is a normal load.


    :param str conf_json: Solr conf json, contains the jobs metadata information
    :param str run_control_date: The current run control date passed as a datetime object
    :param str keystore: The path to the appropriate java keystore
    :param str args: The arguments passed down from data_pipeline.py
    
    :return int: 0 if the record count is within 2 standard deviations, 2 if it is between 2 and 3 standard deviations and logs a warning so that particular load can be investigated, 3 if it is greater than 3 standard deviations and logs a warning so the load can be investigated.
    '''

    logger = dsl.getLogger(appname = args.job_name, log_file = args.log_file)
    

    hostname = conf_json['LOADER_Resource']['NAME_NODE'].split('/')[2]

    dq_table_level = conf_json['LOADER_METADATA']['TABLELEVEL_QUALITY_TABLENAME'] #SCHEMA.TABLE
    #dq_schema = dq_table_level.split(".")[0]
    dq_schema = 'HDMWV00P' # hardcoded for testing with test_data_batch
    db2_dq_table = dq_table_level.split(".")[-1]
    hv_dq_table = db2_dq_table.replace('D2','HV')
    tabname = conf_json['LOADER_METADATA']['TARGET_TABLE'].split(".")[-1]
    job_name = args.job_name.split('_JOB_')[0]
    tabschema = conf_json['LOADER_METADATA']['TARGET_TABLE'].split(".")[0]
    
    

    #run_control_date is passed around as a datime object
    target_date_str =  run_control_date.strftime(date_format)

    current_count_stmt = "SELECT NUM_RECORDS_WRITTEN FROM "+dq_schema+"."+db2_dq_table + " WHERE TABSCHEMA = '"+tabschema+"' AND JOB_NAME LIKE '%"+job_name+"%' AND RUN_CONTROL_DATE = '"+target_date_str+"' ORDER BY LOAD_TIME DESC;"
    mean_std_dev_stmt = "SELECT AVG(NUM_RECORDS_WRITTEN), STDDEV_SAMP(NUM_RECORDS_WRITTEN) FROM "+dq_schema+"."+hv_dq_table + " WHERE TABSCHEMA = '"+tabschema+"' AND JOB_NAME LIKE '%"+job_name+"%' AND RUN_CONTROL_DATE > DATE('"+target_date_str+"') - 6 MONTHS AND DAYOFWEEK(RUN_CONTROL_DATE) = DAYOFWEEK(DATE('"+target_date_str+"'));"
    logger.info('The following SQL statements calculate statistics')
    logger.info(current_count_stmt)
    logger.info(mean_std_dev_stmt)

    current_count = dsc.run_sql(current_count_stmt,hostname, 'bigsql.user', 'bigsql.password', keystore, getdata=True)
    mean_std_dev = dsc.run_sql(mean_std_dev_stmt,hostname, 'bigsql.user', 'bigsql.password', keystore, getdata=True)
    logger.info('Length of current log is :' + str(len(current_count)))
    logger.info('Length of historic logs is :' + str(len(mean_std_dev)))
    if len(current_count) == 0 or len(mean_std_dev) == 0:
        logger.info('Could not find sufficient logs to calculate statistics')
        result = 0
    else:
        current_count = float(current_count.values[0][0])
        mean = float(mean_std_dev.values[0][0])

        std_dev = float(mean_std_dev.values[0][1])
        if std_dev == 0.0:
            sig = 0
        else:
            sig = (current_count - mean)/std_dev

        logger.info('Post validation for table: '+ tabname+'. '+str(current_count)+ ' records written on '+ target_date_str + ' for job:'+ job_name)
        logger.info('Post validation for table: '+ tabname+'. '+str(mean) + ' is the average written over the last six months for the same day of the week.')
        if abs(sig) < 2:
            logger.info('Post validation for table: '+ tabname+'. Sigma value: '+str(sig) +'. This is a healthy load')
            result = 0
        elif abs(sig) < 3:
            logger.warn('Post validation for table: '+ tabname+'. Sigma value: '+str(sig) +'. Record count slightly outside normal, requires investigation.')
            result = 2
        else:
            result = 3
            logger.warn('Post validation for table: '+ tabname+'. Sigma value: '+str(sig) +'. Record count far outside normal.')

    return result
    


