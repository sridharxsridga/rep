# -*- coding: utf-8 -*-
"""
Created on Tue Sep 12 15:31:24 2017

@author: Colm Coughlan. Data Science and Solutions. 40631
"""

from subprocess import check_output
from datetime import datetime
import socket
from dsspy import connections as dsc
import ast
from dsspy import logging as dsl
import json
import pandas as pd

start_of_log_text = '##--## Starting Acqusition Pipeline'

def get_used_ports():
    '''
    Return the ports currently in use on the system via netstat 
    
    :return tuple: A tuple of ports in use, the lowest port available and the highest port available
    '''
    
    lowest_port = 1024
    highest_port = 65335
    
    cmd = 'netstat -lat'
    vals = check_output(cmd, shell=True).decode('ascii').split('\n')
    ports = []
    
    bad_val = False

    for val in vals:
        try:
                add = val.split()[-2]
                port = add.split(':')[-1]
                ports.append(int(port))
        except:
                bad_val = True

    ports = sorted(ports)

    return ports, lowest_port, highest_port
    
    
# use minimal logging when most of the normal logging parameters won't be defined (minimal = True)
def post_log(args, job_id, job_name, conf, outcome, start_time, end_time, solr_core, period_date, run_control_date, minimal = False):
    '''
    Post a log from a file to solr and bigsql
    
    :param str args: The arguments passed down from data_pipline
    :param str job_id: The unique job ID
    :param str job_name: The name of the job in the metadata core (not unique by time, step etc.)
    :param str conf: Solr conf json, contains the jobs metadata information
    :param boolean outcome: True for success, false for failure
    :param datetime start_time: The job start time as a datetime object
    :param datetime end_time: The job end time as a datetime object
    :param str solr_core: The solr metadata core used for the job
    :param datetime period_date: The period date as a datetime object
    :param datetime run_control_date: The run control date as a datetime object (same as period date often (always?))
    :param boolean minimal: If true, only write a minimal log. Useful for early stage logs etc.

        
    :return int: Return code of final write to bigsql. 0 if successful.
    '''
    
    logger = dsl.getLogger(appname = args.job_name, log_file = args.log_file)
    
    app_id = args.appname
    
    maxchars_solr = 10000 # trim the log for solr
    maxchars_sql = 1000 # trim the log for SQL (should be smaller than solr)
    
    null = ''
    ctime = datetime.utcnow()
    host = socket.gethostname()
    vstart_time = start_time.strftime("%Y-%m-%d %H:%M:%S").replace(' ','T') + 'Z'
    vend_time = end_time.strftime("%Y-%m-%d %H:%M:%S").replace(' ','T') + 'Z'
    diff = str(int((end_time - start_time).total_seconds())) # just get the seconds part
    tsolr_core = solr_core.split('select')[0]
    
    # read in full log
    
    with open(args.log_file) as fin:
        historic_log = fin.readlines()
            
    clog = []
    for line in reversed(historic_log):
        clog.append(line)
        if start_of_log_text in line:
            break
    clog = ''.join(reversed(clog))
    # cut the log down to useful parts if it's very long, regardless of whether or not it has been successful
    
    if len(clog) > maxchars_solr:
        clog = clog[-maxchars_solr:]
    
    # bash command to get most recent finished spark job details from yarn
    if minimal:
        
        srce_inst = -1 # not available if the scheduler itself has failed for some reason. Scheduler not in srce_inst list, so use -1
        srce_sys = -1 # but needed for the partitions! (try not to have nulls)
        
        log = {'id':job_id, 'job_name':job_name, 'success_ind':str(outcome), 'solr_core':tsolr_core
        ,'start_time':vstart_time, 'end_time':vend_time, 'job_time_in_seconds':diff, 'work_station':host
        , 'log_date':ctime.strftime("%Y-%m-%d"), 'run_control_date':run_control_date.strftime("%Y-%m-%d")
        , 'log_time': str(int(ctime.timestamp())), 'app_id':app_id, 'output_log':clog, 'srce_sys':srce_sys
        , 'srce_inst':srce_inst, 'period_dte':period_date.strftime("%Y-%m-%d"), 'load_dte':end_time.strftime("%Y-%m-%d"), 'load_time':str(int(end_time.timestamp()))}

    else:
        
        '''
        history_cmd = 'yarn application -appStates FINISHED -appTypes SPARK -list | grep \''+job_id+'\' | awk \'{if(NR>2)print}\'|sort -r| awk \'{if(NR==1)print}\''
        history = check_output(history_cmd, shell=True).decode('ascii').split('\t') # using shell = true here to exec the bash string. Ok as not exposed to user.
        spark_app_id = history[0]
        history_url = history[-1]
        '''
        srce_sys = conf['LOADER_METADATA']['PARTITIONS']['srce_sys']['value'] if 'LOADER_METADATA' in conf else '-1'
        srce_inst = conf['LOADER_METADATA']['PARTITIONS']['srce_inst']['value'] if 'LOADER_METADATA' in conf else '-1'
    
        # solr needs the job name + time, then the log
        

                
        log = {'id':job_id, 'job_name':job_name, 'success_ind':str(outcome), 'solr_core':tsolr_core, 'dependencies':null
        ,'start_time':vstart_time, 'end_time':vend_time, 'job_time_in_seconds':diff, 'work_station':host, 'operation_no':null, 'successor_name':null
        , 'successor_appl_name':null, 'successor_work_station':null, 'successor_opr_no':null, 'run_control_date':run_control_date.strftime("%Y-%m-%d"), 'log_date':ctime.strftime("%Y-%m-%d")
        , 'log_time': str(int(ctime.timestamp())), 'app_id':app_id, 'output_log':clog, 'srce_sys':srce_sys
        , 'srce_inst':srce_inst, 'period_dte':period_date.strftime("%Y-%m-%d"), 'load_dte':end_time.strftime("%Y-%m-%d"), 'load_time':str(int(end_time.timestamp()))}


    # write out to solr
    try:
        dsc.write_to_solr(args.solr_logging_url, log, jceks = args.jceks)
    except:
        try:
            logger.warn('Error writing large solr log. Attempt to write last '+str(maxchars_sql)+' characters.')
            log['output_log'] = clog[-maxchars_sql:]
            dsc.write_to_solr(args.solr_logging_url, log, jceks = args.jceks, jceks_pass = args.jceks_pass)
        except:
            try:
                logger.warn('Error writing smaller Solr log. Falling back.')
                log['output_log'] = 'Solr log could not be processed. See '+args.bigsql_logging_table+' for details.'
                dsc.write_to_solr(args.solr_logging_url, log, jceks = args.jceks, jceks_pass = args.jceks_pass)
            except:
                logger.error(args.solr_logging_url)
                logger.error(log)
                logger.error(args.jceks)
                logger.error('Error writing to solr. No attempt to write actual log succeeded.')
                logger.error('Attempted core: '+args.solr_logging_url)
                
        log['output_log'] = clog[-maxchars_sql:] # restore the full log for SQL logging
        
    # now that the solr log has been posted, should also write to DQ table with JSQSH (for the moment - need to get a better solution)
    bigsql = args.bigsql_logging_table.split('.')
    schema = dsc.sql_parse_paramaterisation_not_an_option(bigsql[0])
    tablename = dsc.sql_parse_paramaterisation_not_an_option(bigsql[1])
    sql_cmd = 'INSERT INTO '+schema+'.'+tablename+' ('
    sql_values = []
    for key, value in log.items():
        if key != 'id':
            sql_cmd = sql_cmd + dsc.sql_parse_paramaterisation_not_an_option(key)  + ''',''' # like to have this peer reviewed, should be parameterised (like the values), but doesn't seem to work
            if key == 'output_log':
                sql_values.append(value[-maxchars_sql:])
            elif key == 'success_ind':
                sql_values.append(str(int(ast.literal_eval(value))))
            elif key in ['log_time', 'load_time']:
                sql_values.append(datetime.fromtimestamp(int(value)).strftime("%Y-%m-%d %H:%M:%S"))
            elif key in ['start_time','end_time']:
                sql_values.append(value.replace('T',' ')[0:-1])
            elif key in ['job_time_in_seconds','srce_sys','srce_inst']:
                sql_values.append(value)
            else:
                sql_values.append(value)
        
    sql_cmd = sql_cmd[0:-1] + ') VALUES ('
    
    for key, value in log.items():
        if key != 'id':
            sql_cmd = sql_cmd   + '''?,'''
            
    sql_cmd = sql_cmd[0:-1] + ');' # remove trailing comma

    if 'LOADER_Resource' in conf:
        hostname = (conf['LOADER_Resource']['NAME_NODE'].split('//')[1]).split('/')[0]
    else:
        hostname = (conf['CONNECTION_STRING'].split('HOSTNAME=')[1]).split(';')[0]
    ret = dsc.run_sql(sql_cmd, hostname, 'bigsql.user', 'bigsql.password', keystore = args.jceks, getdata = False, params = sql_values)
    
    return(ret)

def get_export_sqoop_metadata(conf_json, args):
    '''
    Grabs the specific metadata needed for the export sqoop jobs.abs

    :param str conf_json: Solr conf json, contains the jobs metadata information
    :param str args: The arguments passed down from data_pipline
    
    :return dict: targets,which is a dictionary of the metadata information
    '''

    logger = dsl.getLogger(appname = args.job_name, log_file = args.log_file)

    targets = {}    
    name = args.job_name
    try:
        hive_raw_zone = conf_json['LOADER_METADATA']['TARGET_TABLE'].split('.')
        hive_rz_table = hive_raw_zone[-1]
        hive_rz_schema = hive_raw_zone[0]
        hive_staging = conf_json['LOADER_METADATA']['STAGING_TABLE'].split('.')
        hive_staging_table = hive_staging[-1]
        hive_staging_schema = hive_staging[0]
        edw_db = conf_json['LOADER_METADATA']['EDW_TARGET_DB']
        edw_table = conf_json['LOADER_METADATA']['EDW_TARGET_TABLE']
        hostname = conf_json['LOADER_Resource']['NAME_NODE'].split('/')[2]
        
        if edw_table != '' and edw_db != '':
            logger.info('Adding sqoop for job '+ args.job_name)
            targets[name] = {'id':name, 'hive_rz_table':hive_rz_table, 'hive_rz_schema':hive_rz_schema, 'hive_staging_table':hive_staging_table, 'hive_staging_schema':hive_staging_schema, 'edw_db':edw_db, 'edw_table':edw_table, 'hostname':hostname}
        else:
            raise Exception('Sqoop settings null in metadata for job '+name)
    except KeyError as e:
        raise Exception('No Sqoop variables present in metadata found for job '+name)
        
    return targets

def get_import_sqoop_metadata(conf_json, args):
    '''
    Grabs the specific metadata needed for the import sqoop jobs.abs
    
    :param str conf_json: Solr conf json, contains the jobs metadata information
    :param str args: The arguments passed down from data_pipline
    
    :return dict: targets, which is a dictionary of the metadata information
    '''

    logger = dsl.getLogger(appname = args.job_name, log_file = args.log_file)

    targets = {}    
    name = args.job_name
    try:
        hive_parquet = conf_json['LOADER_METADATA']['TARGET_TABLE'].split('.')
        hive_pq_table = hive_parquet[-1]
        hive_pq_schema = hive_parquet[0]
        hive_staging = conf_json['LOADER_METADATA']['STAGING_TABLE'].split('.')
        hive_staging_table = hive_staging[-1]
        hive_staging_schema = hive_staging[0]
        edw_db = conf_json['LOADER_METADATA']['EDW_TARGET_DB']
        edw_table = conf_json['LOADER_METADATA']['EDW_TARGET_TABLE']
        hostname = conf_json['LOADER_Resource']['NAME_NODE'].split('/')[2]
        split_col = conf_json['LOADER_METADATA']['EDW_PRIMARY_INDEX_COL']
        textfile_delimiter = conf_json['LOADER_METADATA']['DELIMITER']
        
        if edw_table != '' and edw_db != '':
            logger.info('Adding sqoop for job '+ args.job_name)
            targets[name] = {'id':name, 'hive_pq_table':hive_pq_table, 'hive_pq_schema':hive_pq_schema
                            , 'hive_staging_table':hive_staging_table, 'hive_staging_schema':hive_staging_schema, 'edw_db':edw_db
                            , 'edw_table':edw_table, 'hostname':hostname, 'split_col':split_col, 'target_file_location':target_file_location
                            ,'textfile_delimiter':textfile_delimiter}
        else:
            raise Exception('Sqoop settings null in metadata for job '+name)
    except KeyError as e:
        raise Exception('No Sqoop variables present in metadata found for job '+name)
        
    return targets

def get_ordered_columns(conf_json, args):
    '''
    Queries the solr metadata and orders the fields and partitions in the sequence they are provided in the BRD.
    This is to generate insert statments for the hive staging tables

    :param str conf_json: Solr conf json, contains the jobs metadata information
    :param str args: The arguments passed down from data_pipline
    
    :return list: formatted_columns, a list of the columns in the table
    '''

    logger = dsl.getLogger(appname = args.job_name, log_file = args.log_file)

    columns_metadata = {}
    formatted_columns = []

    try:
        partitions = conf_json['LOADER_METADATA']['PARTITIONS']
        added_columns = conf_json['LOADER_METADATA']['ADDED_COLUMNS']
        fields = conf_json['LOADER_METADATA']['FIELDS']
    except KeyError as e:
        raise Exception('No column information present in metadata found for job '+args.job_name)

    columns_metadata.update(fields)
    columns_metadata.update(added_columns)
    columns_metadata.update(partitions)

    columns = {col.upper(): int(columns_metadata[col]['target_position']) for col in columns_metadata}
    columns_series = pd.Series(columns)
    formatted_columns = columns_series.sort_values().index.tolist()

    return formatted_columns

def get_count(stmt,hostname,user,pwd, keystore= None):
    '''
    Runs a count(*) sql statment on hive (or Teradata, but connector currently doesn't work for Teradata) and returns a formated count as an integer

    :param str stmt: The sql statement to run
    :param str hostname: the Hadoop/Teradata hostname to use. See dsspy docs section on run_sql for correct use
    :param str user: The username the run the sql statement under
    :param str pwd: The corresponding password for the above username
    :param str keystore: The java keystore containing the username and password of the user to run the sql queries. Defaults to None. 
    
    :return int: The count
    '''
    data = int(dsc.run_sql(stmt, hostname, user , pwd, keystore, getdata=True).values)
    return data

