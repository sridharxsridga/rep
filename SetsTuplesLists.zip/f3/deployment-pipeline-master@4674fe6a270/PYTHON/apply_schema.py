# -*- coding: utf-8 -*-
"""
Created on Fri Oct 14 14:20:24 2016

This script applies a schema and path to SQL files in a directory:

Inputs (command line):
    1. Schema name. (also used as path name)
    2. Directory name
    
Outputs:
    Edits all SQL files in directory (ending with SQL - case insensitive)
    Reports files and total number to user via

@author: Colm Coughlan. colm.p.coughlan@aib.ie
"""

import os

have_argparse = True
try:
    import argparse
except ImportError:
    import sys
    have_argparse = False

# Check arguments

def add_schema(root, file, args):
    tags = {'CREATE':0, 'DROP':0, 'ANALYZE':0, 'GRANT':0, 'ALTER':0, 'DELETE':0,'TRUNCATE':0}    
    
    with open(os.path.join(root,file), 'r+') as f:  # open files
        lines = f.readlines()   # read everything
            
        if(loud):
            print("Editing "+os.path.join(root,file))   # chat to the user
            
        index = 0
        i = 0
        for line in lines:
            try:
                if (line.split()[0]).upper() in tags:
                    index = i
                    break
            except IndexError:
                IndexError
            i = i + 1
            
        lines.insert(index, 'SET SCHEMA '+args['schema_name']+';\n')   # insert schema
        lines.insert(index, 'SET PATH '+args['schema_name']+';\n') # insert path
        
        f.seek(0)   # reset pointer to start of file
        f.writelines(lines) # write out new version
        f.truncate()

if(have_argparse):
    parser = argparse.ArgumentParser(description='Apply a schema to all SQL files in a directory.')
    parser.add_argument('schema_name', type=str, help='The name of the schema to apply.')
    parser.add_argument('dir_name', type=str, help='The name of the directory containing the SQL.')
    parser.add_argument('--verbose',action="store_true" , help='Increase output verbosity.')
    
    args = vars(parser.parse_args())  # get args

else:
    if(len(sys.argv) == 3 or len(sys.argv) == 4):
        if len(sys.argv) == 4:
            sys_verbose = True
        else:
            sys_verbose = False
        args = {'schema_name': sys.argv[1], 'dir_name': sys.argv[2], 'verbose': sys_verbose}
    else:
        print('Argument error.')
        sys.exit()

if(args['verbose']):
	loud = True
else:
	loud = False
 

if os.path.isdir(args['dir_name']):
    nfiles = 0
    for root, dirs, files in os.walk(args['dir_name']):    # for all files in direcotry
        for file in files:
            if(file.upper().endswith('.SQL')):  # if it's an sql file
                nfiles = nfiles + 1 # count files
                add_schema(root, file, args)
else:
    nfiles = 1
    add_schema(os.path.dirname(args['dir_name']), os.path.basename(args['dir_name']), args)
                
print('Schema and path applied to '+str(nfiles)+' files.')