# -*- coding: utf-8 -*-
"""
Created on Fri Nov 4 2016

This script replaces schema and path to SQL files in a directory:

Inputs (command line):
    1. Schema name1. (also used as path name)
    2. Schema name2
    3. Directory name
    
Outputs:
    Edits all SQL files in directory (ending with SQL - case insensitive)
    Reports files and total number to user via

@author: Colm Coughlan. colm.p.coughlan@aib.ie
"""

import os
have_argparse = True
try:
    import argparse
except ImportError:
    import sys
    have_argparse = False
import re

# Check arguments

if(have_argparse):
	parser = argparse.ArgumentParser(description='Replace schema in directory.')
	parser.add_argument('schema_name1', type=str, help='The name of the schema to replace.')
	parser.add_argument('schema_name2', type=str, help='The new schema name.')
	parser.add_argument('dir_name', type=str, help='The name of the directory containing the SQL.')
	parser.add_argument('--verbose',action="store_true" , help='Increase output verbosity.')

	args = vars(parser.parse_args())  # get args

else:
    if(len(sys.argv) == 4 or len(sys.argv) == 5):
        if len(sys.argv) == 5:
            sys_verbose = True
        else:
            sys_verbose = False
        args = {'schema_name1': sys.argv[1], 'schema_name2': sys.argv[2], 'dir_name': sys.argv[3], 'verbose': sys_verbose}
    else:
        print('Argument error.')
        sys.exit()

nfiles = 0
if(args['verbose']):
	loud = True
else:
	loud = False

regex = re.compile(args['schema_name1'], re.IGNORECASE)

for root, dirs, files in os.walk(args['dir_name']):    # for all files in direcotry
    for file in files:
        if(file.upper().endswith('_STG.SQL')):  # if it's an sql file for staging
                    
            nfiles = nfiles + 1 # count files
            
            with open(os.path.join(root,file), 'r+') as f:  # open files
                lines = f.readlines()   # read everything
                    
                if(loud):
                    print("Editing "+os.path.join(root,file))   # chat to the user
                    
                for i in range(0,len(lines)):
                    lines[i] = re.sub(regex, args['schema_name2'], lines[i])
                    
                
                f.seek(0)   # reset pointer to start of file
                f.writelines(lines) # write out new version
                f.truncate()
                
print('Replacement carried out on '+str(nfiles)+' files.')