# -*- coding: utf-8 -*-
"""
Created on Tue Apr 18 11:24:26 2017
Program to amalgamate all Create SQL files used in the SAP HR Acquisition project so they can be used in the Erwin modeling program.
Lines required by Hadoop and not required by Erwin will be removed.

@author: 41774


regexs are the characters to be removed from the files.

repodir is the directory the files are stored in.
FileNameClose is the directory path and file name that the amalgamated file should be stored in.

if file.startswith("CREATE_STATEMENT.sql"): contains the name of the file to be searched for in the directory specified in repodir above,
 in this case it's CREATE_STATEMENT.sql

These variables need to be set before the file is run.

"""

import re 
#import sys
import os

regexs = [
        ('CREATE EXTERNAL HADOOP TABLE IF NOT EXISTS','CREATE  TABLE')
        ,('\s*COMMENT\s*\'.*\'',"")
        ,('\s*COMMENT\s*\'.*\n.*\'',"")
        ,('DATE STORED AS DATE','DATE')
        ,('DATE\s*NOT NULL','DATE')
        ,('\s*\)\s*STORED\s+AS.*\n','')
        ,('\s*PARTITIONED\s+BY\s*\(\s*',',\n')
    ]


#repodir = 'D:\\Git\\'
repodir = 'D:\\Test Delete This\\'
# turn the above into a list for all repos and generate a file for each 


#path = 'D:\\Git\\'
repodir = 'D:\\Test Delete This\\'
#FileNameClose = 'D:\\Git\\DataModelingFile.sql'
FileNameClose = 'D:\\Test Delete This\\DataModelingFileICMLCM.sql'

tfile = open(FileNameClose,"a")
for dirs, subdir, files in os.walk(repodir):
    for file in files:
        if file.startswith("CREATE_STATEMENT.sql"):
                 fileName = file
 
                 changeLines=''
                 
                 with open(dirs+"\\"+fileName,"r") as tmpfile:
                     for line in tmpfile:
                         #writes the output as one long line adds on each new line
                         changeLines += line
                         
                         # re sub substitutes the comments out, spaces before and after, and resinserts changeLines on new lines

                 for pattern, replace in regexs:
                     changeLines = re.sub(pattern, replace, changeLines)
                
               

                 for line in changeLines:
                            
                            tfile.write(line)
                      
tfile.close()  

