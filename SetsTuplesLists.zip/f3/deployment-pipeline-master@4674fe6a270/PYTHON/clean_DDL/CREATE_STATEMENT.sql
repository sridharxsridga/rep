/*=============================================
-- TABLE              : HR_SF_APPL_RECEIVED_PER_POS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 23/03/2017 13:46:45

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SF_APPL_RECEIVED_PER_POS
(
    APPLICATION_DATE     DATE,
    APPLICATION_ID     CHAR(20),
    JOB_REQ_ID     CHAR(20)     NOT NULL,
    REQUISITION_STATUS     VARCHAR(20)     NOT NULL,
    APPLICATION_STATUS     VARCHAR(100),
    HR_RECRUITER_FIRST_NAME     VARCHAR(100)     NOT NULL,
    HR_RECRUITER_LAST_NAME     VARCHAR(50)     NOT NULL,
    AGENCY_NAME     VARCHAR(50),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
