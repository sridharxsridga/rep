/*=============================================
-- TABLE              : HR_SF_APPL_RECEIVED_PER_POS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 23/03/2017 13:46:45

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SF_APPL_RECEIVED_PER_POS
(
    APPLICATION_DATE     DATE,
    APPLICATION_ID     CHAR(20),
    JOB_REQ_ID     CHAR(20)     NOT NULL,
    REQUISITION_STATUS     VARCHAR(20)     NOT NULL,
    APPLICATION_STATUS     VARCHAR(100),
    HR_RECRUITER_FIRST_NAME     VARCHAR(100)     NOT NULL,
    HR_RECRUITER_LAST_NAME     VARCHAR(50)     NOT NULL,
    AGENCY_NAME     VARCHAR(50),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_ABSENCES
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:15

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_ABSENCES
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    ABSENCE_TYPE_VAL     VARCHAR(4)     NOT NULL,
    ABSENCE_TYPE_TEXT     VARCHAR(25)     NOT NULL,
    ABSENCE_START_TIME     VARCHAR(20),
    ABSENCE_END_TIME     VARCHAR(20),
    ABSENCE_HOURS     DECIMAL(7,2)     NOT NULL,
    ABSENCE_DAYS     DECIMAL(6,2)     NOT NULL,
    CALENDAR_DAYS     DECIMAL(6,2)     NOT NULL,
    PAYROLL_DAYS     DECIMAL(6,2)     NOT NULL,
    PAYROLL_HOURS     DECIMAL(7,2)     NOT NULL,
    FULL_DAY_IND     VARCHAR(1),
    ILLNESS_DESC_CODE     VARCHAR(6),
    ILLNESS_DESCRIPTION     VARCHAR(20),
    STAFF_IN_PAYMENT_HC     CHAR(1)     NOT NULL,
    AVAILABLE_HEADCOUNT     CHAR(1)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_ACTIONS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:15

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_ACTIONS
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    ACTION_TYPE_VAL     CHAR(2)     NOT NULL,
    ACTION_TYPE_TEXT     VARCHAR(40),
    ACTION_REASON_VAL     CHAR(2),
    ACTION_REASON_TEXT     VARCHAR(40),
    EMPLOYMT_STATUS_VAL     CHAR(1)     NOT NULL,
    EMPLOYMT_STATUS_TEXT     VARCHAR(40)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_ACTIVE_ORG_STRUCTURE
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:15

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_ACTIVE_ORG_STRUCTURE
(
    LEVEL_0_OBJECT_ID     CHAR(8),
    LEVEL_0_TEXT     VARCHAR(40)     NOT NULL,
    LEVEL_0_SHORT     VARCHAR(12)     NOT NULL,
    EMPLOYER_OBJECT_ID     CHAR(8),
    EMPLOYER_TEXT     VARCHAR(40),
    EMPLOYER_SHORT     VARCHAR(12),
    LEVEL_1_OBJECT_ID     CHAR(8),
    LEVEL_1_TEXT     VARCHAR(40),
    LEVEL_1_SHORT     VARCHAR(12),
    LEVEL_2_OBJECT_ID     CHAR(8),
    LEVEL_2_TEXT     VARCHAR(40),
    LEVEL_2_SHORT     VARCHAR(12),
    LEVEL_3_OBJECT_ID     CHAR(8),
    LEVEL_3_TEXT     VARCHAR(40),
    LEVEL_3_SHORT     VARCHAR(12),
    LEVEL_4_OBJECT_ID     CHAR(8),
    LEVEL_4_TEXT     VARCHAR(40),
    LEVEL_4_SHORT     VARCHAR(12),
    OBJECTID     CHAR(8)     NOT NULL,
    OBJECT_NAME     VARCHAR(40),
    OBJECT_ABBR     VARCHAR(12)     NOT NULL,
    COST_CTR     VARCHAR(10),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_ADDITIONAL_ACTIONS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:15

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_ADDITIONAL_ACTIONS
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    ACTION_TYPE_VAL     VARCHAR(2)     NOT NULL,
    ACTION_TYPE_TEXT     VARCHAR(40)     NOT NULL,
    ACTION_REASON_VAL     VARCHAR(2),
    ACTION_REASON_TEXT     VARCHAR(40),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_BASIC_PAY_ANNUAL_SALARY
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:15

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_BASIC_PAY_ANNUAL_SALARY
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    REASON_FOR_CHGE_VAL     VARCHAR(2),
    REASON_FOR_CHGE_TEXT     VARCHAR(30),
    PAY_SCALE_TYPE_VAL     VARCHAR(2)     NOT NULL,
    PAY_SCALE_TYPE_TEXT     VARCHAR(20)     NOT NULL,
    PAY_SCALE_AREA_VAL     VARCHAR(2)     NOT NULL,
    PAY_SCALE_AREA_TEXT     VARCHAR(20)     NOT NULL,
    PAY_SCALE_GROUP     VARCHAR(8),
    PAY_SCALE_LEVEL     VARCHAR(2),
    CAPACITY_UTIL_LEVEL     DECIMAL(5,2)     NOT NULL,
    WORK_HOURS_PERIOD     DECIMAL(5,2)     NOT NULL,
    NEXT_INCREASE     DATE,
    ANNUAL_SALARY     DECIMAL(15,2)     NOT NULL,
    CRCY_FOR_ANNUAL_SAL     VARCHAR(5)     NOT NULL,
    MINIMUM_PAY_GRADE     DECIMAL(15,2)     NOT NULL,
    MIDPOINT_PAY_GRADE     DECIMAL(15,2)     NOT NULL,
    MAXIMUM_PAY_GRADE     DECIMAL(15,2)     NOT NULL,
    PLAN_COMP_TYPE_VAL     VARCHAR(1)     NOT NULL,
    PLAN_COMP_TYPE_TEXT     VARCHAR(60)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_BASIC_PAY_WAGE_TYPES
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:15

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_BASIC_PAY_WAGE_TYPES
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    WAGE_TYPE_VAL     VARCHAR(4),
    WAGE_TYPE_TEXT     VARCHAR(25),
    WAGE_TYPE_AMOUNT     DECIMAL(13,2)     NOT NULL,
    WAGE_TYPE_NUMBER     DECIMAL(7,2)     NOT NULL,
    WAGE_TYPE_UNITS_VAL     VARCHAR(3),
    WAGE_TYPE_UNITS_TEXT     VARCHAR(20),
    CURRENCY     VARCHAR(5)     NOT NULL,
    OPERATION_IND_VAL     VARCHAR(1),
    OPERATION_IND_TEXT     VARCHAR(10)     NOT NULL,
    IND_VALUATION     VARCHAR(1),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_CONTRACT_ELEMENTS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:15

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_CONTRACT_ELEMENTS
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    CONTRACT_TYPE_VAL     VARCHAR(2),
    CONTRACT_TYPE_TEXT     VARCHAR(20),
    PROB_PERIOD_NO     DECIMAL(3,0),
    PROB_PER_UNITS_VAL     VARCHAR(3),
    PROB_PER_UNITS_TEXT     VARCHAR(20),
    ER_NOTICE_PER_VAL     VARCHAR(2),
    ER_NOTICE_PER_TEXT     VARCHAR(20),
    EE_NOTICE_PER_VAL     VARCHAR(2),
    EE_NOTICE_PER_TEXT     VARCHAR(20),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_DATE_SPECIFICATIONS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:15

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_DATE_SPECIFICATIONS
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    DATE_TYPE_VAL     VARCHAR(2),
    DATE_TYPE_TEXT     VARCHAR(20),
    DATE_FOR_DATE_TYPE     DATE,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_MONITORING_OF_TASKS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:15

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_MONITORING_OF_TASKS
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    TASK_TYPE_VAL     VARCHAR(2)     NOT NULL,
    TASK_TYPE_TEXT     VARCHAR(20)     NOT NULL,
    DATE_OF_TASK     DATE,
    PROCESSING_IND_VAL     VARCHAR(1),
    PROCESSING_IND_TEXT     VARCHAR(20)     NOT NULL,
    REMINDER_DATE     DATE,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_ORG_ASSIGNMENT
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:15

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_ORG_ASSIGNMENT
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    COMPANY_CODE_VAL     VARCHAR(4)     NOT NULL,
    COMPANY_CODE_TEXT     VARCHAR(25)     NOT NULL,
    PERSONNEL_AREA_VAL     VARCHAR(4)     NOT NULL,
    PERSONNEL_AREA_TEXT     VARCHAR(30)     NOT NULL,
    COST_CENTER_VAL     VARCHAR(10),
    COST_CENTER_TEXT     VARCHAR(20),
    PERS_SUBAREA_VAL     VARCHAR(4)     NOT NULL,
    PERS_SUBAREA_TEXT     VARCHAR(15)     NOT NULL,
    EMPLOYEE_GROUP_VAL     VARCHAR(1)     NOT NULL,
    EMPLOYEE_GROUP_TEXT     VARCHAR(20)     NOT NULL,
    EMP_SUBGROUP_VAL     VARCHAR(2)     NOT NULL,
    EMPL_SUBGROUP_TEXT     VARCHAR(20)     NOT NULL,
    PAYROLL_AREA_VAL     VARCHAR(2)     NOT NULL,
    PAYROLL_AREA_TEXT     VARCHAR(20)     NOT NULL,
    WORK_CONTRACT_VAL     VARCHAR(2)     NOT NULL,
    WORK_CONTRACT_TEXT     VARCHAR(15)     NOT NULL,
    POSITION_VAL     CHAR(8)     NOT NULL,
    POSITION_TEXT     VARCHAR(40),
    POSITION_SHORT_TEXT     VARCHAR(12),
    JOB_CODE     VARCHAR(3),
    JOB_VAL     CHAR(8),
    JOB_SHORT_TEXT     VARCHAR(12),
    JOB_DESCRIPTION     VARCHAR(40),
    ORG_UNIT_VAL     CHAR(8),
    ORG_UNIT_TEXT     VARCHAR(40),
    ORGANIZATIONAL_KEY     VARCHAR(14),
    JOB_CATEGORY_DESC     VARCHAR(20),
    EMPLOYEE_NAME     VARCHAR(40),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_PERSONAL_DATA
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:15

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_PERSONAL_DATA
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    LAST_NAME     VARCHAR(40)     NOT NULL,
    FIRST_NAME     VARCHAR(40)     NOT NULL,
    KNOWN_AS     VARCHAR(40),
    GENDER_VAL     VARCHAR(1),
    GENDER_TEXT     VARCHAR(8)     NOT NULL,
    DATE_OF_BIRTH     DATE,
    CTRY_OF_BIRTH_VAL     VARCHAR(3),
    CTRY_OF_BIRTH_TEXT     VARCHAR(50),
    COUNTY     VARCHAR(3),
    BIRTHPLACE     VARCHAR(40),
    NATIONALITY_VAL     VARCHAR(3)     NOT NULL,
    NATIONALITY_TEXT     VARCHAR(15)     NOT NULL,
    COMM_LANG_VAL     VARCHAR(2)     NOT NULL,
    COMM_LANG_TEXT     VARCHAR(16)     NOT NULL,
    MARITAL_STATUS_VAL     VARCHAR(1),
    MARITAL_STATUS_TEXT     VARCHAR(6),
    MARITAL_STATUS_DATE     DATE,
    NO_OF_CHILDREN     DECIMAL(3,0),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_PLANNED_WORKING_TIME
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:15

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_PLANNED_WORKING_TIME
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    WORK_SCH_RULE_VAL     VARCHAR(8)     NOT NULL,
    WORK_SCH_RULE_TEXT     VARCHAR(25),
    TIME_MGMT_STAT_VAL     CHAR(1),
    TIME_MGMT_STAT_TEXT     VARCHAR(50)     NOT NULL,
    EMPLOYMENT_PERCENT     DECIMAL(5,2)     NOT NULL,
    MONTHLY_WORKING_HRS     DECIMAL(5,2)     NOT NULL,
    WEEKLY_WORKING_HOURS     DECIMAL(5,2)     NOT NULL,
    DAILY_WORKING_HOURS     DECIMAL(5,2)     NOT NULL,
    WEEKLY_WORKDAYS     DECIMAL(4,2)     NOT NULL,
    ANNUAL_WORKING_HOURS     DECIMAL(7,2)     NOT NULL,
    PART_TIME_EMPLOYEE     VARCHAR(1),
    FTE_WEEKLY_HOURS     DECIMAL(5,2)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SF_APPL_RECEIVED_PER_POS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 23/03/2017 13:46:45

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SF_APPL_RECEIVED_PER_POS
(
    APPLICATION_DATE     DATE,
    APPLICATION_ID     CHAR(20),
    JOB_REQ_ID     CHAR(20)     NOT NULL,
    REQUISITION_STATUS     VARCHAR(20)     NOT NULL,
    APPLICATION_STATUS     VARCHAR(100),
    HR_RECRUITER_FIRST_NAME     VARCHAR(100)     NOT NULL,
    HR_RECRUITER_LAST_NAME     VARCHAR(50)     NOT NULL,
    AGENCY_NAME     VARCHAR(50),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SF_EMPL_PROFILE
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 23/03/2017 13:46:45

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SF_EMPL_PROFILE
(
    STAFF_NUMBER     CHAR(50)     NOT NULL,
    FIRST_NAME     VARCHAR(50)     NOT NULL,
    LAST_NAME     VARCHAR(50)     NOT NULL,
    REVIEWER     CHAR(20)     NOT NULL,
    MANAGER     CHAR(20)     NOT NULL,
    MANAGER_FIRST_NAME     VARCHAR(50)     NOT NULL,
    MANAGER_LAST_NAME     VARCHAR(50)     NOT NULL,
    MATRIX_MANAGER_FIRST_NAME     VARCHAR(50),
    MATRIX_MANAGER_LAST_NAME     VARCHAR(50),
    FROM_DTE_EMP_INT_WORK_HIST_1     VARCHAR(30),
    END_DTE_EMP_INT_WORK_HIST_1     VARCHAR(30),
    TITLE_EMP_INT_WORKHIST     VARCHAR(50),
    BUSINESS_INT_WORK_HIST     VARCHAR(50),
    DEPT_EMP_INT_WORK_HIST     VARCHAR(50),
    FROM_DTE_EMP_EXT_WORK_HIST_1     VARCHAR(30),
    END_DTE_EMP_EXT_WORK_HIST_1     VARCHAR(30),
    COMPANY_NAME     VARCHAR(50),
    TITLE_EMP_EXT_WORK_HIST     VARCHAR(50),
    DESCRIPTION     VARCHAR(200),
    FROM_DTE_EMP_EXT_WORK_HIST_2     VARCHAR(30),
    END_DTE_EMP_EXT_WORK_HIST_2     VARCHAR(30),
    ASSIGNMENT_PROJECT     VARCHAR(50),
    DESCRIPTION_EMP_SPECIALASSIGN     VARCHAR(65),
    FROM_DATE_EMP_SPECIALASSIGN     VARCHAR(30),
    END_DATE_EMP_SPECIALASSIGN     VARCHAR(30),
    UNIVERSITY_COLLEGE     VARCHAR(50),
    IF_OTHER_UNIVERSITY_MENTION     VARCHAR(50),
    SUBJECT     VARCHAR(50),
    IF_OTHER_SUBJECT_MENTION     VARCHAR(50),
    EDUCATION     VARCHAR(50),
    IF_OTHER_EDUCATION_MENTION     VARCHAR(200),
    QUALIFICATION     VARCHAR(50),
    CERTIFICATION_LICENSE     VARCHAR(50),
    DESCRIPTION_EMP_CERTIFICATIONS     VARCHAR(50),
    INSTITUTION     VARCHAR(50),
    EFFECTIVE_DATE     VARCHAR(30),
    EXPIRATION_DATE     VARCHAR(30),
    LANG     VARCHAR(50),
    IF_OTHER_PLEASE_MENTION     VARCHAR(50),
    SPEAKING_PROFICIENCY     VARCHAR(50),
    READING_PROFICIENCY     VARCHAR(50),
    WRITING_PROFICIENCY     VARCHAR(50),
    TECHNICAL_COMPETENCY     VARCHAR(50),
    LEVEL_EMPLOYEE_TECHNICAL     VARCHAR(50),
    COMMENTS_EMPLOYEE_TECHNICAL     VARCHAR(77),
    IT_AND_SYSTEM_AREA     VARCHAR(50),
    LEVEL_EMPLOYEE_IT     VARCHAR(300),
    COMMENTS_EMPLOYEE_IT     VARCHAR(50),
    PROFESSIONAL_COMPETENCY     VARCHAR(50),
    LEVEL_EMPLOYEE_PROFESSIONAL     VARCHAR(50),
    PROFESSIONAL_MEMBERSHIP_BODY     VARCHAR(50),
    COMMUNITY_VOLUNTEER_ORG_NAME     VARCHAR(50),
    ROLE_EMPLOYEE_COMMUNITY     VARCHAR(50),
    FROM_DATE_EMPLOYEE_COMMUNITY     VARCHAR(30),
    END_DATE_EMPLOYEE_COMMUNITY     VARCHAR(30),
    BUSINESS_EMPLOYEE_CAREER     VARCHAR(50),
    DEPARTMENT_EMPLOYEE_CAREER     VARCHAR(50),
    PREFERENCE     VARCHAR(50),
    TIMEFRAME     VARCHAR(50),
    COMMENTS_EMPLOYEE_CAREER     VARCHAR(200),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SF_OBJECTIVE_MANAGEMENT
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 23/03/2017 13:46:45

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SF_OBJECTIVE_MANAGEMENT
(
    OBJECTIVE_PLAN_NAME     VARCHAR(50)     NOT NULL,
    OBJECTIVE_PLAN_STATE     VARCHAR(50),
    OBJ_PLAN_DATA_LAST_MOD_DTE     VARCHAR(30),
    OBJECTIVE_OWNER_STAFF_NUMBER     CHAR(16)     NOT NULL,
    OBJECTIVE_OWNER_EMAIL     VARCHAR(50),
    NUMBERING     CHAR(5),
    OBJECTIVE_ID     CHAR(10),
    GOAL     VARCHAR(15000),
    OBJECTIVE_TYPE     VARCHAR(20),
    OBJ_EXT_FIELD1     VARCHAR(6000),
    OBJ_EXT_FIELD2     VARCHAR(6000),
    LAST_MODIFIED_DATE     VARCHAR(30),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SF_PERFM_MGMT_GEN_DATA
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 23/03/2017 13:46:45

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SF_PERFM_MGMT_GEN_DATA
(
    FORM_TEMPLATE_ID     CHAR(20)     NOT NULL,
    LT_FORM_SUBJECT_USR_SYS_USRNME     CHAR(20)     NOT NULL,
    REVIEWEE_FIRST_NAME     VARCHAR(50),
    REVIEWEE_LAST_NAME     VARCHAR(50),
    FORM_START_DATE     DATE,
    FORM_END_DATE     DATE,
    FORM_DUE_DATE     DATE,
    FORM_CREATION_DATE     VARCHAR(30)     NOT NULL,
    LAST_MODIFIED_DATE     VARCHAR(30)     NOT NULL,
    FORM_TEMPLATE_NAME     VARCHAR(50)     NOT NULL,
    CURR_ROUTE_STEP_NME_NOT_SUPP     VARCHAR(50),
    OVERALL_PERFORMANCE_RATING     CHAR(7),
    OVERALL_PERFM_RATING_DESCR     VARCHAR(15000),
    COMPETENCY_ID     CHAR(20),
    COMPETENCY_NAME     VARCHAR(50),
    COMPETENCY_OFFICIAL_RATING     CHAR(5),
    COMPETENCY_OFFICIAL_RTE_DESCR     VARCHAR(50),
    STATUS     VARCHAR(20)     NOT NULL,
    CURRENT_ROUTE_STEP_NAME     VARCHAR(50),
    LT_SECTION_CUSTOM_FIELD_ID     CHAR(20),
    LT_SECTION_CUSTOM_FIELD_NAME     VARCHAR(50),
    LT_SECTION_CUSTOM_FIELD_VALUE     VARCHAR(6000),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SF_PERFM_MGMT_NARRATIVE
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 23/03/2017 13:46:45

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SF_PERFM_MGMT_NARRATIVE
(
    REVIEWEE_FIRST_NAME     VARCHAR(50)     NOT NULL,
    REVIEWEELAST_NAME     VARCHAR(50)     NOT NULL,
    REVIEWEE_EMAIL     VARCHAR(50),
    SECTION_ID     CHAR(20),
    SECTION_NAME     VARCHAR(100),
    SECTION_COMMENT     VARCHAR(10000),
    SECTION_COMMENT_OWNER_USER_ID     CHAR(20),
    SECTION_CMNT_OWNER_USER_NAME     VARCHAR(50),
    FORM_TITLE     VARCHAR(73)     NOT NULL,
    STATUS     VARCHAR(50)     NOT NULL,
    MANAGER_FIRST_NAME     VARCHAR(50)     NOT NULL,
    MANAGER_LAST_NAME     VARCHAR(50)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SF_RECRUITMENT_DAYS_TO_FILL
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 23/03/2017 13:46:45

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SF_RECRUITMENT_DAYS_TO_FILL
(
    CANDIDATE_PROGRESS     VARCHAR(50),
    JOB_TITLE     VARCHAR(100)     NOT NULL,
    JOB_REQ_ID     CHAR(20)     NOT NULL,
    JURISDICTION     VARCHAR(50),
    LOCATION     VARCHAR(100),
    PAYROLL_AREA     VARCHAR(64),
    BUSINESS     CHAR(40),
    DEPARTMENT     VARCHAR(50),
    ACTUAL_START_DATE     DATE,
    FIRST_NAME     VARCHAR(50),
    LAST_NAME     VARCHAR(50),
    CONFIRMED_START_DATE     DATE,
    CANDIDATE_NAME     VARCHAR(50),
    CANDIDATE_RECRUITED     VARCHAR(10),
    CANDIDATE_ID     CHAR(20),
    KNOWN_AS     VARCHAR(51),
    SAP_APPROVED     VARCHAR(50),
    SAP_KEYED     VARCHAR(50),
    CONFIRMED_SALARY     CHAR(20),
    CONFIRMED_GRADE     VARCHAR(80),
    HOW_DID_YOU_HEAR_ABOUT_POS     VARCHAR(31),
    APPLICATION_ID     CHAR(20),
    LINE_MANAGER_NOTIFICATION     CHAR(10),
    APPLICATION_LOCALE     CHAR(50),
    APPLICATION_STATUS_LABEL     VARCHAR(50),
    LINE_MANAGER_NAME     VARCHAR(62),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SF_RECRUITMENT_FILLED_REQ
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 23/03/2017 13:46:45

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SF_RECRUITMENT_FILLED_REQ
(
    JOB_REQ_ID     CHAR(20)     NOT NULL,
    JOB_TITLE     VARCHAR(100)     NOT NULL,
    GRADE_OR_CAREER_BAND     VARCHAR(200),
    REQUISITION_TYPE     VARCHAR(30),
    NUMBER_OF_OPENINGS     CHAR(2),
    HR_RECRUITER_FIRST_NAME     VARCHAR(50)     NOT NULL,
    HR_RECRUITER_LAST_NAME     VARCHAR(50)     NOT NULL,
    REQUISITION_STATUS     VARCHAR(100)     NOT NULL,
    STATUS     VARCHAR(100),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SF_RECRUITMENT_GENERAL_INFO
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 23/03/2017 13:46:45

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SF_RECRUITMENT_GENERAL_INFO
(
    JOB_REQ_ID     CHAR(20)     NOT NULL,
    CNTRY_WHERE_VAC_IS_REQUIRED     VARCHAR(50),
    APPLICATION_DATE     DATE,
    APPLICATION_ID     CHAR(20),
    CANDIDATE_ID     CHAR(20),
    EMPLOYEE_ID     CHAR(20),
    FIRST_NAME     VARCHAR(50),
    LAST_NAME     VARCHAR(50),
    APPLICATION_STATUS_LABEL     VARCHAR(50),
    JOB_TITLE     VARCHAR(200)     NOT NULL,
    DEPARTMENT     VARCHAR(50),
    GRADE     VARCHAR(60),
    HR_RECRUITER_FIRST_NAME     VARCHAR(50)     NOT NULL,
    HR_RECRUITER_LAST_NAME     VARCHAR(50)     NOT NULL,
    SOURCE     VARCHAR(50),
    HOW_DID_YOU_HEAR_ABOUT_POS     VARCHAR(32),
    APPLICATION_STATUS     VARCHAR(100),
    EMAIL_ADDRESS     VARCHAR(100),
    HAVE_YOU_WORKED_IN_AIB_BEFORE     VARCHAR(20),
    REQUISITION_TYPE     VARCHAR(21),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_ABSENCE_QUOTAS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 28/03/2017 12:26:00

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_ABSENCE_QUOTAS
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    ABSENCE_QUOTA_VAL     DECIMAL(2,0)     NOT NULL,
    ABSENCE_QUOTA_TEXT     VARCHAR(25)     NOT NULL,
    QUOTA_NUMBER     DECIMAL(10,5)     NOT NULL,
    QUOTA_DEDUCTION     DECIMAL(10,5)     NOT NULL,
    DEDUCTION_FROM     DATE,
    DEDUCTION_TO     DATE,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_ADDITIONAL_PAYMENTS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 28/03/2017 12:26:00

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_ADDITIONAL_PAYMENTS
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4)     NOT NULL,
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NUMBER     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    WAGE_TYPE_VAL     VARCHAR(30)     NOT NULL,
    WAGE_TYPE_TEXT     VARCHAR(25)     NOT NULL,
    OPERATION_IND_VAL     VARCHAR(1),
    OPERATION_IND_TEXT     VARCHAR(10)     NOT NULL,
    WAGE_TYPE_AMOUNT     DECIMAL(13,2)     NOT NULL,
    WAGE_TYPE_CURRENCY     VARCHAR(5)     NOT NULL,
    IND_VALUATION     VARCHAR(1),
    WAGE_TYPE_NUMBER     DECIMAL(7,2)     NOT NULL,
    WAGE_TYPE_UNITS_VAL     VARCHAR(3),
    WAGE_TYPE_UNITS_TEXT     VARCHAR(20),
    ASSIGNMENT_NUMBER     VARCHAR(20),
    REASON_FOR_CHG_VAL     VARCHAR(2),
    REASON_FOR_CHG_TEXT     VARCHAR(30),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_ADDRESSES
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 28/03/2017 12:26:00

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_ADDRESSES
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4)     NOT NULL,
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NUMBER     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    ADDRESS_TYPE     VARCHAR(4)     NOT NULL,
    ADDRESS_TYPE_DESCRIPTION     VARCHAR(40)     NOT NULL,
    CARE_OF     VARCHAR(40),
    ADDRESS_LINE_1     VARCHAR(60),
    ADDRESS_LINE_2     VARCHAR(40),
    ADDRESS_LINE_3     VARCHAR(40),
    ADDRESS_LINE_4     VARCHAR(40),
    COUNTY_CODE     VARCHAR(3),
    COUNTY_CODE_DESCRIPTION     VARCHAR(20),
    POSTAL_CODE     VARCHAR(10),
    COUNTRY_KEY     VARCHAR(3)     NOT NULL,
    COUNTRY_NAME     VARCHAR(15)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_COST_OF_ABSENCE
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 28/03/2017 12:26:00

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_COST_OF_ABSENCE
(
    AMOUNT_IN_PAYROLL     DECIMAL(12,2)     NOT NULL,
    ORIGINAL_CURRENCY     VARCHAR(3)     NOT NULL,
    EUR_EQUIVALENT     DECIMAL(12,2)     NOT NULL,
    GBP_EQUIVALENT     DECIMAL(12,2)     NOT NULL,
    EUR_FACTORED_COST     DECIMAL(12,2)     NOT NULL,
    GBP_FACTORED_COST     DECIMAL(12,2)     NOT NULL,
    FULL_PAY_AMOUNT_EUR     DECIMAL(12,2)     NOT NULL,
    HALF_PAY_AMOUNT_EUR     DECIMAL(12,2)     NOT NULL,
    FULL_PAY_AMOUNT_GBP     DECIMAL(12,2)     NOT NULL,
    HALF_PAY_AMOUNT_GBP     DECIMAL(12,2)     NOT NULL,
    NUMBER_OF_DAYS     DECIMAL(7,2)     NOT NULL,
    EXCHANGE_RATE     DECIMAL(9,5)     NOT NULL,
    PERSONNEL_NUMBER     DECIMAL(8,0),
    PERIOD_START_DATE     DATE,
    PERIOD_END_DATE     DATE,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_EMPLOYEE_REMUNERATION
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 28/03/2017 12:26:00

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_EMPLOYEE_REMUNERATION
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    WAGE_TYPE_VAL     VARCHAR(4)     NOT NULL,
    WAGE_TYPE_TEXT     VARCHAR(25)     NOT NULL,
    NUMBER_OF_HOURS     DECIMAL(7,2)     NOT NULL,
    NUMBER_PER_TIME_UNIT     DECIMAL(7,2),
    WAGE_TYPE_UNITS_VAL     VARCHAR(3),
    WAGE_TYPE_UNITS_TEXT     VARCHAR(20),
    WAGE_TYPE_AMOUNT     DECIMAL(13,2),
    WAGE_TYPE_CURRENCY     VARCHAR(5),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_NEW_EXTERNALS_INFOTYPE
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 28/03/2017 12:26:00

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_NEW_EXTERNALS_INFOTYPE
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    CONTRACT_IN_PLACE     VARCHAR(1),
    PERM_STATION_REQ     VARCHAR(1),
    SOLE_TRADER     VARCHAR(1),
    COMPANY_LESS_THAN_5     VARCHAR(1),
    CONTRACTOR_COST_CAP     VARCHAR(1),
    CONTRACTOR_COMPANY     VARCHAR(40),
    PROJECT_NAME     VARCHAR(40),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_PENSIONS_GB
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 28/03/2017 12:26:00

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_PENSIONS_GB
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4)     NOT NULL,
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    SCHEME_REFERENCE     VARCHAR(20)     NOT NULL,
    PENSION_SCHEME_NAME     VARCHAR(30),
    LOW_BAND_LEVEL     DECIMAL(9,2),
    HIGH_BAND_LEVEL     DECIMAL(9,2),
    EMPLOYEE_LWR_BAND_PERCENT     DECIMAL(7,4)     NOT NULL,
    EMPLOYER_LWR_BAND_PERCENT     DECIMAL(7,4)     NOT NULL,
    EMPLOYEE_MID_BAND_PERCENT     DECIMAL(7,4)     NOT NULL,
    EMPLOYER_MID_BAND_PERCENT     DECIMAL(7,4)     NOT NULL,
    EMPLOYEE_UPP_BAND_PERCENT     DECIMAL(7,4)     NOT NULL,
    EMPLOYER_UPP_BAND_PERCENT     DECIMAL(7,4)     NOT NULL,
    FLAT_RATE_AVC     DECIMAL(9,2)     NOT NULL,
    FLAT_RATE_FSAVC     DECIMAL(9,2)     NOT NULL,
    PERCENTAGE_AVC     DECIMAL(7,4)     NOT NULL,
    CURRENCY     VARCHAR(5)     NOT NULL,
    PENSION_CAP_EXCL     VARCHAR(1),
    EE_SPEC_RECORD_IND     VARCHAR(1),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_PENSIONS_IRELAND
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 28/03/2017 12:26:00

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_PENSIONS_IRELAND
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    SCHEME_REFERENCE     VARCHAR(30)     NOT NULL,
    PENSION_SCHEME_NAME     VARCHAR(40),
    EMPLOYEE_PERCENTAGE     DECIMAL(7,4)     NOT NULL,
    EMPLOYEE_PERIOD_CONT     DECIMAL(11,2)     NOT NULL,
    EMPLOYEE_FLAT_AMT     DECIMAL(11,2)     NOT NULL,
    EMPLOYEE_WAGE_TYPE     VARCHAR(4),
    EMPLOYER_PERCENTAGE     DECIMAL(7,4)     NOT NULL,
    EMPLOYER_PERIOD_CONT     DECIMAL(11,2)     NOT NULL,
    EMPLOYER_FLAT_AMT     DECIMAL(11,2)     NOT NULL,
    EMPLOYER_WAGE_TYPE     VARCHAR(4),
    AVC_PERCENTAGE     DECIMAL(7,4)     NOT NULL,
    AVC_PERIOD_CONT     DECIMAL(11,2)     NOT NULL,
    AVC_FLAT_AMT     DECIMAL(11,2)     NOT NULL,
    AVC_WAGE_TYPE     VARCHAR(4),
    CURRENCY     VARCHAR(5)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_RECURRING_PMT_DEDUCT
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 28/03/2017 12:26:00

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_RECURRING_PMT_DEDUCT
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4)     NOT NULL,
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    WAGE_TYPE_VAL     VARCHAR(30)     NOT NULL,
    WAGE_TYPE_TEXT     VARCHAR(25)     NOT NULL,
    OPERATION_IND_VAL     VARCHAR(1),
    OPERATION_IND_TEXT     VARCHAR(10)     NOT NULL,
    WAGE_TYPE_AMOUNT     DECIMAL(13,2)     NOT NULL,
    WAGE_TYPE_CURRENCY     VARCHAR(5)     NOT NULL,
    IND_VALUATION     VARCHAR(1),
    WAGE_TYPE_NUMBER     DECIMAL(7,2)     NOT NULL,
    WAGE_TYPE_UNITS_VAL     VARCHAR(3),
    WAGE_TYPE_UNITS_TEXT     VARCHAR(25),
    ASSIGNMENT_NUMBER     VARCHAR(20),
    REASON_FOR_CHG_VAL     VARCHAR(2),
    REASON_FOR_CHG_TEXT     VARCHAR(30),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_STATISTICS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 28/03/2017 12:26:00

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_STATISTICS
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4)     NOT NULL,
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NUMBER     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    STATISTICS_TEXT     VARCHAR(40)     NOT NULL,
    STATISTICS_INDICATOR     CHAR(2),
    STATISTICS_INDICATOR_TEXT     VARCHAR(10),
    STATISTIC_EXCEPTIONS     VARCHAR(4),
    STATISTIC_EXCEPTIONS_TEXT     VARCHAR(30),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_CS_ILEARN_TRAINING_INFO
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:32

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_CS_ILEARN_TRAINING_INFO
(
    TRAINING_OBJECT_ID     VARCHAR(36)     NOT NULL,
    USER_ID     VARCHAR(100),
    TRAINING_ID     VARCHAR(36),
    TRAINING_TITLE     VARCHAR(500),
    TRAINING_RECORD_REGISTR_DATE     VARCHAR(30),
    TRAINING_STATUS     VARCHAR(11),
    TRAINING_RECORD_CMPLTN_DATE     VARCHAR(30),
    TRAINING_TYPE     VARCHAR(21),
    SESSION_TYPE     VARCHAR(100),
    TRAINING_HOURS     CHAR(6),
    TRAINING_TOPICS     VARCHAR(100),
    TRAINING_RECORD_SCORE     INTEGER,
    TRAINING_VENDOR     VARCHAR(100),
    GRADE     VARCHAR(100),
    DEPARTMENT_BRANCH     VARCHAR(100),
    DEPARTMENT_BRANCH_REF     VARCHAR(100),
    ACCENTURE_ACTIVE_CATALOGUE     VARCHAR(100),
    LEARNING_TYPE     VARCHAR(100),
    LAST_MODIFIED_DATE     VARCHAR(30),
    LAST_MODIFIED_BY_USER_ID     VARCHAR(100),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_ICONNECT_SURVEY_MASTERFILE
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 30/03/2017 10:10:24

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_ICONNECT_SURVEY_MASTERFILE
(
    SURVEY_YEAR     DECIMAL(4,0)     NOT NULL,
    BREAKVAR     DECIMAL(15,0)     NOT NULL,
    TYPE_OF_REPORT     VARCHAR(15)     NOT NULL,
    NAME     VARCHAR(100)     NOT NULL,
    POPULATION_SIZE     DECIMAL(5,0),
    NUMBER_OF_RESPONSES     VARCHAR(10)     NOT NULL,
    RESPONSE_RATE     DECIMAL(3,0),
    SUPPRESSION_REASON     VARCHAR(40),
    CONFLICTING_BUSINESS_UNITS     VARCHAR(900),
    PAST_DATA_AVAILABLE     VARCHAR(3),
    MANAGER_ID     VARCHAR(40)     NOT NULL,
    MANAGER_BUSINESS_UNITS     VARCHAR(40),
    MANAGER_COMPANY     VARCHAR(40),
    MANAGER_COUNTRY     VARCHAR(40),
    LEVEL_1     VARCHAR(40),
    LEVEL_2     VARCHAR(40),
    LEVEL_3     VARCHAR(40),
    LEVEL_4     VARCHAR(40),
    LEVEL_5     VARCHAR(40),
    LEVEL_6     VARCHAR(40),
    LEVEL_7     VARCHAR(40),
    LEVEL_8     VARCHAR(40),
    POSITION     VARCHAR(30),
    ORGANISATION_UNIT_VAL     DECIMAL(8,0),
    ORGANISATION_UNIT_TEXT     VARCHAR(40),
    STREET_HOUSE_ADDRESS     VARCHAR(60),
    SECOND_ADDRESS_LINE     VARCHAR(40),
    DISTRICT     VARCHAR(40),
    CITY     VARCHAR(40),
    REGION     VARCHAR(40),
    SELECTED_FOR_COACHING     VARCHAR(4),
    COACHING_ACCEPTED     VARCHAR(4),
    PROPOSED_NAME_OF_COACH     VARCHAR(30),
    COACH_BUSINESS_AREA     VARCHAR(30),
    METRIC_CATEGORY     VARCHAR(50)     NOT NULL,
    METRIC_VALUE     VARCHAR(100),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_ICONNECT_SURVEY_METRIC_REF
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 30/03/2017 10:10:24

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_ICONNECT_SURVEY_METRIC_REF
(
    METRIC_ID     DECIMAL(3,0)     NOT NULL,
    METRIC_CATEGORY     VARCHAR(50)     NOT NULL,
    METRIC_DESCRIPTION_     VARCHAR(200)     NOT NULL,
    CATEGORY_1     VARCHAR(20),
    CATEGORY_2     VARCHAR(20),
    VALID_TO_DATE     DATE,
    VALID_FROM_DATE     DATE,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_ATTEND_REVIEW_PROCESS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:21

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_ATTEND_REVIEW_PROCESS
(
    PERIOD_START_DATE     DATE,
    PERIOD_END_DATE     DATE,
    ORG_UNIT_VAL     CHAR(8)     NOT NULL,
    ORG_UNIT_TEXT     VARCHAR(40)     NOT NULL,
    ARP_CAUTION_VAL     VARCHAR(1)     NOT NULL,
    ARP_CAUTION_TEXT     VARCHAR(60)     NOT NULL,
    MONTH_NO     INTEGER     NOT NULL,
    MONTH_FDE     DECIMAL(7,2)     NOT NULL,
    DUE_TO_LEAVE_NO     INTEGER     NOT NULL,
    DUE_TO_LEAVE_FDE     DECIMAL(7,2)     NOT NULL,
    NUMBER_OF_STAFF     INTEGER     NOT NULL,
    FDE     DECIMAL(7,2)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_CONTRACT_EXTENSION
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:21

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_CONTRACT_EXTENSION
(
    Personnel_Number     CHAR(8)     NOT NULL,
    PersNo_Approver     CHAR(8)     NOT NULL,
    Request_Number     CHAR(8)     NOT NULL,
    Action_Date     DATE,
    HR_PA_Status_Val     VARCHAR(1)     NOT NULL,
    HR_PA_Status_Text     VARCHAR(30)     NOT NULL,
    Extension_Reas_Val     VARCHAR(1)     NOT NULL,
    Extension_Reason_Txt     VARCHAR(20)     NOT NULL,
    Orig_Cont_Start_Date     DATE,
    Orig_Cont_End_Date     DATE,
    New_Cont_End_Date     DATE,
    Confirmation_1     VARCHAR(1)     NOT NULL,
    Confirmation_2     VARCHAR(1)     NOT NULL,
    Confirmation_3     VARCHAR(1)     NOT NULL,
    CRM_Ticket     CHAR(10)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_FLEXIBLE_WORKING
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:21

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_FLEXIBLE_WORKING
(
    Personnel_Number     CHAR(8)     NOT NULL,
    PersNo_Approver     CHAR(8)     NOT NULL,
    Request_Number     CHAR(8)     NOT NULL,
    Action_Date     DATE,
    HR_PA_Status_Val     VARCHAR(1)     NOT NULL,
    HR_PA_Status_Text     VARCHAR(30)     NOT NULL,
    Request_Type_Val     VARCHAR(10),
    Request_Type_Text     VARCHAR(25),
    Request_Answer_Val     VARCHAR(1),
    Request_Answer_Text     VARCHAR(3),
    Flex_Work_Act_Val     VARCHAR(1),
    Flex_Work_Act_Text     VARCHAR(50),
    Decision_Val     VARCHAR(1),
    Decision_Text     VARCHAR(10),
    Conf_Prob_Comp_Val     VARCHAR(1),
    Conf_Prob_Comp_Text     VARCHAR(3),
    Decline_Date     DATE,
    Decline_Reason_1     VARCHAR(1),
    Decline_Reason_2     VARCHAR(1),
    Decline_Reason_3     VARCHAR(1),
    Decline_Reason_4     VARCHAR(1),
    Decline_Reason_5     VARCHAR(1),
    Decline_Reason_6     VARCHAR(1),
    Decline_Reason_7     VARCHAR(1),
    Decline_Reason_8     VARCHAR(1),
    CRM_Ticket     CHAR(10),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_MCC_FANDP_REGISTER
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:21

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_MCC_FANDP_REGISTER
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    END_DATE     DATE,
    START_DATE     DATE,
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    QUAL_GROUP     CHAR(8)     NOT NULL,
    QUAL_GROUP_TEXT     VARCHAR(40)     NOT NULL,
    QUAL_ID     CHAR(8)     NOT NULL,
    QUALIFICATION_TEXT     VARCHAR(40)     NOT NULL,
    PROFICIENCY     CHAR(4),
    PROFICIENCY_TEXT     VARCHAR(40),
    EXAM_DATE     DATE,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_PARENTAL_LEAVE_BLOCK
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:21

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_PARENTAL_LEAVE_BLOCK
(
    Personnel_Number     CHAR(8)     NOT NULL,
    PersNo_Approver     CHAR(8)     NOT NULL,
    Request_Number     CHAR(8)     NOT NULL,
    Action_Date     DATE,
    HR_PA_Status_Val     VARCHAR(1)     NOT NULL,
    HR_PA_Status_Text     VARCHAR(30)     NOT NULL,
    Request_Type     VARCHAR(10)     NOT NULL,
    Weeks_Notice     CHAR(2)     NOT NULL,
    Days_Notice     CHAR(2)     NOT NULL,
    Leave_Start_Date     DATE,
    Leave_End_Date     DATE,
    Child_Name     VARCHAR(40),
    Child_Date_of_Birth     DATE,
    Parental_Leave_Days     CHAR(3)     NOT NULL,
    Employer_Response     VARCHAR(10),
    Postpone_Reason     VARCHAR(60),
    CRM_Ticket     CHAR(10),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_PARENTAL_LEAVE_RED_HRS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:21

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_PARENTAL_LEAVE_RED_HRS
(
    Personnel_Number     CHAR(8)     NOT NULL,
    PersNo_Approver     CHAR(8)     NOT NULL,
    Request_Number     CHAR(8)     NOT NULL,
    Action_Date     DATE,
    HR_PA_Status_Val     VARCHAR(1)     NOT NULL,
    HR_PA_Status_Text     VARCHAR(30)     NOT NULL,
    Request_Type     VARCHAR(10)     NOT NULL,
    Decision_Val     VARCHAR(1),
    Decision_Text     VARCHAR(10),
    Weeks_Notice     CHAR(2)     NOT NULL,
    Days_Notice     CHAR(2)     NOT NULL,
    Child_Name     VARCHAR(80),
    Child_Date_of_Birth     DATE,
    Leave_Start_Date     DATE,
    Leave_End_Date     DATE,
    Work_schedule_rule     VARCHAR(8)     NOT NULL,
    Decline_Reason_1     VARCHAR(1),
    Decline_Reason_2     VARCHAR(1),
    Decline_Reason_3     VARCHAR(1),
    Decline_Reason_4     VARCHAR(1),
    Decline_Reason_5     VARCHAR(1),
    Decline_Reason_6     VARCHAR(1),
    Decline_Reason_7     VARCHAR(1),
    Decline_Reason_8     VARCHAR(1),
    Decline_Reason_Other     VARCHAR(255),
    CRM_Ticket     CHAR(10),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_WAGE_TYPE_REPORTER
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:21

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_WAGE_TYPE_REPORTER
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    COMPANY_CODE_VAL     VARCHAR(4)     NOT NULL,
    COMPANY_CODE_TEXT     VARCHAR(25)     NOT NULL,
    PERSONNEL_AREA_VAL     VARCHAR(4)     NOT NULL,
    PERSONNEL_AREA_TEXT     VARCHAR(30)     NOT NULL,
    PERS_SUBAREA_VAL     VARCHAR(4)     NOT NULL,
    PERS_SUBAREA_TEXT     VARCHAR(15)     NOT NULL,
    COST_CENTER_VAL     VARCHAR(10),
    COST_CENTER_TEXT     VARCHAR(20),
    ORG_UNIT_VAL     CHAR(8),
    ORG_UNIT_TEXT     VARCHAR(40),
    PAYROLL_AREA_VAL     VARCHAR(2)     NOT NULL,
    PAYROLL_AREA_TEXT     VARCHAR(20)     NOT NULL,
    EMPLOYEE_GROUP_VAL     VARCHAR(1)     NOT NULL,
    EMPLOYEE_GROUP_TEXT     VARCHAR(20)     NOT NULL,
    EMP_SUBGROUP_VAL     VARCHAR(2)     NOT NULL,
    EMPL_SUBGROUP_TEXT     VARCHAR(20)     NOT NULL,
    ORGANIZATIONAL_KEY     VARCHAR(14),
    WAGE_TYPE_VAL     VARCHAR(4)     NOT NULL,
    WAGE_TYPE_TEXT     VARCHAR(25)     NOT NULL,
    NUMBER     DECIMAL(25,2)     NOT NULL,
    AMOUNT     DECIMAL(25,2)     NOT NULL,
    CURRENCY     VARCHAR(5)     NOT NULL,
    IN_PERIOD     VARCHAR(6)     NOT NULL,
    FOR_PERIOD     VARCHAR(6)     NOT NULL,
    PAYMENT_DATE     DATE,
    END_OF_IN_PERIOD     DATE,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SURVEY_MONKEY_EXIT_SURVEY
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 04/04/2017 09:58:47

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SURVEY_MONKEY_EXIT_SURVEY
(
    RESPONDENT_ID     CHAR(10)     NOT NULL,
    COLLECTOR_ID     VARCHAR(10)     NOT NULL,
    START_DATE     DATE,
    END_DATE     DATE,
    IP_ADDRESS     VARCHAR(16)     NOT NULL,
    GRADE     VARCHAR(70),
    JURISDICTION     VARCHAR(20),
    FINAL_DATE_OF_EMPLOYMENT     DATE,
    BU_AT_TIME_OF_EXIT     VARCHAR(40)     NOT NULL,
    AGE_BRACKET     VARCHAR(20)     NOT NULL,
    LENGHT_OF_SERVICE     VARCHAR(20)     NOT NULL,
    ORGANISATION_LEVEL     VARCHAR(30),
    QUALIFICATION_DIPLOMA     VARCHAR(10),
    QUALIFICATION_BA     VARCHAR(10),
    QUALIFICATION_MA_MBA     VARCHAR(10),
    QUALIFICATION_PHD     VARCHAR(10),
    QUALIFICATION_QFA     VARCHAR(10),
    QUALIFICATION_ACCOUNTANT     VARCHAR(15),
    QUALIFICATION_SOLICITOR     VARCHAR(15),
    QUALIFICATION_OTHER     VARCHAR(10),
    QUALIFICATION_OTHER_TEXT     VARCHAR(200),
    PRIMARY_SKILL     VARCHAR(30),
    GENDER     VARCHAR(30)     NOT NULL,
    MAIN_REASON_FOR_LEAVING     VARCHAR(70)     NOT NULL,
    NEW_EMPLOYER     VARCHAR(70),
    NEW_INDUSTRY     VARCHAR(80),
    NEW_ROLE     VARCHAR(70),
    ORG_JOB_DISSATISFACTION_RSN_1     VARCHAR(100),
    ORG_JOB_DISSATISFACTION_RSN_2     VARCHAR(100),
    ORG_JOB_DISSATISFACTION_RSN_3     VARCHAR(100),
    ORG_JOB_DISSATISFACTION_RSN_4     VARCHAR(100),
    ORG_JOB_DISSATISFACTION_RSN_5     VARCHAR(100),
    ORG_JOB_DISSATISFACTION_RSN_6     VARCHAR(100),
    ORG_JOB_DISSATISFACTION_RSN_7     VARCHAR(100),
    ORG_JOB_DISSATISFACTION_RSN_8     VARCHAR(100),
    ORG_JOB_DISSATISFACTION_RSN_9     VARCHAR(100),
    ORG_JOB_DISSATISFACTION_RSN_10     VARCHAR(100),
    NEW_JOB_PENSION_DETAILS     VARCHAR(100),
    NEW_JOB_BONUS_DETAILS     VARCHAR(120),
    NEW_JOB_CAR_DETAILS     VARCHAR(100),
    NEW_JOB_HEALTH_INSURANCE_DTLS     VARCHAR(100),
    NEW_JOB_OTHER_BENEFITS_DETAILS     VARCHAR(300),
    AIB_RATING_AS_PLACE_TO_WORK     CHAR(2),
    CAREER_OPPORTUNITIES_QUESTION     VARCHAR(4),
    AIB_RATING_RECOMEND_PLACE_WORK     VARCHAR(3),
    AIB_RATING_LIKELYHOOD_RETURN     VARCHAR(3),
    DIFFICULTIES_IN_WORK_QUESTION     VARCHAR(4),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_COST_DISTRIBUTION
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:39

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_COST_DISTRIBUTION
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYPE     VARCHAR(4),
    OBJECT_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    DISTRIBUTION_VAL     VARCHAR(4)     NOT NULL,
    DISTRIBUTION_TEXT     VARCHAR(40)     NOT NULL,
    COMPANY_CODE_VAL     VARCHAR(4)     NOT NULL,
    COMPANY_CODE_TEXT     VARCHAR(25)     NOT NULL,
    COST_CENTER_VAL     VARCHAR(10),
    COST_CENTER_TEXT     VARCHAR(20),
    ORDER_VAL     VARCHAR(12),
    ORDER_TEXT     VARCHAR(20),
    WBS_ELEMENT_VAL     CHAR(15),
    WBS_ELEMENT_TEXT     VARCHAR(40),
    PERCENTAGE     DECIMAL(5,2)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_EDUCATION
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:39

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_EDUCATION
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYPE     VARCHAR(4)     NOT NULL,
    OBJECT_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    EDUCATIONAL_EST_VAL     VARCHAR(2)     NOT NULL,
    EDUCATIONAL_EST_TEXT     VARCHAR(20)     NOT NULL,
    ET_CATEGORY_VAL     CHAR(8),
    ET_CATEGORY_TEXT     VARCHAR(40),
    COUNTRY_KEY_VAL     VARCHAR(3)     NOT NULL,
    COUNTRY_KEY_TEXT     VARCHAR(15)     NOT NULL,
    CERTIFICATE_VAL     VARCHAR(2)     NOT NULL,
    CERTIFICATE_TEXT     VARCHAR(40)     NOT NULL,
    COURSE_DURATION     DECIMAL(3,0),
    COURSE_DUR_UNITS_VAL     VARCHAR(3),
    COURSE_DUR_UNITS_TEXT     VARCHAR(20),
    BRANCH_OF_STUDY1_VAL     CHAR(5)     NOT NULL,
    BRANCH_OF_STUDY1_TEXT     VARCHAR(40),
    BRANCH_OF_STUDY2_VAL     CHAR(5),
    BRANCH_OF_STUDY2_TEXT     VARCHAR(40),
    COURSE_APPRAISAL     VARCHAR(40),
    COURSE_FEES     DECIMAL(11,2),
    CURRENCY     VARCHAR(5),
    UNIVERSITY_COLLEGE     VARCHAR(80),
    INSTITUTE_LOCATION     VARCHAR(80)     NOT NULL,
    COURSE_NAME     VARCHAR(80),
    FINANCED_BY     VARCHAR(12),
    FINAL_MARK     VARCHAR(12),
    QUALIFICATION_STATUS     VARCHAR(12),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_IOB_CPD_HOURS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:39

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_IOB_CPD_HOURS
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYPE     VARCHAR(4),
    OBJECT_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    IOB_DESIGNATION     VARCHAR(10)     NOT NULL,
    CPD_YEAR     CHAR(4)     NOT NULL,
    TOTAL_REQUIRED     DECIMAL(5,2)     NOT NULL,
    TOTAL_LOGGED     DECIMAL(5,2)     NOT NULL,
    TOTAL_RETURNED     DECIMAL(5,2)     NOT NULL,
    TOTAL_BALANCE     DECIMAL(5,2)     NOT NULL,
    SHORTFALL     VARCHAR(1)     NOT NULL,
    SUBMITTED_IND     VARCHAR(1)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_SAP_SICKNESS_OCCURRENCE
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 03/04/2017 09:54:39

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE  TABLE HR_SAP_SICKNESS_OCCURRENCE
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    START_DATE     DATE,
    OCCURRENCE_START_DATE     DATE,
    REPORT_START_DATE     DATE,
    END_DATE     DATE,
    LONG_TERM_SICK_LEAVE_START_DATE     DATE,
    ABSENCE_TYPE     VARCHAR(4)     NOT NULL,
    ABSENCE_ID     VARCHAR(2)     NOT NULL,
    ABSENCE_DESCRIPTION     VARCHAR(25)     NOT NULL,
    ABSENCE_TEXT_DETAILED     VARCHAR(35),
    DESCRIPTION_OF_ILLNESS     VARCHAR(20),
    ILLNESS_CODE     VARCHAR(6),
    ABSENCE_DAYS     DECIMAL(7,2)     NOT NULL,
    ABSENCE_FULL_PAID_DAYS     DECIMAL(7,2)     NOT NULL,
    ABSENCE_HALF_PAID_DAYS     DECIMAL(7,2)     NOT NULL,
    ABSENCE_NIL_PAID_DAYS     DECIMAL(7,2)     NOT NULL,
    ABSENCE_INCOME_PROTECTION_HALF_PAID_DAYS     DECIMAL(7,2)     NOT NULL,
    ABSENCE_INCOME_PROTECTION_NIL_PAID_DAYS     DECIMAL(7,2)     NOT NULL,
    ABSENCE_UNDEFINED_DAYS     DECIMAL(7,2)     NOT NULL,
    PAYROLL_DAYS     DECIMAL(7,2)     NOT NULL,
    PAYROLL_FULL_PAID_DAYS     DECIMAL(7,2)     NOT NULL,
    PAYROLL_HALF_PAID_DAYS     DECIMAL(7,2)     NOT NULL,
    PAYROLL_NIL_PAID_DAYS     DECIMAL(7,2)     NOT NULL,
    PAYROLL_INCOME_PROTECTION_HALF_PAID_DAYS     DECIMAL(7,2)     NOT NULL,
    PAYROLL_INCOME_PROTECTION_NIL_PAID_DAYS     DECIMAL(7,2)     NOT NULL,
    PAYROLL_UNDEFINED_DAYS     DECIMAL(7,2)     NOT NULL,
    AIB_DAYS_LOST     DECIMAL(7,2)     NOT NULL,
    AIB_FULLY_PAID_DAYS_LOST     DECIMAL(7,2)     NOT NULL,
    AIB_HALF_PAID_DAYS_LOST     DECIMAL(7,2)     NOT NULL,
    AIB_NIL_PAID_DAYS_LOST     DECIMAL(7,2)     NOT NULL,
    AIB_INCOME_PROTECTION_HALF_PAID_DAYS_LOST     DECIMAL(7,2)     NOT NULL,
    AIB_INCOME_PROTECTION_NIL_PAID_DAYS_LOST     DECIMAL(7,2)     NOT NULL,
    AIB_UNDEFINED_DAYS_LOST     DECIMAL(7,2)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     VARCHAR(30)     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT     NOT NULL,
       SRCE_INST    SMALLINT     NOT NULL,
       LOAD_DTE    DATE
    )
; 
/*=============================================
-- TABLE              : HR_CS_ILEARN_TRAINING_INFO
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 31/01/2017 10:23:58

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_CS_ILEARN_TRAINING_INFO
(
    LOID     VARCHAR(36)     NOT NULL,
    USER_ID     VARCHAR(100),
    TRAINING_ID     VARCHAR(36),
    TRAINING_TITLE     VARCHAR(500),
    TRAINING_RECORD_ REGISTR_DATE     TIMESTAMP,
    TRAINING_STATUS     VARCHAR(11),
    TRAINING_RECORD_CMPLTN_DATE     TIMESTAMP,
    TRAINING_TYPE     VARCHAR(21),
    SESSION_TYPE     VARCHAR(100),
    TRAINING_HOURS     CHAR(6),
    TRAINING_TOPICS     VARCHAR(100),
    TRAINING_RECORD_SCORE     INTEGER,
    TRAINING_VENDOR     VARCHAR(100),
    GRADE     VARCHAR(100),
    DEPARTMENT_BRANCH     VARCHAR(100),
    DEPARTMENT_BRANCH_REF     VARCHAR(100),
    ACCENTURE_ACTIVE_CATALOGUE     VARCHAR(100),
    LEARNING_TYPE     VARCHAR(100),
    LAST_MODIFIED_DATE     TIMESTAMP,
    LAST_MODIFIED_BY_USER_ID     VARCHAR(100),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_ACTIVE_ORG_STRUCTURE
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 27/01/2017 10:29:59

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_ACTIVE_ORG_STRUCTURE
(
    LEVEL_0_OBJECT_ID     CHAR(8),
    LEVEL_0_TEXT     VARCHAR(40)     NOT NULL,
    LEVEL_0_SHORT     VARCHAR(12)     NOT NULL,
    EMPLOYER_OBJECT_ID     CHAR(8),
    EMPLOYER_TEXT     VARCHAR(40),
    EMPLOYER_SHORT     VARCHAR(12),
    LEVEL_1_OBJECT_ID     CHAR(8),
    LEVEL_1 _TEXT     VARCHAR(40),
    LEVEL_1_SHORT     VARCHAR(12),
    LEVEL_2_OBJECT_ID     CHAR(8),
    LEVEL_2_TEXT     VARCHAR(40),
    LEVEL_2_SHORT     VARCHAR(12),
    LEVEL_3_OBJECT_ID     CHAR(8),
    LEVEL_3_TEXT     VARCHAR(40),
    LEVEL_3_SHORT     VARCHAR(12),
    LEVEL_4_OBJECT_ID     CHAR(8),
    LEVEL_4_TEXT     VARCHAR(40),
    LEVEL_4_SHORT     VARCHAR(12),
    OBJECTID     CHAR(8)     NOT NULL,
    OBJ_NAME     VARCHAR(40),
    OBJECT_ABBR     VARCHAR(12)     NOT NULL,
    COST_CTR     VARCHAR(10),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_ABSENCES
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 27/01/2017 10:34:18

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_ABSENCES
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    ABSENCE_TYPE_VAL     VARCHAR(4)     NOT NULL,
    ABSENCE_TYPE_TEXT     VARCHAR(25)     NOT NULL,
    ABSENCE_START_TIME     TIMESTAMP     NOT NULL,
    ABSENCE_END_TIME     TIMESTAMP     NOT NULL,
    ABSENCE_HOURS     DECIMAL(7,2)     NOT NULL,
    ABSENCE_DAYS     DECIMAL(6,2)     NOT NULL,
    CALENDAR_DAYS     DECIMAL(6,2)     NOT NULL,
    PAYROLL_DAYS     DECIMAL(6,2)     NOT NULL,
    PAYROLL_HOURS     DECIMAL(7,2)     NOT NULL,
    FULL_DAY_IND     VARCHAR(1),
    ILLNESS_DESC_CODE     VARCHAR(6),
    ILLNESS_DESCRIPTION     VARCHAR(20),
    STAFF_IN_PAYMENT_HC     CHAR(1)     NOT NULL,
    AVAILABLE_HEADCOUNT     CHAR(1)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_ACTIONS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 27/01/2017 10:34:18

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_ACTIONS
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    ACTION_TYPE_VAL     CHAR(2)     NOT NULL,
    ACTION_TYPE_TEXT     VARCHAR(40)     NOT NULL,
    ACTION_REASON_VAL     CHAR(2),
    ACTION_REASON_TEXT     VARCHAR(40)     NOT NULL,
    EMPLOYMT_STATUS_VAL     CHAR(1)     NOT NULL,
    EMPLOYMT_STATUS_TEXT     VARCHAR(40)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_ADDITIONAL_ACTIONS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 27/01/2017 10:34:18

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_ADDITIONAL_ACTIONS
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    ACTION_TYPE_VAL     VARCHAR(2)     NOT NULL,
    ACTION_TYPE_TEXT     VARCHAR(40)     NOT NULL,
    ACTION_REASON_VAL     VARCHAR(2),
    ACTION_REASON_TEXT     VARCHAR(40)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_BASIC_PAY_ANNUAL_SALARY
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 27/01/2017 10:34:18

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_BASIC_PAY_ANNUAL_SALARY
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    REASON_FOR_CHGE_VAL     VARCHAR(2),
    REASON_FOR_CHGE_TEXT     VARCHAR(30),
    PAY_SCALE_TYPE_VAL     VARCHAR(2)     NOT NULL,
    PAY_SCALE_TYPE_TEXT     VARCHAR(20)     NOT NULL,
    PAY_SCALE_AREA_VAL     VARCHAR(2)     NOT NULL,
    PAY_SCALE_AREA_TEXT     VARCHAR(20)     NOT NULL,
    PAY_SCALE_GROUP     VARCHAR(8),
    PAY_SCALE_LEVEL     VARCHAR(2),
    CAPACITY_UTIL_LEVEL     DECIMAL(5,2)     NOT NULL,
    WORK_HOURS_PERIOD     DECIMAL(5,2)     NOT NULL,
    NEXT_INCREASE     DATE,
    ANNUAL_SALARY     DECIMAL(15,2)     NOT NULL,
    CRCY_FOR_ANNUAL_SAL     DECIMAL(5)     NOT NULL,
    MINIMUM_PAY_GRADE     DECIMAL(15,2)     NOT NULL,
    MIDPOINT_PAY_GRADE     DECIMAL(15,2)     NOT NULL,
    MAXIMUM_PAY_GRADE     DECIMAL(15,2)     NOT NULL,
    PLAN_COMP_TYPE_VAL     VARCHAR(1)     NOT NULL,
    PLAN_COMP_TYPE_TEXT     VARCHAR(60)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_BASIC_PAY_WAGE_TYPES
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 27/01/2017 10:34:18

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_BASIC_PAY_WAGE_TYPES
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    WAGE_TYPE_VAL     VARCHAR(4),
    WAGE_TYPE_TEXT     VARCHAR(25),
    WAGE_TYPE_AMOUNT     DECIMAL(13,2)     NOT NULL,
    WAGE_TYPE_NUMBER     DECIMAL(7,2)     NOT NULL,
    WAGE_TYPE_UNITS_VAL     VARCHAR(3),
    WAGE_TYPE_UNITS_TEXT     VARCHAR(20),
    CURRENCY     DECIMAL(5)     NOT NULL,
    OPERATION_IND_VAL     VARCHAR(1),
    OPERATION_IND_TEXT     VARCHAR(10)     NOT NULL,
    IND_VALUATION     VARCHAR(1),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_CONTRACT_ELEMENTS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 27/01/2017 10:34:18

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_CONTRACT_ELEMENTS
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    CONTRACT_TYPE_VAL     VARCHAR(2),
    CONTRACT_TYPE_TEXT     VARCHAR(20),
    PROB_PERIOD_NO     DECIMAL(3,0),
    PROB_PER_UNITS_VAL     VARCHAR(3),
    PROB_PER_UNITS_TEXT     VARCHAR(20),
    ER_NOTICE_PER_VAL     VARCHAR(2),
    ER_NOTICE_PER_TEXT     VARCHAR(20),
    EE_NOTICE_PER_VAL     VARCHAR(2),
    EE_NOTICE_PER_TEXT     VARCHAR(20),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_DATE_SPECIFICATIONS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 27/01/2017 10:34:18

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_DATE_SPECIFICATIONS
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    DATE_TYPE_VAL     VARCHAR(2)     NOT NULL,
    DATE_TYPE_TEXT     VARCHAR(20)     NOT NULL,
    DATE_FOR_DATE_TYPE     DATE,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_MONITORING_OF_TASKS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 27/01/2017 10:34:18

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_MONITORING_OF_TASKS
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    TASK_TYPE_VAL     VARCHAR(2)     NOT NULL,
    TASK_TYPE_TEXT     VARCHAR(20)     NOT NULL,
    DATE_OF_TASK     DATE,
    PROCESSING_IND_VAL     VARCHAR(1),
    PROCESSING_IND_TEXT     VARCHAR(20)     NOT NULL,
    REMINDER_DATE     DATE,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_ORG_ASSIGNMENT
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 27/01/2017 10:34:18

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_ORG_ASSIGNMENT
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    COMPANY_CODE_VAL     VARCHAR(4)     NOT NULL,
    COMPANY_CODE_TEXT     VARCHAR(25)     NOT NULL,
    PERSONNEL_AREA_VAL     VARCHAR(4)     NOT NULL,
    PERSONNEL_AREA_TEXT     VARCHAR(30)     NOT NULL,
    COST_CENTER_VAL     VARCHAR(10),
    COST_CENTER_TEXT     VARCHAR(20),
    PERS_SUBAREA_VAL     VARCHAR(4)     NOT NULL,
    PERS_SUBAREA_TEXT     VARCHAR(15)     NOT NULL,
    EMPLOYEE_GROUP_VAL     VARCHAR(1)     NOT NULL,
    EMPLOYEE_GROUP_TEXT     VARCVHAR(20)     NOT NULL,
    EMP_SUBGROUP_VAL     VARCHAR(2)     NOT NULL,
    EMPL_SUBGROUP_TEXT     VARCHAR(20)     NOT NULL,
    PAYROLL_AREA_VAL     VARCHAR(2)     NOT NULL,
    PAYROLL_AREA_TEXT     VARCHAR(20)     NOT NULL,
    WORK_CONTRACT_VAL     VARCHAR(2)     NOT NULL,
    WORK_CONTRACT_TEXT     VARCHAR(15)     NOT NULL,
    POSITION_VAL     CHAR(8)     NOT NULL,
    POSITION_TEXT     VARCHAR(40),
    POSITION_SHORT_TEXT     VARCHAR(12),
    JOB_CODE     VARCHAR(3),
    JOB_VAL     CHAR(8),
    JOB_SHORT_TEXT     VARCHAR(12),
    JOB_DESCRIPTION     VARCHAR(40),
    ORG_UNIT_VAL     CHAR(8),
    ORG_UNIT_TEXT     VARCHAR(40),
    ORGANIZATIONAL_KEY     VARCHAR(14),
    JOB_CATEGORY_DESC     VARCHAR(20),
    EMPLOYEE_NAME     VARCHAR(40)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_PERSONAL_DATA
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 27/01/2017 10:34:18

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_PERSONAL_DATA
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    LAST_NAME     VARCHAR(40)     NOT NULL,
    FIRST_NAME     VARCHAR(40)     NOT NULL,
    KNOWN_AS     VARCHAR(40)     NOT NULL,
    GENDER_VAL     VARCHAR(1),
    GENDER_TEXT     VARCHAR(8)     NOT NULL,
    DATE_OF_BIRTH     DATE,
    CTRY_OF_BIRTH_VAL     VARCHAR(3),
    CTRY_OF_BIRTH_TEXT     VARCHAR(50),
    COUNTY     VARCHAR(3),
    BIRTHPLACE     VARCHAR(40),
    NATIONALITY_VAL     VARCHAR(3)     NOT NULL,
    NATIONALITY_TEXT     VARCHAR(15)     NOT NULL,
    COMM_LANG_VAL     VARCHAR(1)     NOT NULL,
    COMM_LANG_TEXT     VARCHAR(16)     NOT NULL,
    MARITAL_STATUS_VAL     VARCHAR(1),
    MARITAL_STATUS_TEXT     VARCHAR(6),
    MARITAL_STATUS_DATE     DATE,
    NO_OF_CHILDREN     DECIMAL(3,0),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_PLANNED_WORKING_TIME
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 27/01/2017 10:34:18

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_PLANNED_WORKING_TIME
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    WORK_SCH_RULE_VAL     VARCHAR(8)     NOT NULL,
    WORK_SCH_RULE_TEXT     VARCHAR(25),
    TIME_MGMT_STAT_VAL     CHAR(1),
    TIME_MGMT_STAT_TEXT     VARCHAR(50)     NOT NULL,
    EMPLOYMENT_PERCENT     DECIMAL(5,2)     NOT NULL,
    MONTHLY_WORKING_HRS     DECIMAL(5,2)     NOT NULL,
    WEEKLY_WORKING_HOURS     DECIMAL(5,2)     NOT NULL,
    DAILY_WORKING_HOURS     DECIMAL(5,2)     NOT NULL,
    WEEKLY_WORKDAYS     DECIMAL(4,2)     NOT NULL,
    ANNUAL_WORKING_HOURS     DECIMAL(7,2)     NOT NULL,
    PART_TIME_EMPLOYEE     VARCHAR(1),
    FTE_WEEKLY_HOURS     DECIMAL(5,2)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_ABSENCE_QUOTAS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 01/02/2017 16:54:27

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_ABSENCE_QUOTAS
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    START_TIME     TIMESTAMP,
    END_TIME     TIMESTAMP,
    ABSENCE_QUOTA_VAL     DECIMAL(2,0),
    ABSENCE_QUOTA_TEXT     VARCHAR(20),
    QUOTA_NUMBER     DECIMAL(10,2),
    QUOTA_DEDUCTION     DECIMAL(10,2),
    DEDUCTION_FROM     DATE,
    DEDUCTION_TO     DATE,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_ADDITIONAL_PAYMENTS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 01/02/2017 16:54:27

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_ADDITIONAL_PAYMENTS
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4)     NOT NULL,
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NUMBER     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    WAGE_TYPE     VARCHAR(4)     NOT NULL,
    WAGE_TYPE_TEXT     VARCHAR(25)     NOT NULL,
    OPERATION_INDICATOR     VARCHAR(1),
    OPERATION_INDICATOR_TEXT     VARCHAR(10)     NOT NULL,
    AMOUNT     DECIMAL(13,2)     NOT NULL,
    CURRENCY     VARCHAR(5)     NOT NULL,
    IND_FOR_INDIRECT_VALUATION     VARCHAR(1),
    NUMBER     DECIMAL(7,2)     NOT NULL,
    TIME/MEASUREMENT_UNIT     VARCHAR(3),
    TIME/MEASUREMENT_UNIT_TEXT     VARCHAR(20),
    DATE_OF_ORIGIN     DATE,
    ASSIGNMENT_NUMBER     VARCHAR(20),
    RSN_FOR_CHANGING_MASTER_DATA     VARCHAR(2),
    RSN_FOR_CHNG_MASTER_DATA_TEXT     VARCHAR(30),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_ADDRESSES
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 01/02/2017 16:54:27

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_ADDRESSES
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4)     NOT NULL,
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NUMBER     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    ADDRESS_TYPE     VARCHAR(4)     NOT NULL,
    ADDRESS_TYPE_DESCRIPTION     VARCHAR(40)     NOT NULL,
    CARE_OF     VARCHAR(40),
    ADDRESS_LINE_1     VARCHAR(60),
    ADDRESS_LINE_2     VARCHAR(40),
    ADDRESS_LINE_3     VARCHAR(40),
    ADDRESS_LINE_4     VARCHAR(40),
    COUNTY_CODE     VARCHAR(3),
    COUNTY_CODE_DESCRIPTION     VARCHAR(20),
    POSTAL_CODE     VARCHAR(10),
    COUNTRY_KEY     VARCHAR(3)     NOT NULL,
    COUNTRY_NAME     VARCHAR(15)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_COST_OF_ABSENCE
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 01/02/2017 16:54:27

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_COST_OF_ABSENCE
(
    AMOUNT_IN_PAYROLL     DECIMAL(12,2)     NOT NULL,
    ORIGINAL_CURRENCY     VARCHAR(3)     NOT NULL,
    EUR_EQUIVALENT     DECIMAL(12,2)     NOT NULL,
    GBP_EQUIVALENT     DECIMAL(12,2)     NOT NULL,
    EUR_FACTORED_COST     DECIMAL(12,2)     NOT NULL,
    GBP_FACTORED_COST     DECIMAL(12,2)     NOT NULL,
    FULL_PAY_AMOUNT_EUR     DECIMAL(12,2)     NOT NULL,
    HALF_PAY_AMOUNT_EUR     DECIMAL(12,2)     NOT NULL,
    FULL_PAY_AMOUNT_GBP     DECIMAL(12,2)     NOT NULL,
    HALF_PAY_AMOUNT_GBP     DECIMAL(12,2)     NOT NULL,
    NUMBER_OF_DAYS     DECIMAL(3,0)     NOT NULL,
    EXCHANGE_RATE     DECIMAL(7,0)     NOT NULL,
    PERSONNEL_NUMBER     DECIMAL(8,0),
    PERIOD_START_DATE     DATE,
    PERIOD_END_DATE     DATE,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_EMPLOYEE_REMUNERATION
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 01/02/2017 16:54:27

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_EMPLOYEE_REMUNERATION
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    WAGE_TYPE_VAL     VARCHAR(4)     NOT NULL,
    WAGE_TYPE_TEXT     VARCHAR(25)     NOT NULL,
    NUMBER_OF_HOURS     DECIMAL(7,2)     NOT NULL,
    NUMBER_PER_TIME_UNIT     DECIMAL(7,2),
    WAGE_TYPE_UNITS_VAL     VARCHAR(3),
    WAGE_TYPE_UNITS_TEXT     VARCHAR(20),
    WAGE_TYPE_AMOUNT     DECIMAL(13,2),
    WAGE_TYPE_CURRENCY     VARCHAR(5),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_NEW_EXTERNALS_INFOTYPE
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 01/02/2017 16:54:27

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_NEW_EXTERNALS_INFOTYPE
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    CONTRACT_IN_PLACE     VARCHAR(1),
    PERM_STATION_REQ     VARCHAR(1),
    SOLE_TRADER     VARCHAR(1),
    COMPANY_LESS_THAN_5     VARCHAR(1),
    CONTRACTOR_COST_CAP     VARCHAR(1),
    CONTRACTOR_COMPANY     VARCHAR(40),
    PROJECT_NAME     VARCHAR(40),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_PENSIONS_GB
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 01/02/2017 16:54:27

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_PENSIONS_GB
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4)     NOT NULL,
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    SCHEME_REFERENCE     VARCHAR(20)     NOT NULL,
    PENSION_SCHEME_NAME     VARCHAR(30),
    LOW_BAND_LEVEL     DECIMAL(9,2),
    HIGH_BAND_LEVEL     DECIMAL(9,2),
    EMPLOYEE_LWR_BAND_PERCENT     DECIMAL(7,4)     NOT NULL,
    EMPLOYER_LWR_BAND_PERCENT     DECIMAL(7,4)     NOT NULL,
    EMPLOYEE_MID_BAND_PERCENT     DECIMAL(7,4)     NOT NULL,
    EMPLOYER_MID_BAND_PERCENT     DECIMAL(7,4)     NOT NULL,
    EMPLOYEE_UPP_BAND_PERCENT     DECIMAL(7,4)     NOT NULL,
    EMPLOYER_UPP_BAND_PERCENT     DECIMAL(7,4)     NOT NULL,
    FLAT_RATE_AVC     DECIMAL(9,2)     NOT NULL,
    FLAT_RATE_FSAVC     DECIMAL(9,2)     NOT NULL,
    PERCENTAGE_AVC     DECIMAL(7,4)     NOT NULL,
    CURRENCY     VARCHAR(5)     NOT NULL,
    PENSION_CAP_EXCL     VARCHAR(1),
    EE_SPEC_RECORD_IND     VARCHAR(1),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_PENSIONS_IRELAND
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 01/02/2017 16:54:27

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_PENSIONS_IRELAND
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4),
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    SCHEME_REFERENCE     VARCHAR(3)     NOT NULL,
    PENSION_SCHEME_NAME     VARCHAR(40),
    EMPLOYEE_PERCENTAGE     DECIMAL(7,4)     NOT NULL,
    EMPLOYEE_PERIOD_CONT     DECIMAL(11)     NOT NULL,
    EMPLOYEE_FLAT_AMT     DECIMAL(11)     NOT NULL,
    EMPLOYEE_WAGE_TYPE     VARCHAR(4),
    EMPLOYER_PERCENTAGE     DECIMAL(7,4)     NOT NULL,
    EMPLOYER_PERIOD_CONT     DECIMAL(11,2)     NOT NULL,
    EMPLOYER_FLAT_AMT     DECIMAL(11,2)     NOT NULL,
    EMPLOYER_WAGE_TYPE     VARCHAR(4),
    AVC_PERCENTAGE     DECIMAL(7,4)     NOT NULL,
    AVC_PERIOD_CONT     DECIMAL(11,2)     NOT NULL,
    AVC_FLAT_AMT     DECIMAL(11,2)     NOT NULL,
    AVC_WAGE_TYPE     VARCHAR(4),
    CURRENCY     VARCHAR(5)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_RECURRING_PMT_DEDUCT
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 01/02/2017 16:54:27

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_RECURRING_PMT_DEDUCT
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4)     NOT NULL,
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NO     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    WAGE_TYPE_VAL     VARCHAR(4)     NOT NULL,
    WAGE_TYPE_TEXT     VARCHAR(25)     NOT NULL,
    OPERATION_IND_VAL     VARCHAR(1),
    OPERATION_IND_TEXT     VARCHAR(10)     NOT NULL,
    WAGE_TYPE_AMOUNT     DECIMAL(13,2)     NOT NULL,
    WAGE_TYPE_CURRENCY     VARCHAR(5)     NOT NULL,
    IND_VALUATION     VARCHAR(1),
    WAGE_TYPE_NUMBER     DECIMAL(7,2)     NOT NULL,
    WAGE_TYPE_UNITS_VAL     VARCHAR(3),
    WAGE_TYPE_UNITS_TEXT     VARCHAR(20),
    ASSIGNMENT_NUMBER     VARCHAR(20),
    REASON_FOR_CHG_VAL     VARCHAR(2),
    REASON_FOR_CHG_TEXT     VARCHAR(30),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SAP_STATISTICS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 01/02/2017 16:54:27

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SAP_STATISTICS
(
    PERSONNEL_NUMBER     CHAR(8)     NOT NULL,
    SUBTYP     VARCHAR(4)     NOT NULL,
    OBJ_ID     VARCHAR(2),
    END_DATE     DATE,
    START_DATE     DATE,
    INFOTYPE_RECORD_NUMBER     VARCHAR(3),
    CHANGED_ON     DATE,
    CHANGED_BY     VARCHAR(12)     NOT NULL,
    STATISTICS_TEXT     VARCHAR(40)     NOT NULL,
    STATISTICS_INDICATOR     CHAR(2),
    STATISTICS_INDICATOR_TEXT     VARCHAR(10),
    STATISTIC_EXCEPTIONS     VARCHAR(4),
    STATISTIC_EXCEPTIONS_TEXT     VARCHAR(30),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SF_APPL_RECEIVED_PER_POS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 31/01/2017 11:01:43

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SF_APPL_RECEIVED_PER_POS
(
    APPLICATION_DATE     DATE,
    APPLICATION_ID     CHAR(20)     NOT NULL,
    RCM_APPLICATION_JOB_REQ_ID     CHAR(20)     NOT NULL,
    REQUISITION_STATUS     VARCHAR(20)     NOT NULL,
    APPLICATION_STATUS     VARCHAR(100)     NOT NULL,
    HR_RECRUITER_FIRST_NAME     VARCHAR(100)     NOT NULL,
    HR_RECRUITER_LAST_NAME     VARCHAR(50)     NOT NULL,
    AGENCY_NAME     VARCHAR(50),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SF_EMPL_PROFILE
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 31/01/2017 11:01:43

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SF_EMPL_PROFILE
(
    STAFF_NUMBER     CHAR(50)     NOT NULL,
    FIRST_NAME     VARCHAR(50)     NOT NULL,
    LAST_NAME     VARCHAR(50)     NOT NULL,
    REVIEWER     CHAR(20)     NOT NULL,
    MANAGER     CHAR(20)     NOT NULL,
    MANAGER_FIRST_NAME     VARCHAR(50)     NOT NULL,
    MANAGER_LAST_NAME     VARCHAR(50)     NOT NULL,
    MATRIX_MANAGER_FIRST_NAME     VARCHAR(50)     NOT NULL,
    MATRIX_MANAGER_LAST_NAME     VARCHAR(50)     NOT NULL,
    FROM_DATE     TIMESTAMP,
    TO_DTE     TIMESTAMP,
    TITLE_EMPLOYEE_INT_WORKHIST     VARCHAR(50),
    BUSINESS_INTERNAL_WORKHISTORY     VARCHAR(50),
    DEPT_EMP_INTERNALWORKHISTORY     VARCHAR(50),
    FROM_DATE_EMP_EXT_WORKHISTORY     TIMESTAMP,
    END_DATE_EMP_EXT_WORKHISTORY     TIMESTAMP,
    COMPANY_NAME     VARCHAR(50),
    TITLE_EMP_EXTERNALWORKHISTORY     VARCHAR(50),
    DESCRIPTION     VARCHAR(50),
    FROM_DTE_EMP_EXTWORKHIST_START     TIMESTAMP,
    END_DTE_EMP_EXTWORKHIST_END     TIMESTAMP,
    ASSIGNMENT_PROJECT     VARCHAR(50),
    DESCRIPTION_EMP_SPECIALASSIGN     VARCHAR(50),
    FROM_DATE_EMP_SPECIALASSIGN     TIMESTAMP,
    END_DATE_EMP_SPECIALASSIGN     TIMESTAMP,
    UNIVERSITY_COLLEGE     VARCHAR(50),
    IF_OTHER_UNIVERSITY_MENTION     VARCHAR(50),
    SUBJECT     VARCHAR(50),
    IF_OTHER_SUBJECT_MENTION     VARCHAR(50),
    EDUCATION     VARCHAR(50),
    IF_OTHER_EDUCATION_MENTION     VARCHAR(50),
    QUALIFICATION     VARCHAR(50),
    CERTIFICATION_LICENSE     VARCHAR(50),
    DESCRIPTION_EMP_CERTIFICATIONS     VARCHAR(50),
    INSTITUTION     VARCHAR(50),
    EFFECTIVE_DATE     TIMESTAMP,
    EXPIRATION_DATE     TIMESTAMP,
    LANG     VARCHAR(50),
    IF_OTHER_PLEASE_MENTION     VARCHAR(50),
    SPEAKING_PROFICIENCY     VARCHAR(50),
    READING_PROFICIENCY     VARCHAR(50),
    WRITING_PROFICIENCY     VARCHAR(50),
    TECHNICAL_COMPETENCY     VARCHAR(50),
    LEVEL_EMPLOYEE_TECHNICAL     VARCHAR(50),
    COMMENTS_EMPLOYEE_TECHNICAL     VARCHAR(50),
    IT_AND_SYSTEM_AREA     VARCHAR(50),
    LEVEL_EMPLOYEE_IT     VARCHAR(50),
    COMMENTS_EMPLOYEE_IT     VARCHAR(50),
    PROFESSIONAL_COMPETENCY     VARCHAR(50),
    LEVEL_EMPLOYEE_PROFESSIONAL     VARCHAR(50),
    PROFESSIONAL_MEMBERSHIP_BODY     VARCHAR(50),
    COMMUNITY_VOLUNTEER_ORG_NAME     VARCHAR(50),
    ROLE_EMPLOYEE_COMMUNITY     VARCHAR(50),
    FROM_DATE_EMPLOYEE_COMMUNITY     TIMESTAMP,
    END_DATE_EMPLOYEE_COMMUNITY     TIMESTAMP,
    BUSINESS_EMPLOYEE_CAREER     VARCHAR(50),
    DEPARTMENT_EMPLOYEE_CAREER     VARCHAR(50),
    PREFERENCE     VARCHAR(50),
    TIMEFRAME     VARCHAR(50),
    COMMENTS_EMPLOYEE_CAREER     VARCHAR(50),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SF_INTERVIEW_REPORT
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 31/01/2017 11:01:43

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SF_INTERVIEW_REPORT
(
    REQUISITION_ID     CHAR(20)     NOT NULL,
    JOB_TITLE     VARCHAR(50),
    APPLICATION_ID     CHAR(20),
    APPLICANT_NAME     VARCHAR(50)     NOT NULL,
    INTERVIEW_DATE     DATE,
    INTERVIEWER     VARCHAR(50)     NOT NULL,
    COMPETENCY     VARCHAR(50)     NOT NULL,
    COMPETENCY_RATING     CHAR(5)     NOT NULL,
    COMMENTS     VARCHAR(1000)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SF_OBJECTIVE_MANAGEMENT
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 31/01/2017 11:01:43

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SF_OBJECTIVE_MANAGEMENT
(
    OBJECTIVE_PLAN_NAME     VARCHAR(50)     NOT NULL,
    OBJECTIVE_PLAN_STATE     VARCHAR(50),
    OBJ_PLAN_DATA_LAST_MOD_DTE     DATE,
    OBJECTIVE_OWNER_STAFF_NUMBER     CHAR(7)     NOT NULL,
    OBJECTIVE_OWNER_EMAIL     VARCHAR(50)     NOT NULL,
    NUMBERING     CHAR(5)     NOT NULL,
    OBJECTIVE_ID     CHAR(10)     NOT NULL,
    GOAL     VARCHAR(10000)     NOT NULL,
    OBJECTIVE_TYPE     VARCHAR(20)     NOT NULL,
    WHAT     VARCHAR(50),
    HOW     VARCHAR(50),
    LAST_MODIFIED_DATE     DATE,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SF_PERFM_MGMT_GEN_DATA
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 31/01/2017 11:01:43

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SF_PERFM_MGMT_GEN_DATA
(
    FORM_TEMPLATE_ID     CHAR(20)     NOT NULL,
    LT_FORM_SUBJECT_USR_SYS_USRNME     CHAR(20)     NOT NULL,
    REVIEWEE_FIRST_NAME     VARCHAR(50),
    REVIEWEE_LAST_NAME     VARCHAR(50),
    FORM_START_DATE     DATE,
    FORM_END_DATE     DATE,
    FORM_DUE_DATE     DATE,
    FORM_CREATION_DATE     TIMESTAMP     NOT NULL,
    LAST_MODIFIED_DATE     TIMESTAMP     NOT NULL,
    FORM_TEMPLATE_NAME     VARCHAR(50)     NOT NULL,
    CURR_ROUTE_STEP_NME_NOT_SUPP     VARCHAR(50),
    OVERALL_PERFORMANCE_RATING     CHAR(5),
    OVERALL_PERFM_RATING_DESCR     VARCHAR(10000),
    COMPETENCY_ID     CHAR(20),
    COMPETENCY_NAME     VARCHAR(50),
    COMPETENCY_OFFICIAL_RATING     CHAR(5),
    COMPETENCY_OFFICIAL_RTE_DESCR     VARCHAR(50),
    STATUS     VARCHAR(20)     NOT NULL,
    CURRENT_ROUTE_STEP_NAME     VARCHAR(50)     NOT NULL,
    LT_SECTION_CUSTOM_FIELD_ID     CHAR(20)     NOT NULL,
    LT_SECTION_CUSTOM_FIELD_NAME     VARCHAR(50)     NOT NULL,
    LT_SECTION_CUSTOM_FIELD_VALUE     CHAR(5)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SF_PERFORMANCE_MGT_NARRATIVE
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 31/01/2017 11:01:43

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SF_PERFORMANCE_MGT_NARRATIVE
(
    REVIEWEE_FIRST_NAME     VARCHAR(50)     NOT NULL,
    REVIEWEE_LAST_NAME     VARCHAR(50)     NOT NULL,
    REVIEWEE_EMAIL     VARCHAR(50)     NOT NULL,
    SECTION_ID     CHAR(20)     NOT NULL,
    SECTION_NAME     VARCHAR(100),
    SECTION_COMMENT     VARCHAR(10000),
    SECTION_COMMENT_OWNER_USER_ID     CHAR(20),
    SECTION_CMNT_OWNER_USER_NAME     VARCHAR(50),
    FORM_TITLE     VARCHAR(50)     NOT NULL,
    STATUS     VARCHAR(50)     NOT NULL,
    MANAGER_FIRST_NAME     VARCHAR(50)     NOT NULL,
    MANAGER_LAST_NAME     VARCHAR(50)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SF_RECRUITMENT_DAYS_TO_FILL
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 31/01/2017 11:01:43

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SF_RECRUITMENT_DAYS_TO_FILL
(
    CANDIDATE_PROGRESS_IN_PROS     VARCHAR(50),
    RCM_JOB_REQ_LOCAL_JOB_TITLE     VARCHAR(50)     NOT NULL,
    RCM_JOB_REQ_JOB_REQ_ID     CHAR(20)     NOT NULL,
    RCM_JOB_REQ_EXT_PICKLIST2     VARCHAR(50),
    RCM_JOB_REQ_EXT_TEXT1     VARCHAR(50),
    RCM_JOB_REQ_EXT_PICKLIST18     VARCHAR(50),
    RCM_JOB_REQ_JOB_DIVISION     CHAR(20),
    RCM_JOB_REQ_JOB_DEPARTMENT     VARCHAR(50),
    OFFER_DETAIL_REQ_ACT_START_DTE     DATE,
    RCM_APPLICATION_FIRSTNAME     VARCHAR(50),
    RCM_APPLICATION_LASTNAME     VARCHAR(50),
    RCM_APPLICATION_EXT_DATE2     DATE,
    RCM_OFFER_DETAIL_APP_CAND_NAME     VARCHAR(50),
    RCM_OFFER_DTL_REQ_CAND_HIRED     VARCHAR(10),
    RCM_CANDIDATE_CANDIDATE_ID     CHAR(20),
    RCM_APPLICATION_EXT_TEXT21     VARCHAR(50),
    RCM_APPLICATION_EXT_PICKLIST18     VARCHAR(50),
    RCM_APPLICATION_EXT_PICKLIST17     VARCHAR(50),
    RCM_OFFER_DETAIL_APP_EXT_TEXT9     CHAR(20),
    RCM_JOB_REQ_EXT_TEXT10     VARCHAR(50),
    RCM_APPLICATION_EXT_PICKLIST36     VARCHAR(20),
    RCM_APP_STATUS_AUD_APPL_ID     CHAR(20),
    RCM_APPLICATION_EXT_TEXT25     CHAR(10),
    RCM_APPLICATION_APP_LOCALE     CHAR(50),
    SET_ITEM_LOCAL_STATUS_LABEL     VARCHAR(50),
    RCM_APPLICATION_EXT_TEXT24     VARCHAR(50),
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE              : HR_SF_RECRUITMENT_FILLED_REQ
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 31/01/2017 11:01:43

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SF_RECRUITMENT_FILLED_REQ
(
    JOB_REQ_ID     CHAR(20)     NOT NULL,
    JOB_TITLE     VARCHAR(50)     NOT NULL,
    GRADE_OR_CAREER_BAND     VARCHAR(50)     NOT NULL,
    REQUISITION_TYPE     VARCHAR(20)     NOT NULL,
    NUMBER_OF_OPENINGS     CHAR(2)     NOT NULL,
    HR_RECRUITER_FIRST_NAME     VARCHAR(50)     NOT NULL,
    HR_RECRUITER_LAST_NAME     VARCHAR(50)     NOT NULL,
    REQUISITION_STATUS     VARCHAR(100)     NOT NULL,
    STATUS     VARCHAR(100)     NOT NULL,
    PERIOD_DTE     DATE,
    SRCE_SYS     SMALLINT     NOT NULL,
    SRCE_INST     SMALLINT     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_DTE     DATE,
    LOAD_TIME     TIMESTAMP     NOT NULL,
)
; 
*//*=============================================
-- TABLE              : HR_SF_RECRUITMENT_GENERAL_INFO
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : 41774
-- CREATE DATE        : 31/01/2017 11:01:43

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/

/*
CREATE  TABLE HR_SF_RECRUITMENT_GENERAL_INFO
(
    JOB_REQ_ID     CHAR(20)     NOT NULL,
    CNTRY_WHERE_VAC_IS_REQUIRED     VARCHAR(50)     NOT NULL,
    APPLICATION_DATE     DATE,
    APPLICATION_ID     CHAR(20)     NOT NULL,
    CANDIDATE_ID     CHAR(20)     NOT NULL,
    EMPLOYEE_ID     CHAR(20)     NOT NULL,
    FIRST_NAME     VARCHAR(50)     NOT NULL,
    LAST_NAME     VARCHAR(50)     NOT NULL,
    APPLICATION_STATUS_LABEL     VARCHAR(50)     NOT NULL,
    JOB_TITLE     VARCHAR(50)     NOT NULL,
    DEPARTMENT     VARCHAR(50),
    GRADE     VARCHAR(50)     NOT NULL,
    HR_RECRUITER_FIRST_NAME     VARCHAR(50)     NOT NULL,
    HR_RECRUITER_LAST_NAME     VARCHAR(50)     NOT NULL,
    SOURCE     VARCHAR(50),
    HOW_DID_YOU_HEAR_ABOUT_POS     VARCHAR(20),
    APPLICATION_STATUS     VARCHAR(100)     NOT NULL,
    EMAIL_ADDRESS     VARCHAR(100)     NOT NULL,
    HAVE_YOU_WORKED_IN_AIB_BEFORE     VARCHAR(20)     NOT NULL,
    REQUISITION_TYPE     VARCHAR(20)     NOT NULL,
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL,
    LOAD_TIME     TIMESTAMP     NOT NULL,
PERIOD_DTE    DATE,
       SRCE_SYS    SMALLINT,
       SRCE_INST    SMALLINT,
       LOAD_DTE    DATE
    )
; 
*//*=============================================
-- TABLE		:
-- FUNCTION		: 
-- STEPS		: 
-- AUTHOR		:	
-- CREATE DATE	: 

-- DESCRIPTION	: 


-- =============================================*/

/*
CREATE HADOOP TABLE "TABLE" 
(
	"COL1"	VARCHAR(250),
"DATE COL" DATE 
	)
;
*/