# -*- coding: utf-8 -*-
"""
Created on Mon Feb  6 11:28:17 2017

@author: Colm Coughlan. Data Science and Solutions. 40631

N.B. Jenkins python is now at python 2.7.4!
"""

# grab modules - need to check that modules exist in some cases

import sys
import os
import re
from plugins.utilities import parse_args, filesys_op, str_replace, move_solr_configs, extract_variable
from plugins.executable import python_exec, maven_build, git_command
from plugins.ssh import scp, remote_sql, remote_exec, rsync, connect_to_build_server, update_from_build_server, clean_build_server

from subprocess import Popen


"""
This is a modular pipeline that runs a set number of tasks. The types of supported tasks can be found in the plugins documentation.
"""
def pipeline():
    
    if sys.version_info[0] > 2:
        import configparser as cfg_parser
    else:
        import ConfigParser as cfg_parser
        
    have_argparse = True
    try:
        import argparse
    except ImportError:
        have_argparse = False
        
    
    
    
    # Check arguments
    
    if(have_argparse):
        parser = argparse.ArgumentParser(description='Start pipeline. Give effect home and pipeline dirs as arguments.')
        parser.add_argument('cfg_file', type=str, help='The configuration file (relative to home)')
        parser.add_argument('extra_args',type=str, help='Comma separated string of additional variables')
        main_args = vars(parser.parse_args())  # get args
    
    else:
        if(len(sys.argv) == 3):
            main_args = {'cfg_file': sys.argv[1]}
            main_args['extra_args'] = sys.argv[2]
        else:
            print('Argument error.')
            raise(Exception)
    
    # use the default configuration file or VM file if specified
    if main_args['cfg_file'] == 'default':
        main_args['cfg_file'] = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'default_deployment.ini')
    elif main_args['cfg_file'] == 'default_with_stg':
        main_args['cfg_file'] = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'default_with_stg_deployment.ini')
    elif main_args['cfg_file'] == 'vm':
        main_args['cfg_file'] = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'vm_deploy.ini')
    elif main_args['cfg_file'] == 'production':
        main_args['cfg_file'] = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'production_deployment.ini')
    
    if len(main_args['extra_args']) > 0:
        full_arg_str = re.sub(r',\s+',',',main_args['extra_args'])
        for extra_arg in full_arg_str.split(','):
            extra_arg_list = extra_arg.split('=')
            if extra_arg_list[0] != 'cfg_file':
                main_args[extra_arg_list[0]] = '='.join(extra_arg_list[1:])
    
    # add top level dirs to main_args
    
    cwd = os.getcwd()
    main_args['jenkins_wd'] = cwd
    main_args['pipeline_name'] = main_args['jenkins_wd'].split(os.path.sep)[-1]
    for directory in next(os.walk(cwd))[1]:
        if '.' not in directory:
            main_args[directory] = os.path.join(cwd, directory)
            
            
    # read configuration
        
    print("Reading configuration file from "+main_args['cfg_file'])
    config = cfg_parser.ConfigParser()
    config.read(main_args['cfg_file'])
    
    # make sure the file at least seems to be valid
    
    if 'control' not in config.sections():
        print('Error: control parameters not found in '+main_args['cfg_file'])
        raise(Exception)
        
    # get the steps and any variables defined
        
    steps = config.get('control', 'steps').replace(' ','').split(',')
    for key, value in config.items('control'):
        if key != 'steps' and key != 'type':
            main_args[key] = value
            
    print('The following variables have been defined:')
    print(str(main_args))
    print('The following steps will be run:')
    print(str(steps))
            
    # loop over steps, calling appropriate plugins
    
    for step in steps:
        step_found = False
        print('Step '+step+': Starting.')
        print('Detected local parameters:')
        print(config.items(step))
        
        proc = Popen(['echo','\"'+step+'\"'])
        
        comms = proc.communicate() # note this waits for completion of the subprocess
        
        print(comms[0]) # stdout
        print(comms[1]) # stderr  
        
        if config.get(step, 'type') == 'python_executable':
            step_found = True
            ret = python_exec(step, config, main_args)
                
        if config.get(step, 'type') == 'maven':
            step_found = True
            ret = maven_build(step, config, main_args)
                
        if config.get(step, 'type') == 'rsync':
            step_found = True
            ret = rsync(step, config, main_args)
                
        if config.get(step, 'type') == 'scp':
            step_found = True
            ret = scp(step, config, main_args)
                
        if config.get(step, 'type') == 'remote_sql':
            step_found = True
            ret = remote_sql(step, config, main_args)
                
        if config.get(step, 'type') == 'remote_exec':
            step_found = True
            ret = remote_exec(step, config, main_args)
                
        if config.get(step, 'type') == 'filesys_op':
            step_found = True
            ret = filesys_op(step, config, main_args)
            
        if config.get(step, 'type') == 'str_replace':
            step_found = True
            ret = str_replace(step, config, main_args)
            
        if config.get(step, 'type') == 'git_command':
            step_found = True
            ret = git_command(step, config, main_args)
    
        if config.get(step, 'type') == 'move_solr_configs':
            step_found = True
            ret = move_solr_configs(step, config, main_args)
            
        if config.get(step, 'type') == 'extract_variable':
            step_found = True
            ret, var = extract_variable(step, config, main_args)
            if ret == 0:
                varname = parse_args(config.get(step, 'to').replace(' ',''), main_args)
                main_args[varname] = var
                print('Successfully extracted value '+var+' to variable '+varname)
                
        if config.get(step, 'type') == 'remote_build':
            step_found = True
            ret = connect_to_build_server(step, config, main_args)
            
        if config.get(step, 'type') == 'update_from_remote':
            step_found = True
            ret = update_from_build_server(step, config, main_args)

        if config.get(step, 'type') == 'clean_remote':
            step_found = True
            ret = clean_build_server(step, config, main_args)
          
        if step_found:
            if(ret != 0):
                print('Error executing step '+step)
                raise(Exception)
            print('Step '+step+' complete')
            
        else:
            print('Error: Step '+step+' not found.')
            raise(Exception)
        
    print('Pipeline finished.')
    
if __name__ == '__main__':
    pipeline()