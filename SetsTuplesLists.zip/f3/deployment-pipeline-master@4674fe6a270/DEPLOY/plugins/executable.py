# -*- coding: utf-8 -*-
"""
Created on Mon Feb  6 16:51:37 2017

@author: Colm Coughlan. Data Science and Solutions. 40631

This module contains code to be executed on the build server.

"""

from subprocess import Popen, PIPE
import os
from utilities import parse_args , get_user
import sys
import glob
if sys.version_info[0] > 2:
    from urllib.parse import quote
else:
    from urllib import quote

# Allows python code to be executed on the local (Jenkins) node

def python_exec(step, config, main_args):
    '''
    Execute python function on build server.
    
    :param str type: python_executable
    :param str path: path to directory
    :param str exec: filename
    :param str args: comma separated list of arguments to called python script
    :param bool expand_wildcards: Optional. true to expand wildcards in args, treating them as files on the system. Default = false.
    :param str wait: wait until complete?
    :return: Return code of executed file
    '''
    # get step parameters and construct command string to be executed
    path = parse_args(config.get(step, 'path').replace(' ',''), main_args)
    cmd_str = 'python ' + os.path.join(path, config.get(step, 'exec'))
    args = config.get(step, 'args').replace(' ','').split(',')

    try:
        expand_wildcards = parse_args(config.get(step, 'expand_wildcards'), main_args)
        if expand_wildcards.lower() == 'true':
            expand_wildcards = True
            print('Expanding wildcards')
        else:
            expand_wildcards = False
    except Exception as e:
        expand_wildcards = False
    
    target_pos = -1
    for i, arg in enumerate(args):
        parg = parse_args(arg, main_args)
        if '*' in parg and expand_wildcards:
            targets = glob.glob(parg)
            target_pos = i
            print(parg)
            print(targets)
            break
        cmd_str = cmd_str + ' ' + parg
        
    if target_pos > 0:
        cmd_strs = []
        for target in targets:
            cmd_str_tmp = 'python ' + os.path.join(path, config.get(step, 'exec'))
            for i, arg in enumerate(args):
                if i == target_pos:
                    parg = target
                else:
                    parg = parse_args(arg, main_args)
                cmd_str_tmp = cmd_str_tmp + ' ' + parg
            cmd_strs.append(cmd_str_tmp)
    else:
        cmd_strs = [cmd_str]
        
    for cmd_str in cmd_strs:
        print(cmd_str)
        
        # launch command string as subprocess in non-shell mode
        proc = Popen(cmd_str.split())
        if parse_args(config.get(step, 'wait'), main_args) == 'True':
            proc.wait()
            print('Python executable finised.')
            if proc.returncode !=0:
                return(proc.returncode)
        else:
            print("PP not implemented yet - going to wait instead.")
            proc.wait()
            if proc.returncode !=0:
                return(proc.returncode)
            
    return 0
        
# Maven build on local node
    
        
def maven_build(step, config, main_args):
    '''
    Build maven on build server.
    
    :param str type: = maven
    :param str path: = path to directory with pom.xml
    :param str version: = maven version - only tested with 3.2.3
    :param str args: = comma separated list of arguments to maven
    :param str wait: = wait until complete?
    :return: Return code of executed file
    '''
    
    # get step parameters and construct command string to be executed
    path = parse_args(config.get(step, 'path').replace(' ',''), main_args)
    version = parse_args(config.get(step, 'version').replace(' ',''), main_args)
    os.environ['PATH'] = os.pathsep.join(['/opt/maven/apache-maven-'+version+'/bin','/opt/jdk1.8.0_20/bin']) + os.pathsep + os.environ['PATH']
    cmd_str = 'mvn -T 1C' # maven with one thread per core
    args = config.get(step, 'args').replace(' ','').split(',')
    for arg in args:
        cmd_str = cmd_str + ' ' + parse_args(arg, main_args)
    cmd_str = cmd_str + ' -f '+os.path.join(path,'pom.xml')
    print(cmd_str)
    
    proc = Popen(cmd_str.split(), stdout=PIPE, stderr=PIPE)
    comms = proc.communicate() # note this waits for completion of the subprocess
    print(comms[0]) # stdout
    print(comms[1]) # stderr
    
    if parse_args(config.get(step, 'wait'), main_args) == 'True':
        proc.wait()
        print('Python executable finised.')
        return(proc.returncode)
    else:
        print("PP not implemented yet - going to wait instead.")
        proc.wait()
        return(proc.returncode)
        
def git_command(step, config, main_args):
    '''
    Git commands. Currently implemented without use of python's git module, due to out of date python on Jenkins.
    User and pipeline are identified automatically if using Jenkins. This may fail on different Jenkins versions.
    
    :param str type: = git_command
    :param str path: = path to directory with pom.xml
    :param str cmd: = commit_push
    :param str branch: = The branch to push do
    :param str cmsg: = The commit message (include a JIRA tag)
    :return: Return code of executed file
    '''
    # get step parameters and construct command string to be executed
    path = parse_args(config.get(step, 'path').replace(' ',''), main_args)
    cmd = parse_args(config.get(step, 'cmd').replace(' ',''), main_args)
    branch = parse_args(config.get(step, 'branch').replace(' ',''), main_args)
    cmsg = parse_args(config.get(step, 'commit_msg').replace(' ',''), main_args)
    
    if(cmd != 'commit_push'):
        print('Error: only git commit supported at the moment.')
        return(1)
        
    user, pipeline = get_user()
    print('Git commit with user: '+user+', from pipeline: '+pipeline)
    cmsg = 'Jenkins. User:'+user+', pipeline: '+pipeline + '. ' + cmsg
    
    cmd_str = 'git --git-dir='+path+'/.git'+' --work-tree='+path+' config --replace-all user.name \"'+user+'\"'

    proc = Popen(cmd_str.split())
    comms = proc.communicate() # note this waits for completion of the subprocess
    print(comms[0]) # stdout
    print(comms[1]) # stderr
    
    cmd_str = 'git --git-dir='+path+'/.git'+' --work-tree='+path+' config --replace-all user.email \"hadoop.supp@aib.ie\"'

    proc = Popen(cmd_str.split())
    comms = proc.communicate() # note this waits for completion of the subprocess
    print(comms[0]) # stdout
    print(comms[1]) # stderr
        
    cmd_str = 'git --git-dir='+path+'/.git'+' --work-tree='+path+' commit -am '
    cmsg = [cmsg]
    print(cmd_str + cmsg[0])
        
    proc = Popen(cmd_str.split()+cmsg)
    comms = proc.communicate() # note this waits for completion of the subprocess
    print(comms[0]) # stdout
    print(comms[1]) # stderr
    
    cmd_str = 'git --git-dir='+path+'/.git'+' --work-tree='+path+' config --get remote.origin.url'
    git_url = Popen(cmd_str.split(), stdout=PIPE).communicate()[0]
    if '@' in git_url:
        git_url = git_url.split('@')[1]
    else:
        git_url = git_url.split('https://')[1]
    git_url = git_url.strip()
    
    git_user = os.environ['GIT_USERNAME']
    git_pass = quote(os.environ['GIT_PASSWORD'], safe = '')
    
    cmd_str = 'git --git-dir='+path+'/.git'+' --work-tree='+path+' push https://'+git_user+':'+git_pass+'@'+git_url+' '+branch
    ret = os.system(cmd_str)
    
    return(ret)