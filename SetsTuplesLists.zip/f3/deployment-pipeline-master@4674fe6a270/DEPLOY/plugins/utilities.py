# -*- coding: utf-8 -*-
"""
Created on Mon Feb  6 16:53:46 2017

@author: Colm Coughlan. Data Science and Solutions. 40631

Various utility functions for deployment pipeline
"""

import shutil
import glob
import sys
import os
import re
import getpass
import xml.etree.ElementTree as ET

if sys.version_info[0] > 2:
    fileerror = FileNotFoundError
else:
    fileerror = (OSError,IOError)

# parse a string and replace any variables with their values
# variable format = ${variablename}

variable_regex = re.compile("\${(\S*?)}") # non-greedy matching

def get_user():
    '''
    Attempt to get the name of the user running the current pipeline by reading jenkins\_username and jenkins\_pipename from system environment.
    
    :return: A tuple of the user name (Fallback is to use getpass) and the Jenkins pipeline name (Fallback is to use Unknown Pipeline)
    '''
    try:
        user = os.environ['jenkins_username']
        pipe = os.environ['jenkins_pipename']
        
        if len(user) < 1 or len(pipe) < 1:
            raise(Exception)
    except:
        user = getpass.getuser()
        pipe = 'Unknown pipeline'
    return(user, pipe)

def parse_args(arg, main_args):
    '''
    Parse input parameters to replace \$\{\} syntax with correct variable
    
    :param str arg: User provided argument to check
    :param str main_args: Dictionary of defined variables
    :return: Original argument after replacement
    '''
    if '$' in arg:
        new_arg = arg
        for match in variable_regex.findall(arg):
            if(match in main_args):
                new_arg = new_arg.replace('${'+match+'}',main_args[match])
            else:
                print('Error: variable '+match+' not set.')
                print('Error from argument: '+arg)
                raise(Exception)
        return(new_arg)
    else:
        return(arg)
        
def extract_variable(step, config, main_args):
    '''
    Extract a variable from a file or other resource
    
    :param str type: extract_variable
    :param str extraction_type: version_from_pom. Get the version from a maven pom.
    :param str from: Path to the file.
    :param str to: Name of variable to use for storage (as string)
    :return: 0,variable
    '''

    extract_type = parse_args(config.get(step, 'extraction_type').replace(' ',''), main_args)
    
    if extract_type != 'version_from_pom':
        print('Error: Unsupported extraction type')
        raise(Exception)
        
    pom = parse_args(config.get(step, 'from').replace(' ',''), main_args)
        
    tree = ET.parse(pom)
    root = tree.getroot()
    var = ''
    for child in root:
        if 'version' in child.tag:
            if (child.tag).split('}')[1] == 'version':
                var = str(child.text) # expect format is {namespace}version
            
    if var != '':
        print('Successfully extracted variable')
        return 0,var
    else:
        print('Error extracting variable')
        return 1,1

        
def filesys_op(step, config, main_args):
    '''
    Standard file system operations on build server
    
    :param str type: filesys_op
    :param str cmd: command to run
    :param str source: source dir\/file if applicable (cp,mv)
    :param str dest: destination dir\/file if applicable (cp,mv)
    :param str target: target file for operation, if applicable (rm)
    :return: 0
    '''
    cmd = parse_args(config.get(step, 'cmd').replace(' ',''), main_args)
    
    supported_ops = ['rm','cp','mv']
    
    if cmd not in supported_ops:
        print("Error: Unsupported filesystem operation: "+cmd)
        raise(Exception)
    
    if cmd == 'rm':
        target = parse_args(config.get(step, 'target').replace(' ',''), main_args)
        try:
            shutil.rmtree(target)
        except fileerror:
            print('File/directory '+target+' did not exist.')
        
    if cmd == 'cp':
        source = parse_args(config.get(step, 'src').replace(' ',''), main_args)
        dest = parse_args(config.get(step, 'dest').replace(' ',''), main_args)
        shutil.copytree(source, dest)
        
    if cmd == 'mv':
        source = parse_args(config.get(step, 'src').replace(' ',''), main_args)
        dest = parse_args(config.get(step, 'dest').replace(' ',''), main_args)
        shutil.move(source, dest)
    
    return(0)
    

def str_replace(step, config, main_args):
    '''
    Replace strings via regex. Capture groups supported.
    
    :param str type: str_replace
    :param str files: files to target
    :param str repl: Replacement value. Capture groups supported.
    :param str pattern: Regular expression to match.
    :param str case: Ignore case (true\/false)
    :param str wildcard: Optional. Interpret repl as wildcard itself. Useful for expanding paths. Supported values: none, full, tail.
    :return: 0
    '''
    files = parse_args(config.get(step, 'files').replace(' ',''), main_args)
    repl = parse_args(config.get(step, 'repl').replace(' ',''), main_args)
    regex_str = parse_args(config.get(step, 'pattern').replace(' ',''), main_args)
    case = parse_args(config.get(step, 'case').replace(' ',''), main_args).lower()
    try:
        wildcard_path = parse_args(config.get(step, 'wildcard').replace(' ',''), main_args)
    except:
        wildcard_path = 'none'

    if case == 'true':
        regex = re.compile(regex_str)
    else:
        regex = re.compile(regex_str, re.IGNORECASE)

    if wildcard_path != 'none':
        if wildcard_path == 'full':
            repl = ' '.join(glob.glob(repl)) # expand the wildcard
        elif wildcard_path == 'tail':
            repl_files = glob.glob(repl)
            repl = ''
            for file in repl_files:
                repl = file.split(os.path.sep)[-1] + ' ' + repl
            repl = repl[:-1] # cut off extra space
        
    files = glob.glob(files)
            

    #print('Initiating string replace: '+regex_str+' -> '+repl)
    #print('Case sensitiviy = '+case)
    for file in files:
        with open(file,'r') as f:
            lines = f.read()
            if case == 'match':
                new_lines = lines
                nsub = 0
                for match in regex.findall(lines):
                    if match.isupper():
                        new_lines = new_lines.replace(match, repl.upper())
                    elif match.islower():
                        new_lines = new_lines.replace(match, repl.lower())
                    else:
                        print('Error: Trying to match case to mixed string!')
                        raise(Exception)
                    nsub = nsub + 1
            else:
                (new_lines, nsub) = re.subn(regex, repl,lines)
        if nsub > 0:
            #print('Replacing '+str(nsub)+' entries in '+file)
            with open(file,'w') as f:
                f.write(new_lines)
        else:
            print('No replacement performed in '+file)
    
    return(0)

    
def move_solr_configs(step, config, main_args):
    '''
    Move solr configuration files into correct spots in standard directory layout.
    
    :param str type: move_solr_configs
    :param str solr_dir: Original Solr directory containing json
    :param str project_dir: Top level of Project directory. Standard format assumed.
    :return: 0
    '''    
    
    
    solr_dir = parse_args(config.get(step, 'solr_dir').replace(' ',''), main_args)
    project_dir = parse_args(config.get(step, 'project_dir').replace(' ',''), main_args)
    
    files = os.listdir(solr_dir)
        
    if len(files) < 1:
        print('Error: no solr files found!')
        raise(Exception)
        
    for sfile in files:
        folder_name = os.path.join(os.path.join(project_dir, sfile.split('_solr_config')[0]),'Job_Config')
        if os.path.join('_JOB','Job_Config') in folder_name and '(' in folder_name:
            folder_name = os.path.join(folder_name.split('_(')[0],'Job_Config') # we have a multi load table. put json in same table
        new_file_name = os.path.join(folder_name, sfile)
        file_name = os.path.join(solr_dir, sfile)
        print('Moving '+file_name+' to '+new_file_name)
        shutil.move(file_name, new_file_name)
        
    return(0)