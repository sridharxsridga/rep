.. Data Acquisition documentation master file, created by
   sphinx-quickstart.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Data Acquisition Deployment Pipeline documentation.
==============================================

Data acquisition is the process of moving data in a valid format all the way from the landing directory into the appropriate tier one table. This process involves inspecting the landed file and comparing it to the specifications outlined in the Business Relational Document (BRD), performing any transformations required, moving the data to a hive table and updating BigSQL so that it's aware of the new data. Most of the work is done by a spark program which can validate, transform and load the data into hive (documented separately), however additional software is needed to deploy, run and schedule the process. This software is described in this document.

.. include deployment_pipeline

.. toctree::
   :maxdepth: 2

   deployment_pipeline/deployment-pipeline
   deployment_pipeline/deployment-pipeline-parms
   scheduler/scheduler



Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
