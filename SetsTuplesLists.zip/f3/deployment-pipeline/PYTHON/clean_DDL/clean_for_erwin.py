# -*- coding: utf-8 -*-
"""
Created on Wed Apr  5 11:37:33 2017

@author: 40632
"""
"""
/*=============================================
-- TABLE              : HR_SF_APPL_RECEIVED_PER_POS
-- PROCEDURE          : CREATE_STATEMENT.sql
-- FUNCTION           : Create table
-- STEPS              : ---------
-- AUTHOR             : data_batch
-- CREATE DATE        : 23/03/2017 13:46:45

-- DESCRIPTION        : This file creates the 
necessary table.


-- ============================================*/


CREATE EXTERNAL HADOOP TABLE IF NOT EXISTS HR_SF_APPL_RECEIVED_PER_POS
(
    APPLICATION_DATE     DATE STORED AS DATE     COMMENT 'System recorded date that an application is received from an applicant for a particular role.',
    APPLICATION_ID     CHAR(20)     COMMENT 'Unique ID number the system generates for an application when a candidate applies to a given role.',
    JOB_REQ_ID     CHAR(20)     NOT NULL      COMMENT 'Unique ID number the system generates when a job Requisition is first created.',
    REQUISITION_STATUS     VARCHAR(20)     NOT NULL      COMMENT 'A job requisition can have any given number of configured statuses outside of the standard, Open, Pending Approval or Closed, and illustrates the present status of a job requisition in the system.',
    APPLICATION_STATUS     VARCHAR(100)     COMMENT 'The status of an applicants application is where the candidate is currently sitting in the Talent Pipeline, i.e., 1st Interview',
    HR_RECRUITER_FIRST_NAME     VARCHAR(100)     NOT NULL      COMMENT 'The designated recruiters first name',
    HR_RECRUITER_LAST_NAME     VARCHAR(50)     NOT NULL      COMMENT 'The designated recruiters last name',
    AGENCY_NAME     VARCHAR(50)     COMMENT 'The business name or otherwise of the Recruitment Agency that forwarded the candidate to the particluar job requisition',
    LOAD_LAST_ACTION     CHAR(1)     NOT NULL      COMMENT 'Warehouse generated field identifying the system action of the accounting record. D = Deleted/Closed; I = Inserted; U = Update',
    LOAD_TIME     VARCHAR(30)     NOT NULL      COMMENT 'None'
    ) 
    STORED AS PARQUETFILE 
    COMMENT 'Actions Infotype - this table captures HR Data in SuccessFactors related to the number of prospective candidate applications received by the AIB on a per Job Requisition basis. From SuccessFactors Saas - Recruitment'
    PARTITIONED BY
    (
       PERIOD_DTE    DATE STORED AS DATE     NOT NULL      COMMENT 'The reporting period for the data in the table. For periodic/monthly tables this is the last working day of the month. For daily tables it is the previous working day.',
       SRCE_SYS    SMALLINT     NOT NULL      COMMENT 'Used for source acctg system for acc and source appl system for appl. Acctg Source Codes: Branch Acctg = 1359, Loan Acctg = 6, Bankmaster = 7, Credit Card = 3.  Appl Source Codes: NAPS = 23, QTS = 26, HMS = 25, CCNAPS = 3',
       SRCE_INST    SMALLINT     NOT NULL      COMMENT 'Used to identify the source institution (or division)  ROI=1, FTB=2, GB=3, Poland=4 (no longer used), Capital Markete=5, Enterprise=6  and EBS=9',
       LOAD_DTE    DATE STORED AS DATE     NOT NULL      COMMENT 'Auto populated System Field of Batch load date'
    )
;
"""


import re 
import sys
import os
# the number of arguments needed from the file name, if there is a list of arguments/files or not
#if len(sys.argv) < 2:
#    print ("Usage: python jazb.py <PATH_TO_FILE>")
#    sys.exit(1)
# prints out the arguments
#print(sys.argv)
# file path is the first argument of the file

repodir = 'D:\\Test Delete This\\data-acquisition-hr-data-priority-1-sap\\'
# turn the above into a list for all repos and generate a file for each 

for subdir, dirs, files in os.walk(repodir):
    for file in files:
        if file.startswith("CREATE_ STATEMENT.sql"):


#filePath=sys.argv[1]
            fileName = file
# need to have changeLines as an empty script when changign the read version of the tmpfile
changeLines=''
#with open(filePath,"r") as tmpfile:
with open(fileName,"r") as tmpfile:   
    for line in tmpfile:
        #writes the output as one long line adds on each new line
        changeLines += line
# re sub substitutes the comments out, spaces before and after, and resinserts changeLines on new lines 

changeLines = re.sub(r'CREATE EXTERNAL HADOOP TABLE IF NOT EXISTS','CREATE  TABLE',changeLines)
changeLines = re.sub(r'\s*COMMENT\s*\'.*\'',"",changeLines)
changeLines = re.sub(r'DATE STORED AS DATE','DATE',changeLines)
changeLines = re.sub(r'DATE\s*NOT NULL','DATE',changeLines)
changeLines = re.sub(r'\s*\)\s*STORED\s+AS.*\n','',changeLines)
changeLines = re.sub(r'\s*PARTITIONED\s+BY\s*\(\s*',',\n',changeLines)

tmpfile.close()
FileNameClose = DataModelingFile.sql
with open(FileNameClose,"w") as tfile:
#    for line in changeLines:
     for line in changeLines:
        #will overwrite the file to the new output
        tfile.write(line)
tfile.close()

"""
argumentsList = str(sys.argv)
agruments = len(sys.argv)
count = len(arguments)
for x in sys.argv:
    print ("Argument: "), x
    if len(sys.argv) !=2:
        print ("Usage: python ex.py")
        sys.exit(1)

"""