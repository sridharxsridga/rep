
#!/bin/bash

#createDirectories.sh
#This script takes in lists of directories in arrays from a config file and creates the nested directories


echo "Reading config..."

# Reads in config file (source here is a bash command)
source $1

# Prints the directory arrays
echo "PATHNAME=$PATHNAME"
echo "SOURCEARRAY=${SOURCEARRAY[*]}"
echo "INTERVALARRAY=${INTERVALARRAY[*]}"
echo "PROCESSARRAY=${PROCESSARRAY[*]}"

# Sets the delimiter in the pathnames
PATHDELIMITER="/"

echo "Generating directories..."

targets=''
# For loop to create directories (SOURCE here is a variable name)
for SOURCE in ${SOURCEARRAY[*]}; do
	for INTERVAL in ${INTERVALARRAY[*]}; do	
		for PROCESS in ${PROCESSARRAY[*]}; do
			targets=$targets' '$PATHNAME$SOURCE$PATHDELIMITER$INTERVAL$PATHDELIMITER$PROCESS
		done
	done
done
hadoop fs -mkdir -p $targets
hadoop fs -chmod 770 $targets