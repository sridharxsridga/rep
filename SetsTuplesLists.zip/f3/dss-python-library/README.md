Data Science and Solutions Python Library
==============================

This is a library of useful python functions.
Install by running pip.exe install . --trusted-host=pypi.python.org --upgrade
See the docs for more info (build with "make html" while in the docs folder)
