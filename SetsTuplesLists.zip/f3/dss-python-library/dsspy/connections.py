# -*- coding: utf-8 -*-
"""
Created on Fri May 26 09:50:44 2017

@author: Colm Coughlan. Data Science and Solutions. 40631
"""

import requests
import smtplib
import pyodbc
from email.mime.text import MIMEText
import warnings
import pandas as pd
import os
import subprocess
import json
#import jaydebeapi as jdbc

try:
    from paramiko import client as paramikoClient
except:
    warnings.warn('dsslib: No paramiko module found. paramiko functionality unavailable', ImportWarning)
    have_paramiko = False
else:
    have_paramiko = True

try:
    import jks
except:
    warnings.warn('dsslib: No JKS module found. JKS functionality unavailable', ImportWarning)
    have_jks = False
else:
    have_jks = True

class ConnError(Exception):
    """Base class for exceptions."""
    pass

class SolrError(ConnError):
    """Solr error."""
    pass

class ValidationError(ConnError):
    """Validator error."""
    pass

class SparkError(ConnError):
    """Spark error."""
    pass

class BigSQLError(ConnError):
    """Spark error."""
    pass


# get rota

def getrota(rotafile):
    '''
    Get the current email rota holder from a file
    
    :param str rotafile: Rota file to use
    '''
    crh_str = 'CURRENT_ROTA_HOLDERS:'    
    emails = []
    
    with open(rotafile) as f:
        line = f.readline()
        if crh_str not in crh_str:
            raise(Exception('Current rota holder cannot be identified'))
        current_holders = line.split(crh_str)[-1].strip()
        for current_holder in current_holders.split(','):
            emails.append(current_holder)

    return emails

# send emails to users
    
def sendemails(subject, msg, extra_recipients = [], rotafile = None):
    '''
    Send emails to selected users
    
    :param str subject: Email subject
    :param str msg: Email Message
    :param list(str) extra_recipients: Email addresses
    :param str rotafile: Rota file to use (default = None)
    '''
    sender = "scheduler@aib.ie"

    recipients = []
    
    if rotafile is not None:
        try:
            recipients = getrota(rotafile)
        except:
            rotamsg = 'Error reading from rota file '+rotafile
            print(rotamsg)
            msg = msg +'\n ' + rotamsg
    #recipients = ['Colm.P.Coughlan@aib.ie'] + extra_recipients
    recipients = recipients + extra_recipients
    msg = MIMEText(msg)
    msg['Subject'] = subject
    msg['From'] = sender
    msg['To'] = ", ".join(recipients)
    server = smtplib.SMTP("smtp.aib.pri:25")
    server.sendmail(sender, recipients, msg.as_string())
    server.quit()
    
def sql_parse_paramaterisation_not_an_option(sql):
    '''
    Reject text if it seems to contain SQL. You should only use this function if correct parametrisation does not work.
    See run_sql for example of how to pass data in a parameterised way.
    This function is aimed at free text values X, Y in statements such as INSERT INTO X.Y values (parameterized values)
    
    :param str sql: Text to check for SQL
    :return: The same string if it appears to be safe (no guarantees, use parameterisation if possible!)
    '''
    sql = sql.upper()
    if ';' in sql: # protection against sql injection
        raise(Exception)
    for word in sql:
        if word in ['SELECT', 'DROP','GRANT','DELETE','INSERT','FROM']:
            raise(Exception)
    return sql
    
def run_sql(sql, hostname, keyuser, keypass, keystore = None, params = None, storepass = 'none', conn_str = None, getdata = False):
    '''
    Run SQL commands on Teradata/bigsql etc.
    
    :param str sql: SQL to execute
    :param str hostname: Hostname of SQL server. Teradata if Teradata, otherwise enter the hostname.
    :param str keyuser: Login name (or JKS username key)
    :param str keypass: Password (or JKS password key)
    :param str keystore: JKS keystore (default = None)
    :param list parms: Parameters for SQL parameterisation. Important to avoid SQL injection. (default = None)
    :param str storepass: JKS store password (default = 'None')
    :param str conn_str: Custom connection string (default = None)
    :param bool getdata: Set to true if expecting data
    '''
    
    if keystore is not None:
        ks = jks.KeyStore.load(keystore, storepass).secret_keys
        biuser = ks[keyuser].key.decode('utf-8')
        bipass = ks[keypass].key.decode('utf-8')
    else:
        biuser = keyuser
        bipass = keypass

    #if os.name == 'nt' or 'Teradata' not in hostname:   
    
    if conn_str is None:
        if hostname == 'Teradata':
            conn_str = r'DRIVER={Teradata};DBCNAME=ncrdwprod.aib.pri;UID='+biuser+r';PWD='+bipass+r';QUIETMODE=NO;ENCRYPTDATA=ON'
        elif hostname == 'Teradata_BCP':
            conn_str = r'DRIVER={Teradata};DBCNAME=ncrdwbcp.aib.pri;UID='+biuser+r';PWD='+bipass+r';QUIETMODE=NO;ENCRYPTDATA=ON'
        else:
            conn_str = "DRIVER=DB2;DATABASE=bigsql;HOSTNAME="+hostname+";PORT=32051;PROTOCOL=TCPIP;UID="+str(biuser)+";PWD="+str(bipass)+";"
    else:
        conn_str = conn_str + ";UID="+str(biuser)+";PWD="+str(bipass)+";"
    

    with pyodbc.connect(conn_str, autocommit=False,unicode_results=False) as conn:
        if getdata and params is not None:
            data = pd.read_sql(sql, conn , params = params)
        elif getdata:
            data = pd.read_sql(sql, conn)
        else:
            data = None
            with conn.cursor() as cursor:
                if params is not None:
                    cursor.execute(sql, params)
                else:
                    cursor.execute(sql)
                cursor.commit()
    '''
    else:
        jardir = os.environ['ADDITIONAL_JARS']
        jarpaths = [os.path.join(jardir,'tdgssconfig.jar'), os.path.join(jardir, 'terajdbc4.jar'), os.path.join(jardir, 'db2jcc4.jar')]
        #if you don't specify all the jars jaydebeapi spits an error when you connect to multiple databases
        if 'Teradata' in hostname: 
            if hostname == 'Teradata_Prod':
                td_server = 'NCRDWPROD.AIB.PRI'
            elif hostname == 'Teradata_BCP':
                td_server = 'NCRDWBCP.AIB.PRI'
            conn = jdbc.connect('com.teradata.jdbc.TeraDriver', 'jdbc:teradata://'+td_server
            ,{'user':biuser, 'password':bipass, 'CHARSET':'UTF-8'}
            ,jars=jarpaths)
        else:
            bi_server = hostname+':32051/bigsql'
            conn = jdbc.connect('com.ibm.db2.jcc.DB2Jcc', 'jdbc:db2://'+bi_server
            ,{'user':biuser, 'password':bipass, 'CHARSET':'UTF-8'}
            ,jars=jarpaths)
        

        if getdata and params is not None:
            data = pd.read_sql(sql, conn , params = params)
        elif getdata:
            data = pd.read_sql(sql, conn)
        else:
            data = None
            cursor = conn.cursor()
            if params is not None:
                cursor.execute(sql, params)
            else:
                cursor.execute(sql)
            cursor.commit()
        conn.close()
    '''

    return data

def sqoop_eval(libpath, edw_hostname, keyuser, keypass, edw_db, edw_stmt, keystore, storepass = 'none'):
    #edw_hostname is essentially bcp vs prod in the form of 'ncrdwbcp.aib.pri' 
    #will want to take this from solr eventually

    if keystore is not None:
        jceks = 'jceks://file'+keystore
        ks = jks.KeyStore.load(keystore, storepass).secret_keys
        edw_user = ks[keyuser].key.decode('utf-8')

        sqoop_eval = '''
    sqoop eval --libjars '''+libpath+''' \
    -Dhadoop.security.credential.provider.path='''+jceks+''' \
    --username '''+edw_user+''' \
    --password-alias 'sqoop.password' \
    --driver com.teradata.jdbc.TeraDriver \
    --connect jdbc:teradata://'''+edw_hostname+'''/database='''+edw_db+''' \
    --query "'''+ edw_stmt + '''"
    '''

    else:
        edw_user = keyuser
        edw_pass = keypass

        os.environ['sqoop_edw_pass'] = edw_pass
    
        sqoop_eval = '''
    sqoop eval --libjars '''+libpath+''' \
    --username '''+edw_user+''' \
    --password $sqoop_edw_pass \
    --driver com.teradata.jdbc.TeraDriver \
    --connect jdbc:teradata://'''+edw_hostname+'''/database='''+edw_db+''' \
    --query "'''+ edw_stmt + '''"
    '''

    sqoop_eval_check = subprocess.check_output(sqoop_eval, shell=True)
    sqoop_eval_output = [int(s) for s in sqoop_eval_check.split() if s.isdigit()]
    os.environ['sqoop_edw_pass'] = ''

    return sqoop_eval_output[0]
    
def write_to_solr(solr_url_in, outdict, ks_user = 'solr.user.write', ks_pass = 'solr.password.write', jceks = None, jceks_pass = None):
    '''
    Write an entry to solr
    
    :param str solr_url_in: Solr URL up to and including \select.
    :param str outdict: Dictionary of keys and values to post.
    :param str ks_user: Login name (or JKS username key)
    :param str ks_pass: Password (or JKS password key)
    :param str jceks: JKS keystore (default = None)
    :param str jceks_pass: JKS store password (default = 'None')
    '''
    
    solr_url = solr_url_in.split('select')[0]+'update?commit=true'

    # create json for solr
    '''
    This is an update in order to use json instead of xml when writing to solr
    It comes as a result of the xml not working in all cases
    Specifically when writing logs from the update_run_control_date step of the pipeline
    '''
    #convert dictionary to json array
    json_dict = json.dumps(outdict)

    #construct JSON payload
    payload = '''{"add" : {"doc" : ''' + json_dict + '''}}'''

    # write to solr
    headers = {"Content-Type": "application/json"}
    if jceks is not None:
        if jceks_pass is None:
            ksp = 'none'
        else:
            ksp = jceks_pass
        ks = jks.KeyStore.load(jceks, ksp).secret_keys
        cauth = requests.auth.HTTPBasicAuth(ks[ks_user].key.decode('utf-8'), ks[ks_pass].key.decode('utf-8') )
        resp = requests.post(solr_url, auth = cauth, data = payload, headers=headers)
    elif ks_user is not None:
        cauth = requests.auth.HTTPBasicAuth(ks_user, ks_pass)
        resp = requests.post(solr_url, auth = cauth, data = payload, headers=headers)
    else:
        resp = requests.get(solr_url, data = payload, headers=headers) # no authentication provided
    
    resp.raise_for_status() # raise an error if there have been any problems
    
    return 0
    
def query_solr(solr_url, ks_user = 'solr.user.read', ks_pass = 'solr.password.read', jceks = '', jceks_pass = 'none'):
    '''
    Search solr
    
    :param str solr_url: Exact solr query.
    :param str ks_user: Login name (or JKS username key)
    :param str ks_pass: Password (or JKS password key)
    :param str jceks: JKS keystore (default = None)
    :param str jceks_pass: JKS store password (default = 'None')
    '''


    if jceks != '':
        ks = jks.KeyStore.load(jceks,jceks_pass).secret_keys # authenticated request
        auth = requests.auth.HTTPBasicAuth(ks[ks_user].key.decode('utf-8'), ks[ks_pass].key.decode('utf-8') )
        resp = requests.get(solr_url, auth = auth)
    elif ks_user is not None:
        cauth = requests.auth.HTTPBasicAuth(ks_user, ks_pass)
        resp = requests.get(solr_url, auth = cauth)
    else:
        resp = requests.get(solr_url) # no authentication provided
    
    resp.raise_for_status() # raise an error if an invalid response was recieved
    contents = resp.json()
        
    return(contents)
    
class ssh:
    '''
    This class uses python's Paramiko library to implement a SSH client, allowing python to easily connect to other servers
    '''
    client = None

    def __init__(self, address, username, password):
        '''
        Constructor for SSH class
        
        :param str address: Server address
        :param str username: Login name
        :param str password: Password
        '''
        print('Connecting to '+address)
        self.client = paramikoClient.SSHClient()
        # The following line is required if you want the script to be able to access a server that's not yet in the known_hosts file
        self.client.set_missing_host_key_policy(paramikoClient.AutoAddPolicy())
        self.client.connect(address, username=username, password=password, look_for_keys=False)
            
    def close_connection(self):
        '''
        Close the existing connection
        '''
        if(self.client != None):
            self.client.close()
            
    def send_command(self, command):
        '''
        Run a command on an existing connection
        
        :param str command: Bash command to run
        :param str username: Login name
        :param str password: Password
        :return: A tuple. First: Return value of process. Second: Any text output by the remote command.
        '''
        # Check if connection is made previously
        if(self.client):
            print('Running: '+command)
            stdin, stdout, stderr = self.client.exec_command(command)
            recieved_data = False
            while not stdout.channel.exit_status_ready():
                # Print stdout data when available
                if stdout.channel.recv_ready():
                    # Retrieve the first 1024 bytes
                    alldata = stdout.channel.recv(1024)
                    recieved_data = True
                    while stdout.channel.recv_ready():
                        # Retrieve the next 1024 bytes
                        alldata += stdout.channel.recv(1024)
            if recieved_data:
                return stdout.channel.recv_exit_status(), str(alldata, "utf8")
            else:
                return stdout.channel.recv_exit_status(), 'No text returned: Return code:'+str(stdout.channel.recv_exit_status())
        else:
            raise(Exception('Connection not opened yet'))