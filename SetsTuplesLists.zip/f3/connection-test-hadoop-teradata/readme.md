# Connection Test Hadoop-Teradata
This is the test script which checks the connection between Hadoop and Teradata
Exports the hive table to Teradata and validates the record counts are the same on the hive and Teradata post sqoop. 

Sample use:
~~~~
python3 td_connect_test.py 'ncrdwprod.aib.pri' 'DDEWI07S' 'HADOOP_TD_CONN_TEST' 'rhhdomt9.mid.aib.pri' 'HDCWD00S' 'HADOOP_TD_CONN_TEST' --jceks=$prod_jceks_path
~~~~
## Dependencies
dsspy