my_variable = 'hello'
greetingss = 'nice to meet you'
print(my_variable)

print(my_variable)
friend_one ='Amit'

my_list_variable =['hello','hi','nice to meet you']

my_tuple_variable=('hello','hi','nice to meet you')

my_set_variable={'hello','hi','nice to meet you'}

print(my_list_variable)
print(my_tuple_variable)
print(my_set_variable)

my_short_tuple1=('sridhar')
my_short_tuple2=('sridhar',)
my_short_tuple3='sridhar',3

print(my_short_tuple1)
print(my_short_tuple2)
print(my_short_tuple3)

####################################
print(my_list_variable[0])
print(my_tuple_variable[1])
#TypeError: 'set' object does not support indexing
#print(my_set_variable[0])

print(my_list_variable.append("Rajesh"))
print(my_list_variable)

#How to append value to tuple

tuple_append = my_tuple_variable + ("Rajesh",)
print(my_tuple_variable)
print(tuple_append)

#How to append value to set
#Set does not contain duplicates
my_set_variable.add("hello")
my_set_variable.add("hello1")
print(my_set_variable)
